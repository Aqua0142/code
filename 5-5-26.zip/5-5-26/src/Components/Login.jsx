import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LayoutDashboard } from "lucide-react";

const DEFAULT_USERS = [
  { 
    username: "praveen@elite", 
    password: "gate", 
    name: "Praveen", 
    role: "Developer" 
  },
  { 
    username: "oviya@elite", 
    password: "admin", 
    name: "Oviya", 
    role: "Architect" 
  }
];
 
function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
 
  const navigate = useNavigate();
 
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Credentials required to access the pod.");
      return;
    }

    if (isLogin) {
      // 🟢 Check against default users
      const user = DEFAULT_USERS.find(
        (u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
      );

      if (user) {
        setError("");
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("currentUser", JSON.stringify(user)); // Store user info
        navigate("/");
      } else {
        setError("Access Denied: Invalid Squad Credentials.");
      }
    } else {
      setIsLogin(true);
      alert("Account created! Please log in.");
    }
  };
 
  return (
    <div className="relative flex-1 flex items-center justify-center bg-[#09090b] overflow-hidden text-zinc-100 font-sans py-12">
     
      {/* Ambient Lighting - Increased spread for a softer look */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />
 
      {/* Glassmorphism Card */}
      <form
        onSubmit={handleSubmit}
        className="relative z-10 bg-zinc-900/40 backdrop-blur-2xl border border-zinc-800 p-10 rounded-3xl w-[420px] shadow-[0_20px_50px_rgba(0,0,0,0.5)] transition-all duration-500"
      >
        {/* Accent line at the top of the card */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-violet-500 to-transparent" />
        {/* Accent line at the bottom of the card */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-violet-500 to-transparent" />
        
        <div className="text-center mb-10">
          {/* Flex container to hold Logo and Title side-by-side */}
          <div className="flex items-center justify-center gap-4">
            {/* Logo Icon */}
            <div className="w-12 h-12 bg-violet-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-violet-600/20">
              <LayoutDashboard size={25} className="text-white" />
            </div>

            {/* Title */}
            <h2 className="text-3xl font-bold tracking-tight text-white uppercase">
              Elite AI <span className="text-violet-500">Squad</span>
            </h2>
          </div>

          {/* Subtitle remains centered below the logo/title group */}
          <p className="text-[10px] text-zinc-500 uppercase tracking-[0.3em] mt-3 font-semibold">
            {isLogin ? "Login page" : "Sign In page"}
          </p>
        </div>
 
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs p-3 rounded-xl mb-6 text-center animate-pulse">
            {error}
          </div>
        )}
 
        <div className="space-y-5">
          <div className="relative">
            <input
              type="username"
              placeholder="USERNAME"
              className="w-full bg-zinc-950/40 border border-zinc-800 p-4 rounded-2xl focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 outline-none transition-all placeholder:text-zinc-600 text-sm"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
         
          <div className="relative group">
            <input
              type={showPassword ? "text" : "password"}
              placeholder="PASSWORD"
              // pr-16 ensures long passwords don't overlap with the icon button
              className="w-full bg-zinc-950/60 border border-zinc-800 text-zinc-100 p-4 pr-16 rounded-xl focus:outline-none focus:ring-1 focus:ring-violet-500 transition-all placeholder:text-zinc-600 text-sm"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              // Perfectly center the icon vertically and add space from the right edge
              className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-100 transition-colors p-1"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                // --- Hide Icon ---
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-5 h-5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"
                  />
                </svg>
              ) : (
                // --- Show Icon ---
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  strokeWidth={1.5}
                  stroke="currentColor"
                  className="w-5 h-5"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              )}
            </button>
          </div>
        </div>
 
        <div className="relative group mt-10">
  {/* The Glow Aura - Becomes vibrant violet on hover */}
  <div className="absolute -inset-1 bg-violet-600 rounded-2xl blur-md opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
 
  <button
    type="submit"
    className="relative w-full py-4 rounded-2xl font-bold text-xs tracking-[0.2em] transition-all duration-300 shadow-xl active:scale-[0.98] overflow-hidden
      bg-zinc-100 text-zinc-950
      hover:bg-violet-500 hover:text-white"
  >
    {/* Subtle internal shine that sweeps across on hover */}
    <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]" />
   
    <span className="relative z-10">
      {isLogin ? "LOGIN" : "SIGN IN"}
    </span>
  </button>
</div>
 
        <div className="mt-10 text-center flex flex-col items-center gap-4">
          <p className="text-sm text-zinc-500">
            {isLogin ? "New to the Elite AI?" : "Already have account?"}
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-violet-400 hover:text-violet-300 font-bold transition-colors ml-2"
            >
              {isLogin ? "Sign In" : "Login"}
            </button>
          </p>
 
          {isLogin && (
            <button type="button" className="text-[10px] text-zinc-600 uppercase tracking-widest hover:text-zinc-400 transition-colors">
              Forgot Credentials?
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
 
export default Login;
 