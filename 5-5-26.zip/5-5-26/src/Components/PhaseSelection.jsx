import React, { useState, useRef } from "react";
import html2pdf from "html2pdf.js";

import { useNavigate, useLocation } from "react-router-dom";

import { motion, AnimatePresence } from "framer-motion";

import {
  ShieldCheck,
  Settings,
  Cpu,
  Layout,
  Code,
  Activity,
  Rocket,
  AlertCircle,
  UserCheck,
  ChevronLeft,
  ChevronDown,
  Check,
  Plus,
  Info,
  ArrowRight,
  Minus,
  Server,
  Zap,
  Trash2,
  Sparkles,
  Bookmark,
  BookmarkCheck,
  Bot,
  Lock,
  Shield,
  Calendar,
  Users,
  Link as LinkIcon,
  FileUp,
  FolderTree,
  Globe,
  UserPlus,
  X,
  PencilLine,
  HardDrive,
} from "lucide-react";

// --- CONSTANTS ---

const ICON_BASE_URL =
  "https://raw.githubusercontent.com/Aqua0142/agent-icons/main";

const ICON_MAP = {
  "Product Owner": "Product Owner.png",

  "Project Manager": "Project Manager.png",

  "Solution Architect": "Architecture.png",

  "UI/UX Designer": "Designer.png",

  "Frontend Developer": "FE.png",

  "Backend Developer": "BE.png",

  "Database Engineer": "DB.png",

  "System Testing": "System Testing.png",

  "Integration Testing": "SIT.png",

  "Performance testing": "NFR_Tester.png",

  "UAT Agent": "UAT.png",

  "DevOps Engineer": "DevOps.png",

  "Doc Maker": "UAT.png",

  SAGE: "UAT.png",

  default: "UAT.png",
};

const MODEL_DATA = {
  "GPT-4o": { cost: "12.50", color: "text-emerald-400" },

  "GPT-5 (Flagship)": { cost: "11.25", color: "text-emerald-400" },

  "Claude Sonnet 4.6": { cost: "18.00", color: "text-orange-400" },

  "Claude Opus 4.6": { cost: "30.00", color: "text-orange-400" },

  "Gemini 3 Pro": { cost: "14", color: "text-blue-400" },

  "Llama 3.1": { cost: "3.30", color: "text-purple-400" },
};

const MODEL_LIST = Object.keys(MODEL_DATA);

const AGENT_MAPPING = {
  p1: [{ name: "Product Owner" }],

  p2: [{ name: "Project Manager" }],

  p3: [{ name: "Solution Architect" }],

  p4: [
    { name: "Frontend Developer" },
    { name: "Backend Developer" },
    { name: "Database Engineer" },
  ],

  p5: [{ name: "System Testing" }, { name: "Integration Testing" }],

  p6: [{ name: "Performance testing" }],

  p7: [{ name: "UAT Agent" }],

  p8: [{ name: "DevOps Engineer" }],
};

const MANDATORY_AGENTS = [{ name: "Doc Maker" }, { name: "SAGE" }];

const STAGES = [
  { id: "p1", label: "Requirements", icon: ShieldCheck },

  { id: "p2", label: "Planning", icon: Settings },

  { id: "p3", label: "Architecture", icon: Cpu },

  { id: "p4", label: "Development", icon: Code },

  { id: "p5", label: "Testing", icon: Activity },

  { id: "p6", label: "NFR Testing", icon: ShieldCheck },

  { id: "p7", label: "UAT", icon: UserCheck },

  { id: "p8", label: "Deployment", icon: Rocket },
];

const STAGE_IO_DEFAULTS = {
  p1: {
    inputs: [
      { text: "Problem Statement", isMandatory: true },
      { text: "Business Objective", isMandatory: false },
    ],
    outputs: [
      { text: "BRD Document", isMandatory: true },
      { text: "User Stories Document", isMandatory: true },
    ],
  },

  p2: {
    inputs: [
      { text: "User Stories Document", isMandatory: true },
      { text: "NFR Tabel", isMandatory: true },
    ],
    outputs: [
      { text: "Sprint Plan", isMandatory: true },
      { text: "Dependency Graph", isMandatory: true },
      { text: "Risk Mitigation Plan", isMandatory: false },
    ],
  },

  p3: {
    inputs: [
      { text: "BRD & NFR Document", isMandatory: true },
      { text: "Functional Specs", isMandatory: true },
      { text: "Sprint Plan & Dependency Graph", isMandatory: false },
    ],
    outputs: [
      { text: "Architecture Blueprint", isMandatory: true },
      { text: "System Design Diagram", isMandatory: true },
      { text: "API Contract", isMandatory: true },
    ],
  },

  p4: {
    inputs: [
      { text: "Architecture Blueprint", isMandatory: true },
      { text: "API Contract", isMandatory: true },
      { text: "Design Specification", isMandatory: false },
    ],
    outputs: [
      { text: "Source Code", isMandatory: true },
      { text: "Unit Test Results", isMandatory: true },
    ],
  },

  p5: {
    inputs: [
      { text: "Source Code", isMandatory: true },
      { text: "Test Plan", isMandatory: true },
    ],
    outputs: [
      { text: "Test Reports", isMandatory: true },
      { text: "Bug Report", isMandatory: true },
    ],
  },

  p6: {
    inputs: [
      { text: "Verified Code", isMandatory: true },
      { text: "BRD & NFR Document", isMandatory: true },
      { text: "Compliance Standards", isMandatory: false },
    ],
    outputs: [
      { text: "Performance Report", isMandatory: true },
      { text: "Security Audit Log", isMandatory: true },
      { text: "Optimization Guide", isMandatory: false },
    ],
  },

  p7: {
    inputs: [
      { text: "BRD Document", isMandatory: true },
      { text: "Acceptance Criteria", isMandatory: true },
      { text: "Verified Code", isMandatory: true },
    ],
    outputs: [
      { text: "UAT Sign-off", isMandatory: true },
      { text: "UAT Summary", isMandatory: false },
    ],
  },

  p8: {
    inputs: [
      { text: "Software Artifacts", isMandatory: true },
      { text: "Test Report", isMandatory: true },
      { text: "Rollback Plan", isMandatory: true },
    ],
    outputs: [
      { text: "Live Environment URL", isMandatory: true },
      { text: "Deployment Log", isMandatory: true },
    ],
  },
};

const phaseDependencies = {
  planning: "requirements",
  architecture: "planning",
  development: "architecture",
  testing: "development",
  nfr: "testing",
};
const PHASE_REPO_CONFIG = {
  p1: ["doc"], // Requirements
  p2: ["doc"], // Planning
  p3: ["doc"], // Architecture
  p4: ["code", "doc"], // Development (Both)
  p5: ["code"], // Testing
  p6: ["code"], // NFR Testing
  p7: ["doc"], // UAT
  p8: ["code"], // Deployment
};

export default function PhaseStudio() {
  const navigate = useNavigate();

  const location = useLocation();

  const projectName = location.state?.draft?.projectName || "Untitled Pipeline";

  const fileInputRef = useRef(null);
  const summaryRef = useRef(null);

  const [currentStep, setCurrentStep] = useState(0);

  const [config, setConfig] = useState(() => {
    const initial = {};

    STAGES.forEach((s) => {
      const ioDefaults = STAGE_IO_DEFAULTS[s.id] || { inputs: [], outputs: [] };

      initial[s.id] = {
        inputs: ioDefaults.inputs,

        outputs: ioDefaults.outputs,

        context: "",

        reviewers: [],

        assets: [],

        agentConfigs: {},

        selectedAgents: AGENT_MAPPING[s.id]?.map((a) => a.name) || [],

        requirements: { compliance: [] },

        planning: { sprints: 0, points: 0, duration: 0 },

        development: { environment: "" },

        testing: { env: "Staging" },
      };

      const allPossibleAgents = [
        ...(AGENT_MAPPING[s.id] || []),

        { name: "Doc Maker" },

        { name: "SAGE" },
      ];

      allPossibleAgents.forEach((a) => {
        initial[s.id].agentConfigs[a.name] = [
          { model: "GPT-4o", instances: 1 },
        ];
      });

      AGENT_MAPPING[s.id]?.forEach((a) => {
        initial[s.id].agentConfigs[a.name] = [
          { model: "GPT-4o", instances: 1 },
        ];
      });
    });

    return initial;
  });

  const [approvedPhases, setApprovedPhases] = useState([]);

  const [entryMode, setEntryMode] = useState(null);

  const [entryValue, setEntryValue] = useState("");

  const [urlInput, setUrlInput] = useState("");

  const [focusedAgent, setFocusedAgent] = useState(null);

  const activeId = STAGES[currentStep].id;

  const activeLabel = STAGES[currentStep].label;

  const activeData = config[activeId];

  const currentPath = `/root/env-production/${activeLabel.toLowerCase().replace(/\s+/g, "-")}`;

  const isPhaseSelected = approvedPhases.includes(activeId);

  const isPhaseFilled = activeData.reviewers.length > 0;

  const [humanTeam, setHumanTeam] = useState({}); // { p1: ['John Doe'], p2: [] }

  const [isDetailsExpanded, setIsDetailsExpanded] = useState(false);

  const sprintCount = config.p2?.planning?.sprints || 0;
  const weeksPerSprint = config.p2?.planning?.duration || 0;
  const totalProjectWeeks = sprintCount * weeksPerSprint;
  const displayDuration = totalProjectWeeks || 12;

  // Helper to add/remove humans

  const addHumanToPhase = (name) => {
    if (!name.trim()) return;

    const current = activeData.humanTeam || [];

    updateField("humanTeam", [...current, name.trim()]);
  };

  const removeHumanFromPhase = (idx) => {
    const current = activeData.humanTeam || [];

    updateField(
      "humanTeam",
      current.filter((_, i) => i !== idx),
    );
  };

  const updateField = (field, value) => {
    setConfig((prev) => ({
      ...prev,
      [activeId]: { ...prev[activeId], [field]: value },
    }));
  };
  const getActiveInputs = () => {
    // 🟢 Use 'activeId' instead of 'activePhase.id'
    const currentPhaseId = activeId;

    // 🟢 Match the dependency key to your activeLabel
    const previousPhaseLabel = phaseDependencies[activeLabel.toLowerCase()];

    // Find the actual stage ID for the previous phase (e.g., 'Requirements' -> 'p1')
    const previousStage = STAGES.find(
      (s) => s.label.toLowerCase() === previousPhaseLabel,
    );
    const previousStageId = previousStage?.id;

    // 🟢 Use 'config' instead of 'phases'
    if (previousStageId && config[previousStageId]?.outputs?.length > 0) {
      return config[previousStageId].outputs.map((output) => ({
        ...output,
        isMandatory: true, // This ensures the text turns Orange
      }));
    }

    // Fallback to the current phase's default inputs
    return activeData.inputs;
  };
  const addItemToList = (type) => {
    if (!entryValue.trim()) return;

    const newItem = { text: entryValue.trim(), isMandatory: false };

    updateField(type, [...activeData[type], newItem]);

    setEntryValue("");
    setEntryMode(null);
  };

  const togglePhaseSelection = () => {
    if (isPhaseSelected) {
      setApprovedPhases((prev) => prev.filter((id) => id !== activeId));
    } else {
      setApprovedPhases((prev) => [...new Set([...prev, activeId])]);
    }
  };

  const toggleAgentSelection = (agentName) => {
    const currentSelected = activeData.selectedAgents;

    if (currentSelected.includes(agentName)) {
      if (currentSelected.length <= 1) return;

      updateField(
        "selectedAgents",
        currentSelected.filter((a) => a !== agentName),
      );
    } else {
      updateField("selectedAgents", [...currentSelected, agentName]);
    }
  };

  const updateAgentSetting = (agentName, key, value) => {
    const newConfigs = { ...activeData.agentConfigs };

    newConfigs[agentName][0][key] = value;

    updateField("agentConfigs", newConfigs);
  };

  const [isInstructionsExpanded, setIsInstructionsExpanded] = useState(true);

  const [showFinalModal, setShowFinalModal] = useState(false);

  // Helper to calculate total cost based on selected phases and their default agents

  const calculateTotalCost = (targetPhases) => {
    let totalCost = 0;

    targetPhases.forEach((pId) => {
      const agentsInPhase = AGENT_MAPPING[pId] || [];

      agentsInPhase.forEach(() => {
        // Using GPT-4o base cost from your MODEL_DATA (12.50)

        const tokenWeight = pId === "p5" || pId === "p6" ? 0.25 : 0.1;

        totalCost += 1.5 * tokenWeight * 12.5;
      });
    });

    // Add Mandatory Agents cost (SAGE ~9.00 + Tech Writer ~3.75 based on your logic)

    return (totalCost + 12.75).toFixed(2);
  };

  const getPhaseValidationState = () => {
    if (!isPhaseSelected) return "skipped";

    const hasReviewers = activeData.reviewers.length > 0;

    let hasMandatoryFields = true;

    if (activeId === "p2") {
      const { sprints, duration, points } = activeData.planning;

      // 🟢 Mandatory check: Values must be > 0

      hasMandatoryFields = sprints > 0 && duration > 0 && points > 0;
    } else if (activeId === "p4") {
      // 🟢 Mandatory check: Environment must be selected

      hasMandatoryFields =
        !!activeData.development.environment &&
        activeData.development.environment !== "1";
    } else if (["p5", "p6", "p7", "p8"].includes(activeId)) {
      hasMandatoryFields = !!activeData.testing?.env;
    }

    return hasReviewers && hasMandatoryFields ? "ready" : "pending";
  };

  const handleSaveNextAction = () => {
    const state = getPhaseValidationState();

    // 🟢 Deactivate if phase is not selected

    if (state === "skipped") return;

    if (state === "pending") {
      alert(
        "Incomplete Metadata: Please assign a Human Reviewer and fill all mandatory phase parameters (*).",
      );

      return;
    }

    // Mark as approved and move forward

    setApprovedPhases((prev) => [...new Set([...prev, activeId])]);

    if (currentStep < STAGES.length - 1) setCurrentStep((prev) => prev + 1);
  };

  const handleSkipAction = () => {
    if (activeId === "p8") {
      // For deployment skip: Open modal with currently approved phases only

      setShowFinalModal(true);
    } else {
      setApprovedPhases((prev) => prev.filter((id) => id !== activeId));

      if (currentStep < STAGES.length - 1) setCurrentStep((prev) => prev + 1);
    }
  };

  const handleStartPipelineAction = () => {
    const state = getPhaseValidationState();

    if (state === "skipped") return;

    if (state === "pending") {
      alert(
        "Incomplete Metadata: Please assign a Human Reviewer and fill mandatory Deployment fields.",
      );

      return;
    }

    // For deployment start: Ensure p8 is in approved list then open modal

    const finalApproved = [...new Set([...approvedPhases, activeId])];

    setApprovedPhases(finalApproved);

    setShowFinalModal(true);
  };

  // Inside PhaseStudio component
  const createAndNavigateProject = (finalPhases) => {
    const projectId = Date.now().toString(); // Consistent with ID type in router

    const newProject = {
      id: projectId,
      name: projectName,
      // finalPhases contains the IDs like ["p1", "p2", "p4"]
      selectedPhaseIds: finalPhases,
      phaseConfigs: config,
      totalCost: calculateTotalCost(finalPhases),
      cost: `${calculateTotalCost(finalPhases)}`,
      status: "New",
      stage: STAGES.find((s) => finalPhases.includes(s.id))?.label || "None",
      created: new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
    };

    // 1. Persist to LocalStorage so the Router Wrapper/Details page can find it
    const existingProjects = JSON.parse(
      localStorage.getItem("projects") || "[]",
    );
    localStorage.setItem(
      "projects",
      JSON.stringify([newProject, ...existingProjects]),
    );

    // 2. Navigate using the project ID route
    // We pass the project object in state as a backup for immediate rendering
    navigate(`/project/${projectId}`, {
      state: { project: newProject, phaseConfigs: config },
    });
  };

  const projectDuration = config.p2?.planning?.duration || 12;

  const downloadPDF = () => {
    const element = summaryRef.current;
    if (!element) return;

    const opt = {
      margin: [0.3, 0.3],
      filename: `${projectName}_Summary.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        backgroundColor: "#161920", // Keeps your professional dark theme
      },
      jsPDF: { unit: "in", format: "a3", orientation: "landscape" },
    };

    html2pdf().set(opt).from(element).save();
  };

  // --- Dynamic Right Sidebar Content ---

  const renderPhaseSpecificFields = () => {
    switch (activeId) {
      case "p1": // Requirements
        return (
          <div className="space-y-3 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2">
              <Shield size={12} /> Compliance Standards
            </label>

            <div className="grid grid-cols-2 gap-2">
              {["HIPAA", "SOC2", "GDPR", "PCI-DSS"].map((std) => (
                <button
                  key={std}
                  onClick={() => {
                    const current = activeData.requirements.compliance;

                    const next = current.includes(std)
                      ? current.filter((c) => c !== std)
                      : [...current, std];

                    updateField("requirements", {
                      ...activeData.requirements,
                      compliance: next,
                    });
                  }}
                  className={`px-3 py-2 rounded-lg text-[10px] font-bold border transition-all ${activeData.requirements.compliance.includes(std) ? "bg-violet-500/20 border-violet-500 text-white" : "bg-black/20 border-white/5 text-slate-500 hover:border-white/20"}`}
                >
                  {std}
                </button>
              ))}
            </div>
          </div>
        );

      case "p2": // Planning
        return (
          <div className="space-y-4 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2">
              <Calendar size={12} /> Sprint Configuration{" "}
              <span className="text-[10px] text-rose-500">*</span>
            </label>

            <div className="space-y-3">
              {[
                { l: "Number of Sprints", k: "sprints" },
                { l: "Points / Sprint", k: "points" },
                { l: "Duration / Sprint (Weeks)", k: "duration" }, // 🟢 Syncs with 'weeksPerSprint'
              ].map((item) => (
                <div
                  key={item.k}
                  className="flex justify-between items-center bg-black/20 p-2 rounded-xl border border-white/5"
                >
                  <span className="text-[10px] text-slate-400 font-bold">
                    {item.l}
                  </span>

                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    className="bg-transparent text-right w-12 outline-none text-white font-mono text-xs placeholder:text-slate-600"
                    value={activeData.planning[item.k]}
                    onChange={(e) => {
                      const val = Math.max(0, parseInt(e.target.value) || 0);
                      updateField("planning", {
                        ...activeData.planning,
                        [item.k]: val,
                      });
                    }}
                  />
                </div>
              ))}

              {/* 🟢 VISUAL FEEDBACK: Calculated Total Cycle */}
              <div className="pt-2 border-t border-white/10 flex justify-between items-center px-1">
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">
                  Estimated Cycle
                </span>
                <span className="text-[11px] font-black text-emerald-400 font-mono">
                  {displayDuration} Weeks
                </span>
              </div>
            </div>
          </div>
        );

      case "p3": // 🟢 NEW: Architecture
        return (
          <div className="space-y-4 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2">
              <Cpu size={12} /> Technology Preference
            </label>

            <div className="space-y-2">
              <input
                type="text"
                placeholder="e.g. FastAPI, PostgreSQL, Tailwind..."
                className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-[11px] text-white outline-none focus:border-violet-500/50 transition-all"
                value={activeData.architecture?.techStack || ""}
                onChange={(e) =>
                  updateField("architecture", {
                    ...activeData.architecture,
                    techStack: e.target.value,
                  })
                }
              />

              <p className="text-[8px] text-slate-500 px-1 uppercase tracking-tight">
                Specify framework or library preferences for the agents.
              </p>
            </div>
          </div>
        );

      case "p4": // Development
        return (
          <div className="space-y-4 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2">
              <Server size={12} /> Hosting Infrastructure{" "}
              <span className="text-[10px] text-rose-500">*</span>
            </label>

            <div className="space-y-3">
              <select
                className={`w-full bg-black/40 border rounded-xl p-2.5 text-[10px] font-bold outline-none focus:border-violet-500/50 transition-all ${activeData.development.environment ? "text-white border-white/10" : "text-slate-500 border-rose-500/30"}`}
                value={activeData.development.environment || ""}
                onChange={(e) =>
                  updateField("development", {
                    ...activeData.development,
                    environment: e.target.value,
                  })
                }
              >
                <option value="" disabled>
                  Select Infrastructure...
                </option>

                <option value="GCP">GCP</option>

                <option value="AWS">AWS</option>

                <option value="Docker">Docker</option>

                <option value="Kubernetes">Kubernetes</option>
              </select>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#0f1115] text-slate-100 font-sans overflow-hidden flex-col">
      <div className="h-24 border-b border-white/5 bg-[#161920] flex items-center px-12 shadow-2xl z-20 shrink-0">
        <div className="flex items-center justify-between w-full max-w-7xl mx-auto">
          {STAGES.map((stage, idx) => (
            <React.Fragment key={stage.id}>
              <div
                className="flex flex-col items-center gap-2 cursor-pointer group"
                onClick={() => {
                  setCurrentStep(idx);
                  setFocusedAgent(null);
                }}
              >
                <div
                  className={`w-9 h-9 rounded-lg border-2 flex items-center justify-center transition-all ${
                    currentStep === idx
                      ? "border-violet-500 bg-violet-500/20 text-white shadow-[0_0_15px_rgba(139,92,246,0.3)]"
                      : approvedPhases.includes(stage.id)
                        ? "border-emerald-500 bg-emerald-500/10 text-emerald-400"
                        : "border-slate-800 bg-slate-900/50 text-slate-600"
                  }`}
                >
                  {approvedPhases.includes(stage.id) ? (
                    <Check size={18} strokeWidth={3} />
                  ) : (
                    <stage.icon size={20} />
                  )}
                </div>

                <span
                  className={`text-[9px] font-black uppercase tracking-widest ${currentStep === idx ? "text-violet-400" : "text-slate-600"}`}
                >
                  {stage.label}
                </span>
              </div>

              {idx !== STAGES.length - 1 && (
                <div
                  className={`flex-1 h-[1px] mx-4 rounded-full ${approvedPhases.includes(STAGES[idx].id) ? "bg-emerald-500/50" : "bg-slate-800"}`}
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      <main className="flex-1 flex px-12 py-6 gap-8 overflow-hidden bg-[radial-gradient(#ffffff03_1px,transparent_1px)] [background-size:40px_40px]">
        <div className="flex-1 flex flex-col gap-6 overflow-y-auto no-scrollbar pr-4 custom-scrollbar">
          <div className="flex items-center justify-between shrink-0">
            <div className="flex flex-col">
              <h1 className="text-2xl font-black uppercase tracking-tighter text-white flex items-center gap-3">
                {activeLabel}{" "}
                <Sparkles size={24} className="text-violet-500 animate-pulse" />
              </h1>
            </div>

            {/* 🟢 NEW TOGGLE SWITCH COMPONENT */}

            <div className="flex items-center gap-4 bg-white/5 px-6 py-3 rounded-3xl border border-white/20">
              <span
                className={`text-[10px] font-black uppercase tracking-widest transition-colors ${isPhaseSelected ? "text-emerald-400" : "text-slate-300"}`}
              >
                {isPhaseSelected ? "Phase Selected" : "Select Phase "}
              </span>

              <div
                onClick={togglePhaseSelection}
                className={`relative w-14 h-7 rounded-full cursor-pointer transition-all duration-300 p-1 ${
                  isPhaseSelected
                    ? "bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                    : "bg-slate-700"
                }`}
              >
                <motion.div
                  animate={{ x: isPhaseSelected ? 28 : 0 }}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  className="w-5 h-5 bg-white rounded-full shadow-lg flex items-center justify-center"
                >
                  {isPhaseSelected ? (
                    <Check
                      size={12}
                      className="text-emerald-600"
                      strokeWidth={4}
                    />
                  ) : (
                    <X size={12} className="text-slate-400" strokeWidth={4} />
                  )}
                </motion.div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <EditableArtefactList
              title="Phase Inputs"
              list={getActiveInputs()}
              color="violet"
              type="inputs"
              entryMode={entryMode}
              entryValue={entryValue}
              setEntryValue={setEntryValue}
              onAddClick={() => setEntryMode("inputs")}
              onConfirm={() => addItemToList("inputs")}
              onDelete={(idx) =>
                updateField(
                  "inputs",
                  activeData.inputs.filter((_, i) => i !== idx),
                )
              }
              onToggle={(idx) => {
                const newList = [...activeData.inputs];

                if (
                  newList[idx].isMandatory &&
                  newList.filter((i) => i.isMandatory).length <= 1
                )
                  return;

                newList[idx].isMandatory = !newList[idx].isMandatory;

                updateField("inputs", newList);
              }}
              // 🟢 NEW PROPS

              repoUrl={location.state?.draft?.repoUrl}
              updateField={updateField}
            />

            <EditableArtefactList
              title="Phase Deliverables"
              list={activeData.outputs}
              color="emerald"
              type="outputs"
              entryMode={entryMode}
              entryValue={entryValue}
              setEntryValue={setEntryValue}
              onAddClick={() => setEntryMode("outputs")}
              onConfirm={() => addItemToList("outputs")}
              onDelete={(idx) =>
                updateField(
                  "outputs",
                  activeData.outputs.filter((_, i) => i !== idx),
                )
              }
              onToggle={(idx) => {
                const newList = [...activeData.outputs];

                newList[idx].isMandatory = !newList[idx].isMandatory;

                updateField("outputs", newList);
              }}
              repoUrl={location.state?.draft?.repoUrl} // 🟢 Source for fetching
              targetCodeRepo={location.state?.draft?.codeRepoUrl} // 🟢 Target Code
              targetDocRepo={location.state?.draft?.docRepoUrl} // 🟢 Target Docs
              activeId={activeId}
              updateField={updateField}
            />
          </div>

          {/* Agent Pool */}

          <div className="flex flex-col gap-4 bg-[#08080a] border border-white/10 rounded-3xl p-6 shadow-2xl relative">
            <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-emerald-500/40 to-transparent" />

            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <div className="flex items-center gap-3">
                {location.state?.draft?.executionMode === "hybrid" ? (
                  <>
                    <Users size={20} className="text-amber-500" />

                    <label className="text-[11px] font-black uppercase tracking-[0.2em] text-amber-500">
                      Hybrid Team Selection
                    </label>
                  </>
                ) : (
                  <>
                    <Bot size={20} className="text-emerald-500" />

                    <label className="text-[11px] font-black uppercase tracking-[0.2em] text-emerald-400">
                      Agent Selection Pool
                    </label>
                  </>
                )}
              </div>
            </div>

            <div className="grid grid-cols-4 gap-x-4 gap-y-10 py-4 relative">
              {/* 🟢 RENDER AGENTS (Always visible) */}

              {[
                ...(AGENT_MAPPING[activeId] || []),
                { name: "Doc Maker", isMandatory: true },
                { name: "SAGE", isMandatory: true },
              ]

                .filter(
                  (agent) =>
                    !(
                      location.state?.draft?.frameworkMode === "classic" &&
                      agent.name === "SAGE"
                    ),
                )

                .map((agent, index) => {
                  const isMandatory = agent.isMandatory;

                  const isSelected = isMandatory
                    ? true
                    : activeData.selectedAgents.includes(agent.name);

                  const isFocused = focusedAgent === agent.name;

                  const agentConfig = activeData.agentConfigs[
                    agent.name
                  ]?.[0] || { model: "GPT-4o", instances: 1 };

                  const isLastInRow = (index + 1) % 4 === 0;

                  return (
                    <div
                      key={agent.name}
                      className={`relative flex flex-col items-center ${isFocused ? "z-50" : "z-10"}`}
                    >
                      <div
                        onClick={() =>
                          !isMandatory && toggleAgentSelection(agent.name)
                        }
                        className={`relative group cursor-pointer transition-all duration-300 ${isFocused ? "scale-110" : "scale-100"}`}
                      >
                        <div
                          className={`w-20 h-20 rounded-[1.8rem] border-2 flex items-center justify-center relative transition-all duration-500 

                        ${
                          isSelected
                            ? isMandatory
                              ? "bg-black border-amber-500/60 shadow-[0_0_20px_rgba(245,158,11,0.2)]"
                              : "bg-black border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
                            : "bg-zinc-900/40 border-white/5 hover:border-white/20"
                        }`}
                        >
                          <img
                            src={`${ICON_BASE_URL}/${encodeURIComponent(ICON_MAP[agent.name] || ICON_MAP["default"])}`}
                            alt={agent.name}
                            className={`w-16 h-16 transition-all ${isSelected ? "opacity-100" : "opacity-50 grayscale group-hover:grayscale-0"}`}
                            onError={(e) =>
                              (e.target.src = `${ICON_BASE_URL}/UAT.png`)
                            }
                          />

                          {isSelected && (
                            <>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setFocusedAgent(
                                    isFocused ? null : agent.name,
                                  );
                                }}
                                className={`absolute -bottom-1 -left-1 w-7 h-7 rounded-xl border-2 border-black text-white flex items-center justify-center z-10 transition-colors ${isMandatory ? "bg-amber-600 hover:bg-amber-500" : "bg-emerald-600 hover:bg-emerald-500"}`}
                              >
                                <Settings
                                  size={14}
                                  className={isFocused ? "rotate-90" : ""}
                                />
                              </button>

                              {/* 🟢 AGENT COUNT BADGE: Re-added here */}

                              {!isMandatory && (
                                <div className="absolute -top-1 -right-1 w-6 h-6 bg-emerald-600 rounded-full border-2 border-black flex items-center justify-center z-10 shadow-lg shadow-emerald-900/40">
                                  <span className="text-[10px] font-black text-white">
                                    {agentConfig.instances}
                                  </span>
                                </div>
                              )}

                              {/* MANDATORY LOCK ICON */}

                              {isMandatory && (
                                <div className="absolute -top-1 -right-1 w-6 h-6 bg-amber-600 rounded-full border-2 border-black flex items-center justify-center z-10 shadow-lg shadow-amber-900/40">
                                  <Lock size={10} className="text-white" />
                                </div>
                              )}
                            </>
                          )}
                        </div>

                        <span
                          className={`mt-2 text-[9px] font-black uppercase tracking-tighter text-center block ${isSelected ? (isMandatory ? "text-amber-500" : "text-white") : "text-zinc-600"}`}
                        >
                          {agent.name}
                        </span>
                      </div>

                      <AnimatePresence>
                        {isFocused && (
                          <motion.div
                            initial={{ opacity: 0, x: isLastInRow ? 10 : -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{
                              opacity: 0,
                              scale: 0.9,
                              x: isLastInRow ? 10 : -10,
                            }}
                            // FIX: Smart alignment to prevent cutoff by right sidebar

                            className={`absolute top-0 z-[100] w-[220px] border rounded-2xl p-4 shadow-2xl backdrop-blur-md 

                                                  ${isLastInRow ? "right-[110%]" : "left-[110%]"} 

                                                  ${isMandatory ? "bg-[#0e0a05] border-amber-500/30" : "bg-[#0c0c0e] border-emerald-500/30"}`}
                          >
                            {/* Indicator Arrow */}

                            <div
                              className={`absolute top-8 w-3 h-3 rotate-45 border-l border-b 

                                                  ${isLastInRow ? "-right-[6px] rotate-[225deg]" : "-left-[6px]"} 

                                                  ${isMandatory ? "bg-[#0e0a05] border-amber-500/30" : "bg-[#0c0c0e] border-emerald-500/30"}`}
                            />

                            <div className="relative space-y-4">
                              {agent.name === "Doc Maker" ? (
                                <div className="space-y-3">
                                  <span className="text-[7px] font-black uppercase text-amber-500 tracking-[0.3em] block text-center">
                                    Documentation Engine
                                  </span>

                                  <select
                                    value={agentConfig.model}
                                    onChange={(e) => {
                                      e.stopPropagation();
                                      updateAgentSetting(
                                        agent.name,
                                        "model",
                                        e.target.value,
                                      );
                                    }}
                                    className="w-full bg-black border border-white/10 rounded-lg py-2 px-2 text-[9px] font-black uppercase outline-none text-amber-400"
                                  >
                                    {MODEL_LIST.map((m) => (
                                      <option key={m} value={m}>
                                        {m}
                                      </option>
                                    ))}
                                  </select>

                                  <div className="flex justify-between items-center px-1">
                                    <span className="text-[8px] text-zinc-500 uppercase font-bold">
                                      Est. Cost
                                    </span>

                                    <span className="text-[10px] text-amber-400 font-mono font-bold">
                                      ${MODEL_DATA[agentConfig.model]?.cost}/hr
                                    </span>
                                  </div>
                                </div>
                              ) : agent.name === "SAGE" ? (
                                <div className="space-y-3">
                                  <span className="text-[10px] font-black uppercase text-rose-500 tracking-[0.3em] block text-center">
                                    Security Firewall
                                  </span>

                                  <div className="grid grid-cols-1 gap-2">
                                    <div className="bg-black/40 border border-white/5 p-2 rounded-lg flex justify-between items-center">
                                      <span className="text-[6px] text-zinc-500 uppercase"></span>

                                      <span className="text-[7px] text-white font-bold uppercase"></span>
                                    </div>

                                    <div className="bg-black/40 border border-white/5 p-2 rounded-lg flex justify-between items-center">
                                      <span className="text-[6px] text-zinc-500 uppercase"></span>

                                      <span className="text-[7px] text-emerald-500 font-bold uppercase"></span>
                                    </div>
                                  </div>
                                </div>
                              ) : (
                                <>
                                  <div className="space-y-2">
                                    <span className="text-[8px] font-black uppercase text-zinc-500 tracking-widest block">
                                      Agent Count
                                    </span>

                                    <div className="flex items-center justify-between bg-black rounded-lg p-1 border border-white/5">
                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          updateAgentSetting(
                                            agent.name,
                                            "instances",
                                            Math.max(
                                              1,
                                              agentConfig.instances - 1,
                                            ),
                                          );
                                        }}
                                        className="p-1 hover:text-emerald-400 transition-colors"
                                      >
                                        <Minus size={12} />
                                      </button>

                                      <span className="text-sm font-black font-mono text-white">
                                        {agentConfig.instances}
                                      </span>

                                      <button
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          updateAgentSetting(
                                            agent.name,
                                            "instances",
                                            agentConfig.instances + 1,
                                          );
                                        }}
                                        className="p-1 hover:text-emerald-400 transition-colors"
                                      >
                                        <Plus size={12} />
                                      </button>
                                    </div>
                                  </div>

                                  <div className="space-y-2 pt-2 border-t border-white/5">
                                    <div className="flex justify-between items-end mb-1">
                                      <span className="text-[8px] font-black uppercase text-zinc-500 tracking-widest">
                                        Model & Cost
                                      </span>

                                      <span className="text-[10px] text-emerald-400 font-mono font-bold">
                                        ${MODEL_DATA[agentConfig.model]?.cost}
                                      </span>
                                    </div>

                                    <select
                                      value={agentConfig.model}
                                      onChange={(e) => {
                                        e.stopPropagation();
                                        updateAgentSetting(
                                          agent.name,
                                          "model",
                                          e.target.value,
                                        );
                                      }}
                                      className="w-full bg-[#121214] border border-white/10 rounded-lg py-2 px-2 text-[9px] font-black uppercase outline-none text-emerald-400 focus:border-emerald-500/50 transition-all"
                                    >
                                      {MODEL_LIST.map((m) => (
                                        <option key={m} value={m}>
                                          {m}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}

              {/* 🟢 HYBRID MODE: HUMAN TEAM SELECTION */}

              {location.state?.draft?.executionMode === "hybrid" && (
                <>
                  {/* Render existing humans */}

                  {(activeData.humanTeam || []).map((human, hIdx) => (
                    <div
                      key={`human-${hIdx}`}
                      className="flex flex-col items-center animate-in fade-in zoom-in duration-300"
                    >
                      <div className="w-20 h-20 rounded-[1.8rem] border-2 border-amber-500/40 bg-amber-500/5 flex items-center justify-center relative group">
                        <Users size={32} className="text-amber-500/80" />

                        <button
                          onClick={() => removeHumanFromPhase(hIdx)}
                          className="absolute -top-1 -right-1 w-6 h-6 bg-rose-600 rounded-full border-2 border-black flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={12} className="text-white" />
                        </button>
                      </div>

                      <span className="mt-3 text-[9px] font-black uppercase text-amber-200 tracking-tighter truncate w-20 text-center">
                        {human}
                      </span>
                    </div>
                  ))}

                  {/* Add Human Trigger */}

                  <div className="flex flex-col items-center">
                    {entryMode === "add-human" ? (
                      <motion.div
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="w-20 h-20 rounded-[1.8rem] border-2 border-amber-500 bg-black flex flex-col items-center justify-center p-2"
                      >
                        <input
                          autoFocus
                          className="w-full bg-transparent text-[10px] text-white text-center outline-none font-bold"
                          placeholder="ID/Name"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              addHumanToPhase(e.target.value);

                              setEntryMode(null);
                            }

                            if (e.key === "Escape") setEntryMode(null);
                          }}
                          onBlur={() => setEntryMode(null)}
                        />

                        <span className="text-[7px] text-amber-500 font-black mt-1 uppercase">
                          Enter
                        </span>
                      </motion.div>
                    ) : (
                      <div
                        onClick={() => setEntryMode("add-human")}
                        className="w-20 h-20 rounded-[1.8rem] border-2 border-zinc-400 hover:border-amber-500/50 hover:bg-amber-500/5 transition-all cursor-pointer flex flex-col items-center justify-center group"
                      >
                        <UserPlus
                          size={24}
                          className="text-zinc-300 group-hover:text-amber-500 transition-colors"
                        />
                      </div>
                    )}

                    <span className="mt-3 text-[9px] font-black uppercase text-zinc-300 tracking-tighter">
                      Add Human
                    </span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="w-[320px] flex flex-col gap-6 shrink-0 overflow-y-auto no-scrollbar custom-scrollbar pr-1">
          <div className="flex flex-col gap-4 bg-gradient-to-br from-[#1a1d24] to-[#161920] border border-violet-500/20 rounded-3xl p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex flex-col">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-violet-400">
                  Human Reviewer <span className="text-rose-500 ml-0.5">*</span>
                </label>
                <span className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">
                  Assign members
                </span>
              </div>

              <button
                onClick={() =>
                  setEntryMode(entryMode === "reviewers" ? null : "reviewers")
                }
                className="p-1.5 rounded-lg bg-violet-600 text-white"
              >
                <UserPlus size={16} />
              </button>
            </div>

            <div className="flex flex-col gap-2 max-h-[140px] overflow-y-auto no-scrollbar">
              <AnimatePresence>
                {entryMode === "reviewers" && (
                  <motion.form
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!entryValue) return;

                      updateField("reviewers", [
                        ...activeData.reviewers,
                        entryValue,
                      ]);

                      setEntryValue("");
                      setEntryMode(null);
                    }}
                    className="mb-1"
                  >
                    <input
                      autoFocus
                      value={entryValue}
                      onChange={(e) => setEntryValue(e.target.value)}
                      placeholder="Enter Name or Emp ID..."
                      className="w-full bg-black border border-violet-500/50 rounded-xl py-2 px-3 text-xs outline-none text-white font-bold"
                    />
                  </motion.form>
                )}
              </AnimatePresence>

              {/* 🟢 DYNAMIC SIZING: Shrinks all cards when the 2nd name is added */}
              {activeData.reviewers.length > 1 ? (
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {activeData.reviewers.map((name, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between bg-white/[0.03] border border-white/5 px-2 py-1.5 rounded-lg group hover:border-violet-500/30"
                    >
                      <span className="text-[10px] font-bold text-slate-400 truncate">
                        {name}
                      </span>
                      <button
                        onClick={() =>
                          updateField(
                            "reviewers",
                            activeData.reviewers.filter((_, idx) => idx !== i),
                          )
                        }
                        className="opacity-0 group-hover:opacity-100 text-slate-600 hover:text-rose-500 transition-colors"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                activeData.reviewers.map((name, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between bg-white/[0.03] border border-white/5 px-3 py-2 rounded-xl group hover:border-violet-500/30"
                  >
                    <span className="text-xs font-bold text-slate-200">
                      {name}
                    </span>

                    <button
                      onClick={() =>
                        updateField(
                          "reviewers",
                          activeData.reviewers.filter((_, idx) => idx !== i),
                        )
                      }
                      className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-500 transition-all"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* 🟢 NEW PHASE SPECIFIC FIELDS CARD */}

          {renderPhaseSpecificFields()}

          <div className="bg-[#1a1d24] border border-white/10 rounded-3xl shadow-2xl flex flex-col overflow-hidden shrink-0 transition-all duration-300">
            {/* Header / Toggle Trigger */}

            <button
              onClick={() => setIsInstructionsExpanded(!isInstructionsExpanded)}
              className="w-full p-5 flex items-center justify-between hover:bg-white/[0.02] transition-colors"
            >
              <div className="flex items-center gap-2">
                <PencilLine size={14} className="text-violet-500" />

                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
                  Instructions
                </span>
              </div>

              <motion.div
                animate={{ rotate: isInstructionsExpanded ? 0 : -90 }}
                transition={{ duration: 0.2 }}
                className="text-slate-600"
              >
                <ChevronDown size={16} />
              </motion.div>
            </button>

            {/* Collapsible Content */}

            <AnimatePresence>
              {isInstructionsExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                >
                  <div className="px-5 pb-5 flex flex-col gap-5 border-t border-white/5 pt-5">
                    <div className="flex flex-col gap-3">
                      <textarea
                        value={activeData.context}
                        onChange={(e) => updateField("context", e.target.value)}
                        placeholder="Define phase-specific guidelines..."
                        className="h-24 bg-black/40 border border-white/5 rounded-xl p-3 text-xs text-slate-300 outline-none focus:border-violet-500/50 transition-all resize-none overflow-y-auto custom-scrollbar"
                      />
                    </div>

                    <div className="flex flex-col gap-3">
                      <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 flex items-center gap-2 px-1">
                        Upload Inputs
                      </label>

                      <div className="flex flex-row gap-2 items-stretch">
                        <div className="flex items-center bg-black/40 border border-white/5 rounded-xl px-3 py-2">
                          <Globe size={14} className="text-slate-600 mr-2" />

                          <input
                            type="text"
                            placeholder="Add source link"
                            className="bg-transparent text-[11px] w-full outline-none text-slate-200"
                            value={urlInput}
                            onChange={(e) => setUrlInput(e.target.value)}
                          />

                          <button
                            onClick={() => {
                              if (!urlInput) return;
                              updateField("assets", [
                                ...activeData.assets,
                                { type: "link", value: urlInput },
                              ]);
                              setUrlInput("");
                            }}
                            className="ml-2 text-violet-400 hover:text-white"
                          >
                            <Plus size={16} />
                          </button>
                        </div>

                        <button
                          onClick={() => fileInputRef.current.click()}
                          className="w-full py-2 bg-slate-800 hover:bg-slate-700 border border-white/5 rounded-xl text-slate-300 text-[11px] font-bold flex items-center justify-center gap-2 whitespace-nowrap"
                        >
                          <FileUp size={14} /> Attach File
                        </button>

                        <input
                          type="file"
                          ref={fileInputRef}
                          className="hidden"
                          onChange={(e) =>
                            e.target.files[0] &&
                            updateField("assets", [
                              ...activeData.assets,
                              { type: "file", value: e.target.files[0].name },
                            ])
                          }
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      <footer className="h-20 border-t border-white/5 bg-[#161920] flex items-center justify-between px-12 z-30 shrink-0">
        {/* 🟢 UPDATED: "Back" navigation replaced with "Previous" step logic */}

        <button
          onClick={() => {
            if (currentStep > 0) {
              setCurrentStep((prev) => prev - 1);

              setFocusedAgent(null); // Clear agent focus when switching steps
            } else {
              // If at the very first step, navigate back to setup

              navigate(-1);
            }
          }}
          className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-600 hover:text-white transition-colors flex items-center gap-3 group"
        >
          <ChevronLeft
            size={16}
            className="group-hover:-translate-x-1 transition-transform"
          />

          {currentStep > 0 ? "Previous Phase" : "Back to Setup"}
        </button>

        <div className="flex items-center gap-4">
          {/* Dynamic Skip Button */}

          <button
            onClick={handleSkipAction}
            className="px-8 py-3 rounded-xl text-[11px] font-black uppercase tracking-[0.2em] bg-slate-800 text-slate-400 hover:bg-slate-700 transition-all"
          >
            {activeId === "p8" ? "Skip & Run" : "Skip Phase"}
          </button>

          {/* Dynamic Action Button (Save & Next / Start Pipeline) */}

          {activeId === "p8" ? (
            <button
              onClick={handleStartPipelineAction}
              className={`px-10 py-3 rounded-xl text-[11px] font-black uppercase tracking-[0.2em] shadow-lg transition-all flex items-center gap-3  

                ${
                  getPhaseValidationState() === "ready"
                    ? "bg-emerald-600 text-white"
                    : getPhaseValidationState() === "pending"
                      ? "bg-orange-500 text-white"
                      : "bg-slate-900 text-slate-600 grayscale opacity-50"
                }`}
            >
              Start Pipeline <Rocket size={16} />
            </button>
          ) : (
            <button
              onClick={handleSaveNextAction}
              className={`px-10 py-3 rounded-xl text-[11px] font-black uppercase tracking-[0.2em] shadow-lg transition-all flex items-center gap-3  

                ${
                  getPhaseValidationState() === "ready"
                    ? "bg-emerald-600 text-white"
                    : getPhaseValidationState() === "pending"
                      ? "bg-orange-500 text-white"
                      : "bg-slate-900 text-slate-600 grayscale opacity-50"
                }`}
            >
              Save & Next <ArrowRight size={16} />
            </button>
          )}
        </div>
      </footer>

      <AnimatePresence>
        {showFinalModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div
              ref={summaryRef}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{
                opacity: 1,
                scale: 1,
                width: isDetailsExpanded ? "95vw" : "1000px",
                height: "85vh",
              }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0c0c0e] border border-white/10 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden flex flex-col transition-all duration-500"
            >
              <div className="absolute top-0 left-1/4 right-1/4 h-[2px] bg-gradient-to-r from-transparent via-emerald-500 to-transparent shadow-[0_0_20px_#10b981] shrink-0" />

              <div className="flex flex-col h-full gap-6">
                <div className="flex items-center justify-between shrink-0">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                      <Rocket size={20} />
                    </div>
                    <div className="flex flex-col">
                      <div className="flex items-center gap-3">
                        <h2 className="text-xl font-black uppercase tracking-[0.15em] text-white italic leading-none">
                          Project Timeline Summary
                        </h2>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            downloadPDF();
                          }}
                          className="p-2 rounded-full bg-white/5 border border-white/10 text-emerald-400 hover:bg-emerald-500 hover:text-black transition-all shadow-lg"
                          title="Download Summary PDF"
                        >
                          <FileUp size={18} />
                        </button>
                      </div>
                      <span className="text-[12px] text-emerald-500/60 font-black uppercase tracking-[0.4em] mt-2">
                        {projectName}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-8">
                    <button
                      onClick={() => setIsDetailsExpanded(!isDetailsExpanded)}
                      className={`flex items-center gap-3 px-6 py-3 rounded-2xl font-black text-[11px] uppercase tracking-widest transition-all border ${
                        isDetailsExpanded
                          ? "bg-white/5 border-white/10 text-slate-400"
                          : "bg-emerald-500 text-black border-emerald-400 shadow-[0_0_20px_#10b98144]"
                      }`}
                    >
                      {isDetailsExpanded ? "Hide Details" : "View Node Details"}
                      <motion.div
                        animate={{ rotate: isDetailsExpanded ? 180 : 0 }}
                      >
                        <ChevronDown size={16} />
                      </motion.div>
                    </button>
                    <div className="text-right border-l border-white/10 pl-8">
                      <span className="text-[10px] font-black text-slate-500 uppercase block mb-1">
                        Estimated Cycle
                      </span>
                      <span className="text-xl font-black text-emerald-400 font-mono tracking-tighter">
                        {displayDuration} Weeks
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto no-scrollbar pr-2 min-h-0">
                  <div className="flex gap-10 items-start overflow-hidden">
                    <motion.div
                      animate={{ width: isDetailsExpanded ? "45%" : "100%" }}
                      className="flex flex-col gap-2 shrink-0"
                    >
                      <div className="flex flex-col gap-4 mb-4">
                        <span className="text-[14px] font-black text-violet-400 uppercase tracking-widest italic px-1">
                          Gantt Chart
                        </span>
                        <div className="grid grid-cols-[160px_1fr] border-b border-white/5 pb-4">
                          <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest flex items-center">
                            Phase Node
                          </span>
                          <div className="flex justify-between px-2 gap-1">
                            {Array.from(
                              { length: displayDuration },
                              (_, i) => i + 1,
                            ).map((w) => (
                              <span
                                key={w}
                                className="text-[8px] font-black text-white w-full text-center py-1 bg-violet-600/40 rounded-[4px] border border-violet-500/20 shadow-sm shadow-violet-900/20"
                              >
                                W{w}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-1 relative">
                        <div className="absolute inset-0 grid grid-cols-[160px_1fr] pointer-events-none">
                          <div className="bg-transparent border-r border-white/5" />
                          <div className="flex justify-between px-1 h-full">
                            {Array.from({ length: displayDuration }).map(
                              (_, i) => (
                                <div
                                  key={i}
                                  className={`w-full h-full ${
                                    i % 2 === 0
                                      ? "bg-white/[0.05]"
                                      : "bg-transparent"
                                  }`}
                                />
                              ),
                            )}
                          </div>
                        </div>

                        {(() => {
                          {
                            /* 🟢 DYNAMIC SHIFT LOGIC */
                          }
                          let currentOffset = 2; // Start margin
                          const sortedApproved = [...approvedPhases].sort(
                            (a, b) =>
                              STAGES.findIndex((s) => s.id === a) -
                              STAGES.findIndex((s) => s.id === b),
                          );

                          return sortedApproved.map((id) => {
                            let width = 15;
                            const reqWidth = 15;
                            const planWidth = 18;
                            const archWidth = 15;
                            const devWidth = archWidth * 1.25;
                            const testWidth = devWidth * 0.75;
                            const nfrWidth = 8;

                            let marginLeft = currentOffset;

                            if (id === "p1") width = reqWidth;
                            if (id === "p2") width = planWidth;
                            if (id === "p3") width = archWidth;
                            if (id === "p4") {
                              width = devWidth;
                              // Start dev slightly earlier (overlap) if architecture exists
                              if (approvedPhases.includes("p3")) {
                                marginLeft -= archWidth * 0.25;
                              }
                            }
                            if (id === "p5") {
                              width = testWidth;
                              // Start test mid-dev if dev exists
                              if (approvedPhases.includes("p4")) {
                                marginLeft -= devWidth * 0.5;
                              }
                            }
                            if (id === "p6") width = nfrWidth;
                            if (id === "p7") width = nfrWidth;
                            if (id === "p8") width = nfrWidth;

                            // Update offset for the next bar based on this bar's end position
                            currentOffset = marginLeft + width;

                            return (
                              <div
                                key={id}
                                className={`grid grid-cols-[160px_1fr] ${
                                  isDetailsExpanded ? "h-14" : "h-8"
                                } group items-center relative z-10`}
                              >
                                <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-white/[0.05] pointer-events-none" />
                                <div className="flex items-center px-2 h-full">
                                  <div className="w-1.5 h-1.5 rounded-full bg-violet-500 mr-3 shadow-[0_0_10px_#8b5cf6]" />
                                  <span className="text-[10px] font-black uppercase text-slate-300 truncate">
                                    {STAGES.find((s) => s.id === id)?.label}
                                  </span>
                                </div>
                                <div className="relative flex items-center px-1 h-full">
                                  <motion.div
                                    initial={{ width: 0 }}
                                    animate={{ width: `${width}%` }}
                                    className={`${
                                      isDetailsExpanded ? "h-3" : "h-4"
                                    } -full bg-gradient-to-r from-violet-600 to-violet-400 shadow-[0_0_15px_rgba(139,92,246,0.3)] relative z-10`}
                                    style={{ marginLeft: `${marginLeft}%` }}
                                  />
                                </div>
                              </div>
                            );
                          });
                        })()}
                      </div>
                    </motion.div>

                    <AnimatePresence>
                      {isDetailsExpanded && (
                        <motion.div
                          initial={{ width: 0, opacity: 0, x: 50 }}
                          animate={{ width: "55%", opacity: 1, x: 0 }}
                          exit={{ width: 0, opacity: 0, x: 50 }}
                          className="bg-black/20 border border-white/5 rounded-[2rem] p-6 overflow-hidden shadow-inner mt-2"
                        >
                          <table className="w-full text-left border-separate border-spacing-y-2">
                            <thead>
                              <tr className="text-[10px] font-black uppercase text-slate-500 tracking-widest">
                                <th className="px-4 pb-2">Source Artifacts</th>
                                <th className="px-4 pb-2">Resource Cost</th>
                                <th className="px-4 pb-2">Agent Squad</th>
                                <th className="px-4 pb-2 text-right">
                                  Human Reviewer
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {[...approvedPhases]
                                .sort(
                                  (a, b) =>
                                    STAGES.findIndex((s) => s.id === a) -
                                    STAGES.findIndex((s) => s.id === b),
                                )
                                .map((id) => {
                                  const phaseData = config[id];
                                  const linkedSources = phaseData.inputs.filter(
                                    (inp) => inp.source,
                                  );
                                  return (
                                    <tr
                                      key={id}
                                      className="h-14 bg-white/[0.02] hover:bg-white/[0.04] transition-all rounded-2xl"
                                    >
                                      <td className="px-4 rounded-l-2xl">
                                        {linkedSources.length > 0 ? (
                                          <div className="flex flex-col gap-1 max-h-12 overflow-y-auto no-scrollbar py-1">
                                            {linkedSources.map((src, sIdx) => (
                                              <div
                                                key={sIdx}
                                                className="text-[9px] text-emerald-400 font-bold truncate max-w-[150px] underline underline-offset-2 hover:text-emerald-300 transition-colors"
                                                title={src.source.value}
                                              >
                                                {src.source.value
                                                  .split("/")
                                                  .pop()}
                                              </div>
                                            ))}
                                          </div>
                                        ) : (
                                          <span className="text-[9px] text-slate-600 italic">
                                            No docs attached
                                          </span>
                                        )}
                                      </td>
                                      <td className="px-4">
                                        <span className="text-[11px] font-black text-white font-mono tracking-tighter">
                                          $
                                          {(
                                            parseFloat(
                                              calculateTotalCost([id]),
                                            ) - 12.75
                                          ).toFixed(2)}
                                        </span>
                                      </td>
                                      <td className="px-4">
                                        <div className="flex flex-wrap gap-1.5">
                                          {phaseData.selectedAgents.map(
                                            (a, i) => {
                                              const agentCfg = phaseData
                                                .agentConfigs[a]?.[0] || {
                                                model: "GPT-4o",
                                                instances: 1,
                                              };
                                              return (
                                                <div
                                                  key={i}
                                                  className="flex items-center gap-1 px-2 py-0.5 bg-black/40 border border-white/10 rounded-lg"
                                                >
                                                  <span className="text-[8px] font-black text-slate-400">
                                                    {agentCfg.instances}x
                                                  </span>
                                                  <span className="text-[8px] font-black text-white uppercase tracking-tighter">
                                                    {
                                                      agentCfg.model.split(
                                                        " ",
                                                      )[0]
                                                    }
                                                  </span>
                                                </div>
                                              );
                                            },
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-4 rounded-r-2xl text-right">
                                        <span className="text-[9px] font-black text-slate-500 uppercase">
                                          {phaseData.reviewers[0] || "---"}
                                        </span>
                                      </td>
                                    </tr>
                                  );
                                })}
                            </tbody>
                          </table>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                <div className="flex gap-5 pt-6 border-t border-white/5 shrink-0 mt-auto bg-[#0c0c0e]">
                  <button
                    onClick={() => setShowFinalModal(false)}
                    className="px-10 py-4 rounded-2xl bg-white/5 border border-white/10 text-slate-500 text-[12px] font-black uppercase tracking-widest hover:text-white transition-all"
                  >
                    Cancel Engine
                  </button>
                  <button
                    onClick={() => createAndNavigateProject(approvedPhases)}
                    className="flex-1 py-4 rounded-2xl bg-emerald-500 text-black text-[13px] font-black uppercase tracking-[0.2em] hover:bg-emerald-400 transition-all shadow-[0_10px_30px_#10b98133]"
                  >
                    Initialize {projectName || "Neuroas"} Pipeline
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <style
        dangerouslySetInnerHTML={{
          __html: ` 

        .no-scrollbar::-webkit-scrollbar { display: none; } 

        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; } 

      `,
        }}
      />
    </div>
  );
}

function EditableArtefactList({
  title,
  list,
  color,
  type,
  entryMode,
  entryValue,
  setEntryValue,
  onAddClick,
  onConfirm,
  onDelete,
  onToggle,
  repoUrl,
  targetCodeRepo,
  targetDocRepo,
  activeId,
  updateField,
}) {
  const [linkingIdx, setLinkingIdx] = useState(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [tempSource, setTempSource] = useState({ type: "repo", value: "" });

  const [isExploring, setIsExploring] = useState(false);
  const [repoContents, setRepoContents] = useState([]);
  const [currentDir, setCurrentDir] = useState("");
  const [loadingRepo, setLoadingRepo] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const isAdding = entryMode === type;
  const isCompact = list.length > 4;

  const formatPath = (url) => {
    if (!url || typeof url !== "string") return "not-set";
    const repoName = url.split("/").pop().replace(".git", "");
    return `/${repoName}/${activeId}`;
  };

  const localFileInputRef = useRef(null);

  const needs = PHASE_REPO_CONFIG[activeId] || [];

  const fetchRepoFiles = async (path = "") => {
    // 🟢 FORCE use of repoUrl (Source Project Files: cts_training)
    const activeUrl = repoUrl;

    if (!activeUrl) {
      setErrorMessage("No source repository (Project Files) found.");
      return;
    }

    setLoadingRepo(true);
    try {
      const response = await fetch(
        "http://localhost:5000/api/github-explorer",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          // 🟢 This ensures the explorer ONLY looks at the source repo
          body: JSON.stringify({ repoUrl: activeUrl, path }),
        },
      );

      const data = await response.json();
      if (response.ok && Array.isArray(data)) {
        setRepoContents(data);
        setCurrentDir(path);
      } else {
        setErrorMessage(data.error || "Failed to load files.");
      }
    } catch (error) {
      setErrorMessage("Could not connect to backend server.");
    } finally {
      setLoadingRepo(false);
    }
  };
  const attachSource = (idx) => {
    const newList = [...list];
    newList[idx].source = tempSource;
    updateField(type, newList);
    setLinkingIdx(null);
    setTempSource({ type: "repo", value: "" });
  };

  const createWithSource = () => {
    if (!entryValue.trim())
      return alert("Please enter a name for the element.");
    const newItem = {
      text: entryValue.trim(),
      isMandatory: false,
      source: tempSource.value ? tempSource : null,
    };
    updateField(type, [...list, newItem]);
    setEntryValue("");
    setIsCreatingNew(false);
    setTempSource({ type: "repo", value: "" });
  };

  return (
    <div className="flex flex-col gap-3 min-h-0 relative">
      <div className="flex items-center justify-between px-1">
        {/* 🟢 WRAPPER START: This container aligns title and badges horizontally */}
        <div className="flex items-center gap-3">
          <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 whitespace-nowrap">
            {title}
          </h4>
          {/* 🟢 TOP BADGES: Only visible for non-Development phases */}
          {type === "outputs" && activeId !== "p4" && (
            <div className="flex items-center gap-2">
              {needs.includes("code") && (
                <div
                  className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-violet-500/5 border border-violet-500/10 cursor-help"
                  title={formatPath(targetCodeRepo)} // Show full path on hover
                >
                  <HardDrive size={10} className="text-violet-400" />
                  <code className="text-[9px] text-violet-300 font-mono truncate max-w-[120px]">
                    {formatPath(targetCodeRepo)}
                  </code>
                </div>
              )}
              {needs.includes("doc") && (
                <div
                  className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-emerald-500/5 border border-emerald-500/10 cursor-help"
                  title={formatPath(targetDocRepo)} // Show full path on hover
                >
                  <FileUp size={10} className="text-emerald-400" />
                  <code className="text-[9px] text-emerald-300 font-mono truncate max-w-[120px]">
                    {formatPath(targetDocRepo)}
                  </code>
                </div>
              )}
            </div>
          )}
        </div>

        {!isAdding && !isCreatingNew && (
          <button
            onClick={() => {
              setTempSource({ type: "repo", value: "" });
              setEntryValue("");
              setIsCreatingNew(true);
            }}
            className="p-1 hover:bg-white/10 rounded-md text-violet-400"
          >
            <Plus size={14} strokeWidth={3} />
          </button>
        )}
      </div>

      <div className="flex flex-col gap-2 overflow-y-auto pr-1 max-h-[220px] custom-scrollbar no-scrollbar">
        {list.length > 3 ? (
          /* 🟢 GRID VIEW: Shown for all items if total count is > 3 */
          <div className="grid grid-cols-3 gap-2">
            {list.map((item, idx) => (
              <div
                key={idx}
                onClick={() => {
                  if (type === "inputs") {
                    setLinkingIdx(idx);
                    item.source
                      ? setTempSource(item.source)
                      : setTempSource({ type: "repo", value: "" });
                  }
                }}
                className={`flex items-center justify-between bg-[#1a1d24] border rounded-xl p-2 transition-all cursor-pointer relative min-w-0 
                  ${linkingIdx === idx ? "border-violet-500 ring-1 ring-violet-500/20" : "border-white/5"}`}
              >
                <div className="flex items-center gap-1.5 overflow-hidden min-w-0">
                  <div
                    className={`w-0.5 h-2 rounded-full shrink-0 ${color === "emerald" ? "bg-emerald-500" : "bg-violet-500"}`}
                  />
                  <span
                    className={`text-[9px] font-bold truncate ${item.isMandatory || item.isBookmarked ? "text-orange-500" : "text-slate-400"}`}
                  >
                    {item.text}
                  </span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggle(idx);
                  }}
                  className={`shrink-0 ${item.isMandatory || item.isBookmarked ? "text-orange-500" : "text-slate-600"}`}
                >
                  {item.isMandatory || item.isBookmarked ? (
                    <BookmarkCheck size={10} />
                  ) : (
                    <Bookmark size={10} />
                  )}
                </button>

                {!item.isMandatory && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(idx);
                    }}
                    className="text-slate-600 hover:text-rose-500 transition-colors"
                  >
                    <X size={11} />
                  </button>
                )}
                {linkingIdx === idx && (
                  <motion.div
                    layoutId="activePointer"
                    className="absolute -right-2 top-1/2 -translate-y-1/2 z-[110]"
                  >
                    <div className="w-0 h-0 border-t-[4px] border-t-transparent border-b-[4px] border-b-transparent border-r-[6px] border-r-violet-500" />
                  </motion.div>
                )}
              </div>
            ))}
          </div>
        ) : (
          /* 🟢 LIST VIEW: Shown if 3 or fewer items exist */
          list.map((item, idx) => (
            <div
              key={idx}
              onClick={() => {
                if (type === "inputs") {
                  setLinkingIdx(idx);
                  item.source
                    ? setTempSource(item.source)
                    : setTempSource({ type: "repo", value: "" });
                }
              }}
              className={`flex items-center justify-between bg-[#1a1d24] border rounded-xl p-3 w-full group transition-all cursor-pointer relative 
                ${linkingIdx === idx ? "border-violet-500 ring-1 ring-violet-500/20" : "border-white/5"}`}
            >
              <div className="flex items-center gap-2 overflow-hidden flex-1">
                <div
                  className={`w-1 h-3 rounded-full shrink-0 ${color === "emerald" ? "bg-emerald-500" : "bg-violet-500"}`}
                />

                <span
                  className={`text-[11px] font-bold truncate ${item.isMandatory || item.isBookmarked ? "text-orange-500" : "text-slate-300"}`}
                >
                  {item.text}
                </span>

                {/* 🟢 DEVELOPMENT SPECIFIC: Now shows shortened repo name instead of static "Code" */}
                {activeId === "p4" &&
                  type === "outputs" &&
                  (item.text.toLowerCase().includes("code") ||
                    item.text.toLowerCase().includes("test")) && (
                    <div className="ml-auto mr-2 shrink-0">
                      <div
                        className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-violet-500/10 border border-violet-500/20 cursor-help"
                        title={formatPath(targetCodeRepo)} // 🟢 Native tooltip for the full path
                      >
                        <HardDrive size={8} className="text-violet-400" />
                        <span className="text-[7px] text-violet-300 font-mono uppercase tracking-tighter truncate max-w-[80px]">
                          {formatPath(targetCodeRepo)}
                        </span>
                      </div>
                    </div>
                  )}

                {/* 🟢 Status Indicators */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {type === "inputs" && !item.source && (
                    <AlertCircle
                      size={14}
                      className="text-rose-500 animate-pulse"
                    />
                  )}
                  {item.source && (
                    <LinkIcon size={10} className="text-emerald-500" />
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggle(idx);
                  }}
                  className={`${item.isMandatory || item.isBookmarked ? "text-orange-500" : "text-slate-600 hover:text-orange-400"}`}
                >
                  {item.isMandatory || item.isBookmarked ? (
                    <BookmarkCheck size={14} />
                  ) : (
                    <Bookmark size={14} />
                  )}
                </button>
                {!item.isMandatory && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(idx);
                    }}
                    className="text-slate-600 hover:text-rose-500"
                  >
                    <X size={13} />
                  </button>
                )}
              </div>

              {linkingIdx === idx && (
                <motion.div
                  layoutId="activePointer"
                  className="absolute -right-3 top-1/2 -translate-y-1/2 z-[110]"
                >
                  <div className="w-0 h-0 border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent border-r-[8px] border-r-violet-500" />
                </motion.div>
              )}
            </div>
          ))
        )}
      </div>

      <AnimatePresence>
        {(linkingIdx !== null || isCreatingNew) && (
          <motion.div
            // 🟢 Update 1: Animation direction based on type
            initial={{
              opacity: 0,
              scale: 0.95,
              x: type === "outputs" ? -20 : 20,
            }}
            animate={{ opacity: 1, scale: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.95, x: type === "outputs" ? -20 : 20 }}
            // 🟢 Update 2: CSS Alignment
            // right-[103%] for Deliverables (outputs) pushes the modal to the LEFT
            // left-[103%] for Inputs pushes the modal to the RIGHT
            className={`absolute top-0 z-[100] w-[350px] bg-[#0c0c0e] rounded-3xl border border-violet-500/40 p-6 flex flex-col gap-4 shadow-[0_30px_60px_rgba(0,0,0,0.9)] 
              ${type === "outputs" ? "right-[0%]" : "left-[103%]"}`}
          >
            <div className="flex justify-between items-center relative z-10">
              <div className="flex flex-col gap-0.5">
                <span className="text-[10px] font-black uppercase tracking-widest text-violet-400">
                  {isExploring
                    ? "File Explorer"
                    : isCreatingNew
                      ? "Configure New Element"
                      : "Link Source"}
                </span>
                {/* 🟢 Update 3: Dynamic title name logic remains intact */}
                {linkingIdx !== null && (
                  <span className="text-[11px] text-white font-bold truncate max-w-[240px]">
                    {list[linkingIdx]?.text}
                  </span>
                )}
              </div>
              <X
                size={16}
                className="cursor-pointer text-slate-500 hover:text-white"
                onClick={() => {
                  setLinkingIdx(null);
                  setIsCreatingNew(false);
                  setIsExploring(false);
                }}
              />
            </div>

            {/* --- Remaining content (Tabs, GitHub logic, Label Input) stays exactly as provided in your prompt --- */}
            {!isExploring ? (
              <>
                <div className="grid grid-cols-3 gap-2 relative z-10">
                  {["repo", "file", "text"].map((m) => (
                    <button
                      key={m}
                      onClick={() => setTempSource({ ...tempSource, type: m })}
                      className={`py-2 text-[8px] font-black uppercase rounded-lg border transition-all ${tempSource.type === m ? "bg-violet-600 border-violet-400 text-white" : "bg-black border-white/5 text-slate-500"}`}
                    >
                      {m}
                    </button>
                  ))}
                </div>

                <div className="flex flex-col gap-2 bg-black/40 p-4 rounded-xl border border-white/5 relative z-10">
                  {tempSource.type === "repo" ? (
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[7px] text-slate-500 uppercase truncate max-w-[150px]">
                          Base: {repoUrl || "Not Set"}
                        </span>
                        <button
                          onClick={() => {
                            setIsExploring(true);
                            fetchRepoFiles("");
                          }}
                          className="text-[8px] font-bold text-violet-400 hover:text-violet-300 underline"
                        >
                          EXPLORE REPO
                        </button>
                      </div>
                      <input
                        className="bg-black border border-white/10 rounded-lg p-2 text-[11px] text-white outline-none"
                        placeholder="Path to file..."
                        value={tempSource.value}
                        readOnly
                      />
                    </div>
                  ) : tempSource.type === "file" ? (
                    <div
                      className="flex flex-col items-center justify-center gap-3 py-6 border-2 border-white/10 rounded-xl hover:border-violet-500/40 transition-all cursor-pointer bg-black/20"
                      onClick={() => localFileInputRef.current?.click()}
                    >
                      <FileUp size={24} className="text-violet-400" />
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] font-bold text-white uppercase tracking-tight">
                          {tempSource.value
                            ? tempSource.value
                            : "Select Local File"}
                        </span>
                        <span className="text-[8px] text-slate-500 uppercase mt-1">
                          Click to browse system
                        </span>
                      </div>
                      <input
                        type="file"
                        ref={localFileInputRef}
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files[0];
                          if (file) {
                            setTempSource({ ...tempSource, value: file.name });
                          }
                        }}
                      />
                    </div>
                  ) : (
                    <textarea
                      className="h-24 bg-black border border-white/10 rounded-lg p-2 text-[11px] text-white outline-none resize-none"
                      placeholder="Enter manually..."
                      value={tempSource.value}
                      onChange={(e) =>
                        setTempSource({ ...tempSource, value: e.target.value })
                      }
                    />
                  )}
                </div>

                {isCreatingNew && (
                  <div className="flex flex-col gap-1.5 pt-1 border-t border-white/5 relative z-10">
                    <label className="text-[8px] font-black uppercase text-slate-500 px-1">
                      Element Label
                    </label>
                    <input
                      autoFocus
                      value={entryValue}
                      onChange={(e) => setEntryValue(e.target.value)}
                      placeholder="e.g. BRD Document..."
                      className="bg-black border border-violet-500/30 rounded-lg p-2 text-[11px] text-white outline-none"
                    />
                  </div>
                )}

                <button
                  onClick={() =>
                    isCreatingNew
                      ? createWithSource()
                      : attachSource(linkingIdx)
                  }
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase shadow-lg transition-all"
                >
                  {isCreatingNew ? "Create Element" : "Update Source"}
                </button>
              </>
            ) : (
              <div className="flex flex-col gap-4 relative z-10">
                <button
                  onClick={() => setIsExploring(false)}
                  className="text-[10px] text-violet-400 text-left"
                >
                  ← Back
                </button>
                <div className="bg-black border border-white/10 rounded-xl max-h-[250px] overflow-y-auto custom-scrollbar">
                  {loadingRepo ? (
                    <div className="p-10 text-center text-slate-500 text-[10px] animate-pulse">
                      Connecting to GitHub...
                    </div>
                  ) : errorMessage ? (
                    <div className="p-10 text-center text-rose-500 text-[10px] leading-relaxed">
                      {errorMessage}
                    </div>
                  ) : (
                    <>
                      {currentDir && (
                        <div
                          onClick={() =>
                            fetchRepoFiles(
                              currentDir.split("/").slice(0, -1).join("/"),
                            )
                          }
                          className="p-3 text-[10px] text-violet-400 border-b border-white/5 cursor-pointer hover:bg-white/5"
                        >
                          📁 .. (Back)
                        </div>
                      )}
                      {repoContents.map((file) => (
                        <div
                          key={file.sha}
                          onClick={() => {
                            if (file.type === "dir") fetchRepoFiles(file.path);
                            else {
                              setTempSource({
                                ...tempSource,
                                value: file.path,
                              });
                              setIsExploring(false);
                            }
                          }}
                          className="p-3 text-[10px] text-slate-300 hover:bg-violet-500/20 cursor-pointer border-b border-white/5 last:border-0 flex items-center gap-2"
                        >
                          {file.type === "dir" ? "📁" : "📄"} {file.name}
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}