import React, { useState, useMemo, useEffect } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { 
  ArrowLeft, Lock, Play, Layout, Cpu, Users, Beaker,
  CheckCircle2, Layers, Settings, Database, RefreshCcw, ChevronLeft,
  Terminal, FileText, Upload, Edit2, Pause, SkipForward, RotateCcw, StopCircle
} from "lucide-react";

import NodeGates from "./Gates/NodeGates";
import PipelineCanvas from "./Tabs/PipelineTab";
import RequirementsTab from "./Tabs/RequirementsTab";
import ArtifactsTab from "./Tabs/ArtifactsTab";
import EventsTab from "./Tabs/EventsTab";
import GatesTab from "./Tabs/GatesTab";
import MetricsTab from "./Tabs/MetricsTab";

// --- YOUR GIVEN CODE (CANVAS) ---

const STAGE_DATA = {
  G1: { input: "Product Vision", output: "User Stories / Backlog" },
  G2: { input: "Backlog", output: "Sprint Schedule / Tasks" },
  G3: { input: "Requirements", output: "System Design / Schema" },
  G4: { input: "Architecture", output: "UI Mockups / Prototypes" },
  G5: { input: "Mockups", output: "Source Code / Unit Tests" },
  G6: { input: "Source Code", output: "Approved PRs / Logic Fixes" },
  G7: { input: "Build", output: "Bug Reports / QA Sign-off" },
  G8: { input: "Codebase", output: "Vulnerability Scan / SSL" },
  G9: { input: "Staging App", output: "Client Approval / Live" },
  G10: { input: "Live App", output: "Production Release" },
};
 
const SETUP_STAGES = [
  { id: "G1", label: "Requirements", x: 80, y: 150, status: "approved" },
  { id: "G2", label: "Planning", x: 240, y: 250, status: "approved" }, // Shifted Right
  { id: "G3", label: "Architecture", x: 400, y: 150, status: "approved" }, // Shifted Right
];

const SPRINT_STAGES = [
  { id: "G4", label: "Design", x: 580, y: 320, status: "approved" }, // Moved Down to clear Backlog
  { id: "G5", label: "Development", x: 850, y: 320, type: "parallel" }, // Moved Down
  { id: "G6", label: "Unit Testing", x: 1100, y: 320 }, // Moved Down
  { id: "G7", label: "System Testing", x: 1250, y: 150 }, // Shifted Right
];

const FINAL_STAGES = [
  { id: "G8", label: "NFR Testing", x: 1400, y: 250 },
  { id: "G9", label: "UAT", x: 1550, y: 150 },
  { id: "G10", label: "Deployment", x: 1700, y: 250 },
];
// Note: SETUP_STAGES, SPRINT_STAGES, FINAL_STAGES and STAGE_DATA assumed to be in scope or imported

export default function ProjectDetails({ project: propProject, onBack, onUpdateProject}) {
  const [activeTab, setActiveTab] = useState('Pipeline');
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const { projectId, gateId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (gateId) {
      setSelectedNodeId(gateId);
    } else {
      setSelectedNodeId(null);
    }
  }, [gateId]);

  const handleCloseGate = () => {
    setSelectedNodeId(null);
    navigate(`/project/${projectId}`); // 🟢 Clear the review path from URL
  };

  const project = useMemo(() => {
    if (propProject) return propProject;
    if (location.state?.project) return location.state.project;
    
    const saved = JSON.parse(localStorage.getItem("projects") || "[]");
    return saved.find(p => p.id.toString() === projectId);
  }, [propProject, projectId, location.state]);

 {/* const syncedSetup = useMemo(() => SETUP_STAGES.map(s => ({
    ...s,
    status: project?.stages?.find(ps => ps.id === s.id)?.state || 'pending'
  })), [project]);

  const syncedSprint = useMemo(() => SPRINT_STAGES.map(s => ({
    ...s,
    status: project?.stages?.find(ps => ps.id === s.id)?.state || 'pending'
  })), [project]);

  const syncedFinal = useMemo(() => FINAL_STAGES.map(s => ({
    ...s,
    status: project?.stages?.find(ps => ps.id === s.id)?.state || 'pending'
  })), [project]); */}

  // Handlers

  const handleApprove = (nodeId) => {
    const currentIndex = project.stages.findIndex(s => s.id === nodeId);
    if (currentIndex === -1) return;
    const updatedStages = [...project.stages];
    updatedStages[currentIndex].state = 'approved';
    if (currentIndex + 1 < updatedStages.length) updatedStages[currentIndex + 1].state = 'executing';
    onUpdateProject({ ...project, stages: updatedStages });
    setSelectedNodeId(null);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'Pipeline':
        return (
        /* Use justify-between and remove overflow-hidden to ensure the bar can be seen */
        <div className="flex flex-col items-center justify-between h-full animate-in fade-in duration-700 overflow-visible">
          <PipelineCanvas onNodeClick={(id) => {
            setSelectedNodeId(id);
          }} />
          <PipelineControlBar project={project} />
        </div>
      );
      // case 'Requirements':
      // return (
      //   <RequirementsTab 
      //     project={project} 
      //     onRerunStage={(gateId) => {
      //       setSelectedNodeId(gateId); 
      //     }} 
      //   />
      // );
      case 'Artifacts':
        return <ArtifactsTab project={project} />;
      case 'Events':
        return <EventsTab project={project} />;
      case 'Gates':
        return <GatesTab project={project} />;
      case 'Metrics':
        return <MetricsTab project={project} />;
      default: return null;
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#09090b] overflow-hidden relative animate-in fade-in duration-500">

      {/* 2. TABS NAVIGATION */}
      <div className="px-8 mt-4 shrink-0 relative z-30 bg-[#09090b]">
        <div className="flex gap-8 border-b border-zinc-800">
          {['Pipeline', 'Artifacts', 'Events', 'Gates', 'Metrics'].map(tab => (
            <button 
              key={tab} 
              onClick={() => setActiveTab(tab)} 
              className={`pb-2 text-[11px] font-black uppercase tracking-widest transition-all relative ${activeTab === tab ? 'text-violet-400' : 'text-zinc-500 hover:text-zinc-300'}`}
            >
              {tab}
              {activeTab === tab && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-violet-500 shadow-[0_0_10px_rgba(139,92,246,0.5)]" />}
            </button>
          ))}
        </div>
      </div>

      {/* 1. HEADER AREA */}
      {/* <header className="h-16 border-b border-zinc-800/50 bg-[#09090b]/50 backdrop-blur-md px-8 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-500 hover:text-white transition-all"> <ArrowLeft size={18} /> </button>
          <div className="flex items-center gap-3">
            <h1 className="text-lg font-bold tracking-tight text-white">{project?.name || "Project Details"}</h1>
            {/* <span className="px-2 py-0.5 rounded text-[9px] font-black bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-widest">Active Pod</span>
          </div>
        </div>
      </header> */}

      {/* 3. CONTENT WRAPPER */}
      <div className="flex flex-col overflow-y-auto custom-scrollbar relative mt-1 px-4 pb-2 z-10">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-500 hover:text-white transition-all"> <ArrowLeft size={18} /> </button>
          <div className="flex items-center gap-3">
            <h1 className="text-lg font-bold tracking-tight text-white">{project?.name || "Project Details"}</h1>
          </div>
        </div>
          {renderTabContent()}
      </div>

      {/* 🟢 Overlay logic triggered by the URL state */}
      {selectedNodeId && (
        <NodeGates 
          nodeId={selectedNodeId} 
          project={project} 
          onUpdateProject={onUpdateProject} 
          onApprove={handleApprove} 
          onClose={handleCloseGate} 
        />
      )}

      {selectedNodeId && <NodeGates nodeId={selectedNodeId} project={project} onUpdateProject={onUpdateProject} onApprove={handleApprove} onClose={() => setSelectedNodeId(null)} />}
    </div>
  );
}



// --- PASTE YOUR PipelineCanvas, GateNode, and AgentNode code here ---
function GateNode({ stage, status, onClick, data }) {
    const isApproved = status === "approved";
    const isGate = status === "gate_pending";
    const theme = isApproved ? "bg-emerald-500/10 border-emerald-500 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]" : isGate ? "bg-violet-500/10 border-violet-500 text-violet-400 animate-pulse" : "bg-white/5 border-white text-white shadow-[0_0_15px_rgba(255,255,255,0.2)]";
   
    return (
      <div onClick={onClick} className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center transition-all cursor-pointer group relative hover:scale-110 active:scale-95 bg-black z-20 ${theme}`}>
          {isApproved ? <CheckCircle2 size={24} /> : isGate ? <Lock size={20} /> : <Play size={20} />}
         
          {/* TOOLTIP ON HOVER */}
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-y-2 group-hover:translate-y-0 z-50">
             <div className="bg-zinc-900/90 border border-white/20 rounded-xl p-3 shadow-2xl min-w-[180px] backdrop-blur-xl">
                <div className="flex flex-col gap-2">
                    <div className="flex flex-col">
                        <span className="text-[7px] font-black text-white/40 uppercase">Input</span>
                        <span className="text-[10px] text-white font-bold">{data?.input}</span>
                    </div>
                    <div className="h-px bg-white/10" />
                    <div className="flex flex-col">
                        <span className="text-[7px] font-black text-white/40 uppercase">Output</span>
                        <span className="text-[10px] text-blue-400 font-bold">{data?.output}</span>
                    </div>
                </div>
                <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-zinc-900 border-r border-b border-white/20 rotate-45 -translate-y-1" />
             </div>
          </div>
 
          <div className="absolute -bottom-10 flex flex-col items-center">
              <span className={`text-[9px] font-black uppercase tracking-[0.2em] whitespace-nowrap ${isApproved ? "text-emerald-400" : isGate ? "text-violet-400" : "text-white"}`}>
                  {stage.label}
              </span>
          </div>
      </div>
    );
}
 
function AgentNode({ icon, label, status, color }) {
    // 🟢 Dynamic Theme Logic
    const getTheme = () => {
        switch(color) {
            case "amber":
                return "text-amber-400 border-amber-500/40 bg-amber-500/10 shadow-[0_0_20px_rgba(245,158,11,0.15)]";
            case "emerald":
                return "text-emerald-400 border-emerald-500/30 bg-emerald-500/10 shadow-[0_0_20px_rgba(16,185,129,0.15)]";
            case "white":
            default:
                // 🟢 Inactive "Whited Out" Style
                return "text-white border-white bg-zinc-900/50 shadow-none opacity-80";
        }
    };

    return (
        <div className={`flex items-center gap-2 px-3 py-1.5 border-2 rounded-xl backdrop-blur-xl min-w-[130px] group relative transition-all duration-500 ${getTheme()}`}>
            {icon}
            <div className="flex flex-col">
                <span className={`text-[9px] font-bold ${color === 'white' ? 'text-zinc-400' : 'text-white'}`}>{label}</span>
                <span className="text-[7px] font-black uppercase tracking-widest opacity-80">{status}</span>
            </div>
            
            {/* 🟢 Pulse dot only appears if not whited out */}
            {color !== "white" && (
                <div className={`ml-auto w-1 h-1 rounded-full animate-pulse ${color === 'amber' ? 'bg-amber-400 shadow-[0_0_10px_#f59e0b]' : 'bg-emerald-400'}`} />
            )}
 
            {/* AGENT HOVER TASK */}
            <div className="absolute left-full ml-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 -translate-x-2 group-hover:translate-x-0 z-50">
             <div className="bg-zinc-900 border border-white/10 rounded-lg p-2 shadow-2xl min-w-[140px] backdrop-blur-md">
                <span className="text-[8px] text-white font-bold whitespace-nowrap">Agent status: {status}</span>
             </div>
          </div>
        </div>
    );
}

// --- PIPELINE CONTROL BAR (FLOATING PANEL) ---
function PipelineControlBar({ project }) { //-mt-12
  return (
    <div className="flex items-center gap-4 bg-[#111114]/90 backdrop-blur-xl border border-zinc-700 py-2 px-6 rounded-full max-w-4xl mx-auto mt-12 shadow-2xl relative z-20 shrink-0 mb-6"> 
      <div className="pr-2 border-r border-zinc-800 flex items-center gap-3">
        <div className="relative flex items-center justify-center shrink-0">
          <div className="w-2 h-2 rounded-full bg-violet-400 animate-ping absolute" />
          <div className="w-2 h-2 rounded-full bg-violet-400 relative z-10" />
        </div>
        <div className="flex flex-col min-w-[120px]">
          <span className="text-[7px] font-black uppercase text-zinc-400 tracking-[0.2em] leading-none mb-1">Engine State</span>
          <span className="text-[10px] font-bold text-zinc-100 uppercase tracking-tight leading-none">Sprint 1: Dev</span>
        </div>
      </div>
      
      <div className="flex-1 flex justify-center gap-1">
        <ControlButton icon={Pause} label="Pause" />
        <ControlButton icon={RotateCcw} label="Re-run" />
        <ControlButton icon={StopCircle} label="End" variant="danger" />
      </div>

      <div className="pl-6 border-l border-zinc-800 flex items-center gap-6">
         <ToggleControl label="Auto" active={true} />
      </div>
    </div>
  );
}

// --- HELPER UI COMPONENTS ---
function ControlButton({ icon: Icon, label, variant }) {
  const isDanger = variant === 'danger';
  return (
    <button className="group flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all hover:bg-zinc-800 active:scale-95">
      <div className={`p-1.5 rounded-lg transition-colors ${isDanger ? 'text-red-500' : 'text-zinc-400 group-hover:text-violet-400'}`}>
        <Icon size={18} />
      </div>
      <span className="text-[8px] font-black uppercase tracking-widest text-zinc-500 group-hover:text-zinc-300">{label}</span>
    </button>
  );
}

function ToggleControl({ label, active }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex flex-col items-end">
        <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest leading-none">{label}</span>
        <span className="text-[7px] font-bold text-violet-500/60 mt-0.5">{active ? 'ON' : 'OFF'}</span>
      </div>
      <div className={`w-8 h-4 rounded-full relative cursor-pointer transition-all duration-300 p-0.5 ${active ? 'bg-violet-600' : 'bg-zinc-800'}`}>
        <div className={`w-3 h-3 bg-white rounded-full shadow-lg transition-all transform ${active ? 'translate-x-4' : 'translate-x-0'}`} />
      </div>
    </div>
  );
}