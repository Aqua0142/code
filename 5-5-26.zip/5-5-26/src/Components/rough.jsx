import React, { useState, useRef, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck, Settings, Cpu, Layout, Code,
  Activity, Rocket, UserCheck, ChevronLeft, Check,
  Zap, Wand2
} from "lucide-react";

// --- CONSTANTS ---
const STAGES = [
  { id: "p1", label: "Requirement", icon: ShieldCheck },
  { id: "p2", label: "Planning", icon: Settings },
  { id: "p3", label: "Architecture", icon: Cpu },
  { id: "p4", label: "Design", icon: Layout },
  { id: "p5", label: "Development", icon: Code },
  { id: "p6", label: "Testing", icon: Activity },
  { id: "p7", label: "NFR Testing", icon: ShieldCheck },
  { id: "p8", label: "UAT", icon: UserCheck },
  { id: "p9", label: "Deployment", icon: Rocket },
];

// Split stages into two rows: 5 + 4
const ROW_ONE = STAGES.slice(0, 5); // Requirement to Development
const ROW_TWO = STAGES.slice(5, 9); // Testing to Deployment

const PHASE_METADATA = {
  p1: { role: "Product Owner", desc: "Translates high-level project goals into actionable user stories.", inputs: ["Business Rules", "Domain Context"], outputs: ["Prioritized Backlog", "NFR Table"] },
  p2: { role: "Project Manager", desc: "Organizes the backlog into a logical execution timeline.", inputs: ["Prioritized Backlog", "Team Velocity"], outputs: ["Sprint Plan", "Dependency Graph"] },
  p3: { role: "Solution Architect", desc: "Defines system structural integrity and tech stack patterns.", inputs: ["User Stories", "Infrastructure Goals"], outputs: ["Tech Stack Rationale", "API Contracts"] },
  p4: { role: "UI/UX Designer", desc: "Crafts visual language and user experience guidelines.", inputs: ["User Stories", "Brand Guidelines"], outputs: ["Design Tokens", "UI Specifications"] },
  p5: { role: "Full-Stack Team", desc: "Translates blueprints into production-ready source code.", inputs: ["API Contracts", "UI Specifications"], outputs: ["Integrated Source Code", "Logic Modules"] },
  p6: { role: "Tester", desc: "Analyzes code for logical errors and adherence to standards.", inputs: ["Source Code", "Security Patterns"], outputs: ["Quality Score", "Approved PRs"] },
  p7: { role: "QA & Security", desc: "Validates performance and security against benchmarks.", inputs: ["Source Code", "Security Benchmarks"], outputs: ["Vulnerability Scan", "Load Test Reports"] },
  p8: { role: "Stakeholder", desc: "Confirms software meets business expectations.", inputs: ["Verified Build", "Business Rules"], outputs: ["Final Sign-off", "Verification Matrix"] },
  p9: { role: "DevOps Engineer", desc: "Prepares the system for production release.", inputs: ["Final Code", "Architecture Doc"], outputs: ["Live Build", "README / API Docs"] },
};

export default function PhaseSelection() {
  const navigate = useNavigate();
  const location = useLocation();
  const mainContentRef = useRef(null);

  const [projectDraft, setProjectDraft] = useState(() => {
    if (location.state?.draft) return location.state.draft;
    const saved = sessionStorage.getItem("latest_project_setup");
    try {
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  const [approved, setApproved] = useState(() => {
    return projectDraft?.selectedPhaseIds || [];
  });

  const [hoverData, setHoverData] = useState(null);
  const [activeTemplate, setActiveTemplate] = useState(null);

  useEffect(() => {
    if (projectDraft) {
      const updatedDraft = { ...projectDraft, selectedPhaseIds: approved };
      sessionStorage.setItem("latest_project_setup", JSON.stringify(updatedDraft));
    }
  }, [approved, projectDraft]);

  useEffect(() => {
    if (!projectDraft) {
      navigate("/setup");
    }
  }, [projectDraft, navigate]);

  const togglePhase = (id) => {
    setApproved(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
    setActiveTemplate(null);
  };

  const toggleTemplate = (type) => {
    if (activeTemplate === type) {
      setApproved([]);
      setActiveTemplate(null);
    } else {
      const selection = type === 'mvp' ? ['p1', 'p4', 'p5', 'p9'] : STAGES.map(s => s.id);
      setApproved(selection);
      setActiveTemplate(type);
    }
  };

  const handleConfirmLifecycle = () => {
    const finalizedProject = {
      ...projectDraft,
      selectedPhaseIds: approved,
      status: 'Running'
    };

    navigate("/agent-selection", { state: { draft: finalizedProject } });
  };

  return (
    <div className="flex h-screen w-full bg-[#050506] text-white font-sans overflow-hidden flex-col relative">
      {/* HEADER */}
      <header className="h-24 flex items-center justify-between px-20 border-b border-white/5 bg-[#050506]/50 backdrop-blur-xl z-50 shrink-0">
        <div className="flex items-center gap-6">
          <button onClick={() => navigate(-1)} className="p-2.5 hover:bg-violet-500/10 rounded-xl text-zinc-500 border border-zinc-800 transition-all active:scale-95">
            <ChevronLeft size={24} />
          </button>
          <div className="flex flex-col">
            <h1 className="text-xl font-black tracking-tighter uppercase italic leading-none">Architecture Studio</h1>
            <span className="text-[9px] font-bold text-violet-500 uppercase tracking-[0.3em] mt-1">Pod Lifecycle Configuration</span>
          </div>
        </div>

        <div className="flex items-center gap-8">
            <div className="flex flex-col items-end border-r border-zinc-800 pr-8 text-zinc-500 uppercase font-black text-[9px]">
              Active Draft: <span className="text-sm text-zinc-200 lowercase mt-1">{projectDraft?.projectName || "New Project"}</span>
            </div>
            <div className="text-3xl font-black text-violet-400">{approved.length}<span className="text-zinc-700">/{STAGES.length}</span></div>
        </div>
      </header>

      {/* Template buttons */}
      <div className="absolute top-28 left-20 flex gap-3 z-40">
          <TemplateButton label="MVP" isActive={activeTemplate === 'mvp'} icon={<Zap size={12}/>} onClick={() => toggleTemplate('mvp')} />
          <TemplateButton label="FULL SDLC" isActive={activeTemplate === 'full'} icon={<Wand2 size={12}/>} onClick={() => toggleTemplate('full')} />
      </div>

      {/* MAIN CONTENT - TWO ROW GRID */}
      <main
        ref={mainContentRef}
        className="flex-1 flex flex-col relative overflow-hidden bg-[radial-gradient(#ffffff03_1px,transparent_1px)] [background-size:40px_40px]"
      >
        <div className="flex-1 flex items-center justify-center px-16 relative">
            <div className="flex flex-col gap-16 relative z-10">
              {/* Row 1: Planning Phases */}
              <div className="flex items-center justify-center gap-12 relative">
                <div className="absolute inset-0 flex items-center justify-between px-[60px]">
                  {ROW_ONE.slice(0, -1).map((_, i) => (
                    <div key={i} className="flex-1 h-[2px] bg-gradient-to-r from-violet-500/30 to-transparent" 
                         style={{ marginLeft: i === 0 ? '40px' : '0', marginRight: '40px' }} />
                  ))}
                </div>
                {ROW_ONE.map((stage) => (
                  <div
                    key={stage.id}
                    className="relative"
                    onMouseEnter={(e) => setHoverData({ id: stage.id, rect: e.currentTarget.getBoundingClientRect() })}
                    onMouseLeave={() => setHoverData(null)}
                  >
                    <PhaseBox data={stage} isSelected={approved.includes(stage.id)} onClick={() => togglePhase(stage.id)} />
                  </div>
                ))}
              </div>

              {/* Row 2: Execution & Testing Phases */}
              <div className="flex items-center justify-center gap-12 relative">
                <div className="absolute inset-0 flex items-center justify-between px-[60px]">
                  {ROW_TWO.slice(0, -1).map((_, i) => (
                    <div key={i} className="flex-1 h-[2px] bg-gradient-to-r from-violet-500/30 to-transparent" 
                         style={{ marginLeft: i === 0 ? '40px' : '0', marginRight: '40px' }} />
                  ))}
                </div>
                {ROW_TWO.map((stage) => (
                  <div
                    key={stage.id}
                    className="relative"
                    onMouseEnter={(e) => setHoverData({ id: stage.id, rect: e.currentTarget.getBoundingClientRect() })}
                    onMouseLeave={() => setHoverData(null)}
                  >
                    <PhaseBox data={stage} isSelected={approved.includes(stage.id)} onClick={() => togglePhase(stage.id)} />
                  </div>
                ))}
              </div>
            </div>
        </div>

        <AnimatePresence>
          {hoverData && (
            <SmartCard
              id={hoverData.id}
              rect={hoverData.rect}
              meta={PHASE_METADATA[hoverData.id]}
              label={STAGES.find(s => s.id === hoverData.id)?.label}
              containerRef={mainContentRef}
            />
          )}
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="h-24 p-8 px-20 flex justify-end gap-5 items-center bg-[#08080a] border-t border-white/5 z-50">
        <button onClick={() => { setApproved([]); setActiveTemplate(null); }} className="px-8 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-[10px] font-black uppercase text-zinc-500 hover:text-white transition-all">Reset Selection</button>
        <button
          onClick={handleConfirmLifecycle}
          disabled={approved.length === 0}
          className={`px-12 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 ${
            approved.length > 0
            ? "bg-violet-600 text-white shadow-lg shadow-violet-600/20 hover:bg-violet-500"
            : "bg-zinc-800 text-zinc-500 cursor-not-allowed"
          }`}
        >
          Next
        </button>
      </footer>
    </div>
  );
}

// --- SUB-COMPONENTS ---

function SmartCard({ id, rect, meta, label, containerRef }) {
  const containerRect = containerRef?.current?.getBoundingClientRect() || { left: 0, right: window.innerWidth };
  const cardWidth = 320;
  let preferredLeft = rect.left + (rect.width / 2) - (cardWidth / 2);
  const minLeft = containerRect.left + 20;
  const maxLeft = containerRect.right - cardWidth - 20;
  const finalLeft = Math.max(minLeft, Math.min(preferredLeft, maxLeft));

  return (
    <motion.div
      initial={{ opacity: 0, y: 5, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 5, scale: 0.98 }}
      style={{ position: 'fixed', top: rect.top - 155, left: finalLeft, width: cardWidth }}
      className="p-3 bg-[#0d0d0f]/f8 border border-violet-500/30 rounded-2xl backdrop-blur-xl z-[100] shadow-[0_20px_50px_rgba(0,0,0,0.8)] pointer-events-none"
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
           <div className="w-1 h-3 bg-violet-500 rounded-full" />
           <h4 className="text-[10px] font-black uppercase tracking-widest text-white leading-none">{label}</h4>
        </div>
        <span className="text-[7px] font-black text-violet-400 bg-violet-500/10 px-1.5 py-0.5 rounded border border-violet-500/20 uppercase tracking-tighter">{meta?.role}</span>
      </div>
      <p className="text-[9px] text-zinc-400 leading-tight mb-2.5 opacity-80">{meta?.desc}</p>
      <div className="flex items-start gap-4 pt-2 border-t border-white/5">
        <div className="flex-1">
          <span className="text-[6px] uppercase text-zinc-600 font-black tracking-widest block mb-1.5">Input</span>
          <div className="flex flex-col gap-1">
            {meta?.inputs.map((inp, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <div className="h-0.5 w-0.5 rounded-full bg-violet-600/50" />
                <span className="text-[8.5px] text-zinc-300 font-bold leading-none">{inp}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="flex-1 border-l border-white/5 pl-4">
          <span className="text-[6px] uppercase text-zinc-600 font-black tracking-widest block mb-1.5">Output</span>
          <div className="flex flex-col gap-1">
            {meta?.outputs.map((out, i) => (
              <div key={i} className="flex items-center gap-1.5">
                <Check size={7} className="text-violet-500" strokeWidth={5} />
                <span className="text-[8.5px] text-violet-400 font-black leading-none">{out}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="absolute top-full border-[6px] border-transparent border-t-[#0d0d0f] transition-all duration-200"
        style={{ left: rect.left + (rect.width / 2) - finalLeft, transform: 'translateX(-50%)' }}
      />
    </motion.div>
  );
}

function TemplateButton({ label, icon, onClick, isActive }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-3 px-4 py-2 rounded-xl border transition-all active:scale-95 group ${isActive ? "bg-violet-600 border-violet-400 shadow-lg shadow-violet-600/20" : "bg-zinc-900 border-white/5 hover:border-violet-500/50"}`}>
      <span className={isActive ? "text-white" : "text-zinc-500 group-hover:text-violet-400"}>{icon}</span>
      <span className={`text-[10px] font-black uppercase tracking-tight ${isActive ? "text-white" : "text-zinc-400 group-hover:text-white"}`}>{label}</span>
      {isActive && <Check size={12} className="text-white ml-1" />}
    </button>
  );
}

function PhaseBox({ data, isSelected, onClick }) {
  const Icon = data.icon;
  return (
    <div className="flex flex-col items-center gap-6 relative group">
      <motion.div
        onClick={onClick} 
        whileHover={{ scale: 1.15, borderColor: "rgba(139, 92, 246, 0.8)", borderWidth: "4px" }} 
        whileTap={{ scale: 0.95 }}
        animate={{ 
          scale: isSelected ? 1.1 : 1, 
          borderColor: isSelected ? "#8b5cf6" : "rgba(255,255,255,0.1)", 
          backgroundColor: isSelected ? "rgba(139, 92, 246, 0.1)" : "rgba(5, 5, 6, 1)", 
          borderWidth: isSelected ? "4px" : "2px" 
        }}
        transition={{ type: "spring", stiffness: 400, damping: 25 }}
        className="w-20 h-20 rounded-[2.2rem] border-2 flex items-center justify-center relative cursor-pointer"
        style={{ boxShadow: isSelected ? "0 0 50px rgba(139,92,246,0.2)" : "none" }}
      >
        <Icon size={34} className={`transition-all duration-300 ${isSelected ? "text-violet-400 scale-110" : "text-zinc-500 group-hover:text-violet-300"}`} />
        <AnimatePresence>
          {isSelected && (
            <motion.div 
              initial={{ scale: 0, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              exit={{ scale: 0, opacity: 0 }}
              className="absolute -top-1 -right-1 w-7 h-7 bg-emerald-500 rounded-full border-4 border-[#050506] flex items-center justify-center shadow-lg z-20"
            >
              <Check size={16} strokeWidth={4} className="text-white" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
      <span className={`font-black uppercase tracking-[0.2em] text-[10px] whitespace-nowrap transition-colors duration-200 ${isSelected ? 'text-violet-400' : 'text-zinc-700'}`}>
        {data.label}
      </span>
    </div>
  );
}


import React, { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldCheck, Settings, Cpu, Layout, Code, Activity, Rocket,
  UserCheck, ChevronLeft, Check, Plus, Info, ArrowRight, Minus, Server, Zap,
  Trash2, Sparkles, Bookmark, BookmarkCheck, Bot, Lock, Shield, Calendar,
  Link as LinkIcon, FileUp, FolderTree, Globe, UserPlus, X, PencilLine, HardDrive
} from "lucide-react";
 
// --- CONSTANTS ---
const ICON_BASE_URL = "https://raw.githubusercontent.com/Aqua0142/agent-icons/main";
const ICON_MAP = {
  'Product Owner': 'Product Owner.png',
  'Project Manager': 'Project Manager.png',
  'Solution Architect': 'Architecture.png',
  'UI/UX Designer': 'Designer.png',
  'Frontend Developer': 'FE.png',
  'Backend Developer': 'BE.png',
  'Database Engineer': 'DB.png',
  'System Testing': 'System Testing.png',
  'Integration Testing': 'SIT.png',
  'Performance testing': 'NFR_Tester.png',
  'UAT Agent': 'UAT.png',
  'DevOps Engineer': 'DevOps.png',
  'Technical Writer': 'UAT.png',
  'SAGE': 'UAT.png',
  'default': 'UAT.png'
};
 
 
const MODEL_DATA = {
  'GPT-4o': { cost: '12.50', color: 'text-emerald-400' },
  'GPT-5 (Flagship)': { cost: '11.25', color: 'text-emerald-400' },
  'Claude Sonnet 4.6': { cost: '18.00', color: 'text-orange-400' },
  'Claude Opus 4.6': { cost: '30.00', color: 'text-orange-400' },
  'Gemini 3 Pro': { cost: '14', color: 'text-blue-400' },
  'Llama 3.1': { cost: '3.30', color: 'text-purple-400' }
};
const MODEL_LIST = Object.keys(MODEL_DATA);
 
const AGENT_MAPPING = {
  p1: [{ name: 'Product Owner' }],
  p2: [{ name: 'Project Manager' }],
  p3: [{ name: 'Solution Architect' }],
  p4: [{ name: 'Frontend Developer' }, { name: 'Backend Developer' }, { name: 'Database Engineer' }],
  p5: [{ name: 'System Testing' }, { name: 'Integration Testing' }],
  p6: [{ name: 'Performance testing' }],
  p7: [{ name: 'UAT Agent' }],
  p8: [{ name: 'DevOps Engineer' }],
};
 
const MANDATORY_AGENTS = [
    { name: 'Technical Writer' },
    { name: 'SAGE' }
];
 
const STAGES = [
  { id: "p1", label: "Requirement", icon: ShieldCheck },
  { id: "p2", label: "Planning", icon: Settings },
  { id: "p3", label: "Architecture", icon: Cpu },
  { id: "p4", label: "Development", icon: Code },
  { id: "p5", label: "Testing", icon: Activity },
  { id: "p6", label: "NFR Testing", icon: ShieldCheck },
  { id: "p7", label: "UAT", icon: UserCheck },
  { id: "p8", label: "Deployment", icon: Rocket },
];
 
const STAGE_IO_DEFAULTS = {
  p1: { inputs: [{ text: "Problem Statement", isMandatory: true }, { text: "Business Intent", isMandatory: false }], outputs: [{ text: "BRD Document", isMandatory: true }, { text: "User Stories Document", isMandatory: true }, { text: "NFR Table", isMandatory: true }] },
  p2: { inputs: [{ text: "User Stories Document", isMandatory: true }, { text: "NFR Tabel", isMandatory: true }], outputs: [{ text: "Sprint Plan", isMandatory: true }, { text: "Dependency Graph", isMandatory: true }, { text: "Risk Mitigation Plan", isMandatory: false }] },
  p3: { inputs: [{ text: "BRD & NFR Document", isMandatory: true }, { text: "Functional Specs", isMandatory: true }, { text: "Sprint Plan & Dependency Graph", isMandatory: false }], outputs: [{ text: "Technology Stack", isMandatory: true }, { text: "System Design Diagram", isMandatory: true }, { text: "API Contract", isMandatory: true }] },
  p4: { inputs: [{ text: "Technology Stack", isMandatory: true }, { text: "API Contract", isMandatory: true }, { text: "Design Specification", isMandatory: false }], outputs: [{ text: "Source Code", isMandatory: true }, { text: "Unit Test Results", isMandatory: true }, { text: "Internal Documentation", isMandatory: false }] },
  p5: { inputs: [{ text: "Source Code", isMandatory: true }, { text: "Test Plan", isMandatory: true }], outputs: [{ text: "Test Reports", isMandatory: true }, { text: "Bug Report", isMandatory: true }] },
  p6: { inputs: [{ text: "Verified Code", isMandatory: true }, { text: "BRD & NFR Document", isMandatory: true }, { text: "Compliance Standards", isMandatory: false }], outputs: [{ text: "Performance Report", isMandatory: true }, { text: "Security Audit Log", isMandatory: true }, { text: "Optimization Guide", isMandatory: false }] },
  p7: { inputs: [{ text: "BRD Document", isMandatory: true }, { text: "Acceptance Criteria", isMandatory: true }, { text: "Verified Code", isMandatory: true }], outputs: [{ text: "UAT Sign-off", isMandatory: true }, { text: "UAT Summary", isMandatory: false }, ] },
  p8: { inputs: [{ text: "Software Artifacts", isMandatory: true }, { text: "Test Report", isMandatory: true }, { text: "Rollback Plan", isMandatory: true }], outputs: [{ text: "Live Environment URL", isMandatory: true }, { text: "Deployment Log", isMandatory: true }] }
};
 
export default function PhaseStudio() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [currentStep, setCurrentStep] = useState(0);
 
  const [config, setConfig] = useState(() => {
    const initial = {};
    STAGES.forEach(s => {
      const ioDefaults = STAGE_IO_DEFAULTS[s.id] || { inputs: [], outputs: [] };
      initial[s.id] = {
        inputs: ioDefaults.inputs,
        outputs: ioDefaults.outputs,
        context: "",
        reviewers: [],
        assets: [],
        agentConfigs: {},
        selectedAgents: AGENT_MAPPING[s.id]?.map(a => a.name) || [],
        requirements: { compliance: [] },
        planning: { sprints: 1, points: 0, duration: 2 },
        development: { environment: 'Cloud' },
        testing: { env: 'Staging' }
      };
 
      // FIX: Initialize configs for BOTH stage agents and mandatory agents to prevent selection errors
      const allPossibleAgents = [
        ...(AGENT_MAPPING[s.id] || []),
        { name: 'Technical Writer' },
        { name: 'SAGE' }
      ];
 
      allPossibleAgents.forEach(a => {
        initial[s.id].agentConfigs[a.name] = [{ model: 'GPT-4o', instances: 1 }];
      });
    });
    return initial;
  });
 
  const [approvedPhases, setApprovedPhases] = useState([]);
  const [entryMode, setEntryMode] = useState(null);
  const [entryValue, setEntryValue] = useState("");
  const [urlInput, setUrlInput] = useState("");
  const [focusedAgent, setFocusedAgent] = useState(null);
 
  const activeId = STAGES[currentStep].id;
  const activeLabel = STAGES[currentStep].label;
  const activeData = config[activeId];
  const currentPath = `/root/env-production/${activeLabel.toLowerCase().replace(/\s+/g, '-')}`;
 
  const isPhaseSelected = approvedPhases.includes(activeId);
  const isPhaseFilled = activeData.reviewers.length > 0;
 
  const updateField = (field, value) => {
    setConfig(prev => ({ ...prev, [activeId]: { ...prev[activeId], [field]: value } }));
  };
 
  const addItemToList = (type) => {
    if (!entryValue.trim()) return;
    const newItem = { text: entryValue.trim(), isMandatory: false };
    updateField(type, [...activeData[type], newItem]);
    setEntryValue(""); setEntryMode(null);
  };
 
  const togglePhaseSelection = () => {
    if (isPhaseSelected) {
      setApprovedPhases(prev => prev.filter(id => id !== activeId));
    } else {
      setApprovedPhases(prev => [...new Set([...prev, activeId])]);
    }
  };
 
  const toggleAgentSelection = (agentName) => {
    const currentSelected = activeData.selectedAgents;
    if (currentSelected.includes(agentName)) {
      if (currentSelected.length <= 1) return;
      updateField('selectedAgents', currentSelected.filter(a => a !== agentName));
    } else {
      updateField('selectedAgents', [...currentSelected, agentName]);
    }
  };
 
  const updateAgentSetting = (agentName, key, value) => {
    const newConfigs = { ...activeData.agentConfigs };
    if (!newConfigs[agentName]) {
        newConfigs[agentName] = [{ model: 'GPT-4o', instances: 1 }];
    }
    newConfigs[agentName][0][key] = value;
    updateField('agentConfigs', newConfigs);
  };
 
  const validateCurrentPhase = () => {
    if (activeData.reviewers.length === 0) {
      return { valid: false, msg: "At least one Human Reviewer must be assigned." };
    }
    if (activeId === 'p2') {
      const { sprints, duration } = activeData.planning;
      if (!sprints || sprints <= 0 || !duration || duration <= 0) {
        return { valid: false, msg: "Sprint Count and Duration are mandatory." };
      }
    }
    if (activeId === 'p4') {
      if (!activeData.development.environment || !activeData.development.tech) {
        return { valid: false, msg: "Hosting Environment and Container Tech are mandatory." };
      }
    }
    if (['p5', 'p6', 'p7', 'p8'].includes(activeId)) {
      if (!activeData.testing?.env) {
        return { valid: false, msg: "Target Environment selection is required." };
      }
    }
    return { valid: true };
  };
 
  const handleSaveNext = () => {
    if (!isPhaseSelected) setApprovedPhases(prev => [...new Set([...prev, activeId])]);
    if (currentStep < STAGES.length - 1) setCurrentStep(prev => prev + 1);
  };
 
  const handleSkip = () => {
    if (currentStep < STAGES.length - 1) setCurrentStep(prev => prev + 1);
  };
 
  const handleStartPipeline = () => {
    if (!isPhaseFilled) return;
    navigate("/agent-selection", { state: { draft: config, approvedPhases } });
  };
 
  const renderPhaseSpecificFields = () => {
    switch(activeId) {
      case 'p1':
        return (
          <div className="space-y-3 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2"><Shield size={12}/> Compliance Standards</label>
            <div className="grid grid-cols-2 gap-2">
              {['HIPAA', 'SOC2', 'GDPR', 'PCI-DSS'].map(std => (
                <button
                  key={std}
                  onClick={() => {
                    const current = activeData.requirements.compliance;
                    const next = current.includes(std) ? current.filter(c => c !== std) : [...current, std];
                    updateField('requirements', { ...activeData.requirements, compliance: next });
                  }}
                  className={`px-3 py-2 rounded-lg text-[10px] font-bold border transition-all ${activeData.requirements.compliance.includes(std) ? 'bg-violet-500/20 border-violet-500 text-white' : 'bg-black/20 border-white/5 text-slate-500 hover:border-white/20'}`}
                >
                  {std}
                </button>
              ))}
            </div>
          </div>
        );
      case 'p2':
        return (
          <div className="space-y-4 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2"><Calendar size={12}/> Sprint Configuration <span className="text-[10px] text-rose-500">*</span></label>
            <div className="space-y-3">
               {[{l: 'Number of Sprints', k: 'sprints'}, {l: 'Points / Sprint', k: 'points'}, {l: 'Duration (Weeks)', k: 'duration'}].map(item => (
                 <div key={item.k} className="flex justify-between items-center bg-black/20 p-2 rounded-xl">
                    <span className="text-[10px] text-slate-400 font-bold">{item.l}</span>
                    <input
                      type="number"
                      placeholder="0"
                      className="bg-transparent text-right w-12 outline-none text-white font-mono text-xs placeholder:text-slate-600"
                      value={activeData.planning[item.k]}
                      onChange={(e) => updateField('planning', {...activeData.planning, [item.k]: e.target.value})}
                    />
                 </div>
               ))}
            </div>
          </div>
        );
      case 'p4':
        return (
          <div className="space-y-4 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2"><Server size={12}/> Hosting Infrastructure <span className="text-[10px] text-rose-500">*</span></label>
            <div className="space-y-3">
              <select
                className="w-full bg-black/40 border border-white/10 rounded-xl p-2.5 text-[10px] font-bold text-white outline-none focus:border-violet-500/50 transition-all"
                value={activeData.development.environment || ""}
                onChange={(e) => updateField('development', {...activeData.development, environment: e.target.value})}
              >
                <option value="" disabled hidden>Select Infrastructure...</option>
                <option value="Local (Windows)">Local (Windows)</option>
                <option value="Local (Linux)">Local (Linux)</option>
                <option value="Cloud (AWS/GCP)">Cloud (AWS/GCP)</option>
                <option value="Virtual Environment">Virtual Environment</option>
                <option value="Docker">Docker</option>
                <option value="Kubernetes">Kubernetes</option>
              </select>
            </div>
          </div>
        );
      case 'p5': case 'p6': case 'p7': case 'p8':
        return (
          <div className="space-y-3 p-4 bg-white/5 rounded-2xl border border-white/5">
            <label className="text-[9px] font-black uppercase text-violet-400 flex items-center gap-2"><Zap size={12}/> Target Environment <span className="text-[10px] text-rose-500">*</span></label>
            <select
                className="w-full bg-black/40 border border-white/10 rounded-xl p-2.5 text-[10px] font-bold text-white outline-none focus:border-violet-500/50 transition-all"
                value={activeData.testing?.env || ""}
                onChange={(e) => updateField('testing', {env: e.target.value})}
              >
                <option value="" disabled hidden>Select Environment...</option>
                <option value="Sandbox">Sandbox</option>
                <option value="QA Testing">QA Testing</option>
                <option value="Staging">Staging</option>
                <option value="UAT-Mirror">UAT-Mirror</option>
                <option value="Production">Production</option>
              </select>
          </div>
        );
      default: return null;
    }
  };
 
  return (
    <div className="flex h-screen w-full bg-[#0f1115] text-slate-100 font-sans overflow-hidden flex-col">
      <div className="h-24 border-b border-white/5 bg-[#161920] flex items-center px-12 shadow-2xl z-20 shrink-0">
        <div className="flex items-center justify-between w-full max-w-7xl mx-auto">
          {STAGES.map((stage, idx) => (
            <React.Fragment key={stage.id}>
              <div className="flex flex-col items-center gap-2 cursor-pointer group" onClick={() => {setCurrentStep(idx); setFocusedAgent(null);}}>
                <div className={`w-9 h-9 rounded-lg border-2 flex items-center justify-center transition-all ${
                  currentStep === idx ? "border-violet-500 bg-violet-500/20 text-white shadow-[0_0_15px_rgba(139,92,246,0.3)]" :
                  approvedPhases.includes(stage.id) ? "border-emerald-500 bg-emerald-500/10 text-emerald-400" : "border-slate-800 bg-slate-900/50 text-slate-600"
                }`}>
                  {approvedPhases.includes(stage.id) ? <Check size={18} strokeWidth={3} /> : <stage.icon size={20} />}
                </div>
                <span className={`text-[9px] font-black uppercase tracking-widest ${currentStep === idx ? "text-violet-400" : "text-slate-600"}`}>{stage.label}</span>
              </div>
              {idx !== STAGES.length - 1 && <div className={`flex-1 h-[1px] mx-4 rounded-full ${approvedPhases.includes(STAGES[idx].id) ? "bg-emerald-500/50" : "bg-slate-800"}`} />}
            </React.Fragment>
          ))}
        </div>
      </div>
 
      <main className="flex-1 flex px-12 py-6 gap-8 overflow-hidden bg-[radial-gradient(#ffffff03_1px,transparent_1px)] [background-size:40px_40px]">
        <div className="flex-1 flex flex-col gap-6 overflow-y-auto no-scrollbar pr-4 custom-scrollbar">
          <div className="flex items-center justify-between shrink-0">
            <div className="flex flex-col">
              <h1 className="text-2xl font-black uppercase tracking-tighter text-white flex items-center gap-3">
                {activeLabel} Phase <Sparkles size={24} className="text-violet-500 animate-pulse" />
              </h1>
            </div>
 
            <div className="flex items-center gap-4 bg-white/5 px-6 py-3 rounded-3xl border border-white/20">
                <span className={`text-[10px] font-black uppercase tracking-widest transition-colors ${isPhaseSelected ? 'text-emerald-400' : 'text-slate-300'}`}>
                    {isPhaseSelected ? "Phase Selected" : "Select Phase "}
                </span>
                <div
                    onClick={togglePhaseSelection}
                    className={`relative w-14 h-7 rounded-full cursor-pointer transition-all duration-300 p-1 ${
                        isPhaseSelected ? "bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.3)]" : "bg-slate-700"
                    }`}
                >
                    <motion.div
                        animate={{ x: isPhaseSelected ? 28 : 0 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        className="w-5 h-5 bg-white rounded-full shadow-lg flex items-center justify-center"
                    >
                        {isPhaseSelected ? <Check size={12} className="text-emerald-600" strokeWidth={4} /> : <X size={12} className="text-slate-400" strokeWidth={4} />}
                    </motion.div>
                </div>
            </div>
          </div>
 
          <div className="grid grid-cols-2 gap-6">
            <EditableArtefactList
              title="Phase Inputs" list={activeData.inputs} color="violet" type="inputs"
              entryMode={entryMode} entryValue={entryValue} setEntryValue={setEntryValue}
              onAddClick={() => setEntryMode('inputs')}
              onConfirm={() => addItemToList('inputs')}
              onDelete={(idx) => updateField('inputs', activeData.inputs.filter((_, i) => i !== idx))}
              onToggle={(idx) => {
                const newList = [...activeData.inputs];
                if (newList[idx].isMandatory && newList.filter(i => i.isMandatory).length <= 1) return;
                newList[idx].isMandatory = !newList[idx].isMandatory;
                updateField('inputs', newList);
              }}
            />
            <EditableArtefactList
                title="Phase Deliverables" list={activeData.outputs} color="emerald" type="outputs"
                entryMode={entryMode} entryValue={entryValue} setEntryValue={setEntryValue}
                onAddClick={() => setEntryMode('outputs')}
                onConfirm={() => addItemToList('outputs')}
                onDelete={(idx) => updateField('outputs', activeData.outputs.filter((_, i) => i !== idx))}
                onToggle={(idx) => {
                    const newList = [...activeData.outputs];
                    newList[idx].isMandatory = !newList[idx].isMandatory;
                    updateField('outputs', newList);
                }}
            />
          </div>
 
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-4 bg-[#1a1d24] border border-white/5 rounded-2xl p-4 shadow-lg">
              <div className="p-2 bg-violet-500/10 rounded-lg text-violet-400"><FolderTree size={16} /></div>
              <div className="flex flex-col">
                <span className="text-[10px] py-1 font-black uppercase text-slate-500 tracking-[0.2em]">Output Directory</span>
                <code className="text-xs text-emerald-400 font-mono">{currentPath}</code>
              </div>
            </div>
 
            <div className="flex flex-col gap-4 bg-[#08080a] border border-white/10 rounded-3xl p-6 shadow-2xl relative min-h-[300px]">
              <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-emerald-500/40 to-transparent" />
                <div className="flex items-center justify-between border-b border-white/5 pb-4">
                    <div className="flex items-center gap-3">
                        <Bot size={20} className="text-emerald-500" />
                        <label className="text-[11px] font-black uppercase tracking-[0.2em] text-emerald-400">Agent Selection Pool</label>
                    </div>
                </div>
               
                <div className="grid grid-cols-4 gap-x-8 gap-y-12 py-4 relative">
                    {[...(AGENT_MAPPING[activeId] || []), { name: 'Technical Writer', isMandatory: true }, { name: 'SAGE', isMandatory: true }].map((agent, index) => {
                        const isMandatory = agent.isMandatory;
                        const isSelected = isMandatory ? true : activeData.selectedAgents.includes(agent.name);
                        const isFocused = focusedAgent === agent.name;
                        const agentConfig = activeData.agentConfigs[agent.name]?.[0] || { model: 'GPT-4o', instances: 1 };
                       
                        // FIX: Detect if agent is on the right side of the grid to flip the popup inward
                        const isLastInRow = (index + 1) % 4 === 0;
 
                        return (
                            <div key={agent.name} className={`relative flex flex-col items-center ${isFocused ? 'z-50' : 'z-10'}`}>
                                <div
                                    onClick={() => !isMandatory && toggleAgentSelection(agent.name)}
                                    className={`relative group cursor-pointer transition-all duration-300 ${isFocused ? 'scale-110' : 'scale-100'}`}
                                >
                                    <div className={`w-20 h-20 rounded-[1.8rem] border-2 flex items-center justify-center relative transition-all duration-500
                                        ${isSelected
                                            ? (isMandatory ? 'bg-black border-amber-500/60 shadow-[0_0_20px_rgba(245,158,11,0.2)]' : 'bg-black border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.2)]')
                                            : 'bg-zinc-900/40 border-white/5 hover:border-white/20'}`}>
                                        <img
                                          src={`${ICON_BASE_URL}/${encodeURIComponent(ICON_MAP[agent.name] || ICON_MAP['default'])}`} alt={agent.name}
                                          className={`w-16 h-16 transition-all ${isSelected ? 'opacity-100' : 'opacity-50 grayscale group-hover:grayscale-0'}`}  
                                          onError={(e) => e.target.src = `${ICON_BASE_URL}/UAT.png`}
                                        />
                                       
                                        {isSelected && (
                                            <>
                                                <button
                                                    onClick={(e) => { e.stopPropagation(); setFocusedAgent(isFocused ? null : agent.name); }}
                                                    className={`absolute -bottom-1 -left-1 w-7 h-7 rounded-xl border-2 border-black text-white flex items-center justify-center z-10 transition-colors ${isMandatory ? 'bg-amber-600 hover:bg-amber-500' : 'bg-emerald-600 hover:bg-emerald-500'}`}
                                                >
                                                    <Settings size={14} className={isFocused ? 'rotate-90' : ''} />
                                                </button>
                                                {!isMandatory && (
                                                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-emerald-600 rounded-full border-2 border-black flex items-center justify-center z-10">
                                                        <span className="text-[10px] font-black">{agentConfig.instances}</span>
                                                    </div>
                                                )}
                                                {isMandatory && (
                                                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-amber-600 rounded-full border-2 border-black flex items-center justify-center z-10">
                                                        <Lock size={10} />
                                                    </div>
                                                )}
                                            </>
                                        )}
                                    </div>
                                    <span className={`mt-3 text-[9px] font-black uppercase tracking-tighter text-center block ${isSelected ? (isMandatory ? 'text-amber-500' : 'text-white') : 'text-zinc-600'}`}>
                                        {agent.name}
                                    </span>
                                </div>
 
                                <AnimatePresence>
                                  {isFocused && (
                                    <motion.div
                                      initial={{ opacity: 0, x: isLastInRow ? 10 : -10 }}
                                      animate={{ opacity: 1, x: 0 }}
                                      exit={{ opacity: 0, scale: 0.9, x: isLastInRow ? 10 : -10 }}
                                      // FIX: Smart alignment to prevent cutoff by right sidebar
                                      className={`absolute top-0 z-[100] w-[220px] border rounded-2xl p-4 shadow-2xl backdrop-blur-md
                                        ${isLastInRow ? 'right-[110%]' : 'left-[110%]'}
                                        ${isMandatory ? 'bg-[#0e0a05] border-amber-500/30' : 'bg-[#0c0c0e] border-emerald-500/30'}`}
                                    >
                                      {/* Indicator Arrow */}
                                      <div className={`absolute top-8 w-3 h-3 rotate-45 border-l border-b
                                        ${isLastInRow ? '-right-[6px] rotate-[225deg]' : '-left-[6px]'}
                                        ${isMandatory ? 'bg-[#0e0a05] border-amber-500/30' : 'bg-[#0c0c0e] border-emerald-500/30'}`}
                                      />
                                
                                      <div className="relative space-y-4">
                                        {agent.name === 'Technical Writer' ? (
                                          <div className="space-y-3">
                                            <span className="text-[7px] font-black uppercase text-amber-500 tracking-[0.3em] block text-center">Documentation Engine</span>
                                            <select
                                              value={agentConfig.model}
                                              onChange={(e) => {e.stopPropagation(); updateAgentSetting(agent.name, 'model', e.target.value)}}
                                              className="w-full bg-black border border-white/10 rounded-lg py-2 px-2 text-[9px] font-black uppercase outline-none text-amber-400"
                                            >
                                              {MODEL_LIST.map(m => <option key={m} value={m}>{m}</option>)}
                                            </select>
                                            <div className="flex justify-between items-center px-1">
                                              <span className="text-[8px] text-zinc-500 uppercase font-bold">Est. Cost</span>
                                              <span className="text-[10px] text-amber-400 font-mono font-bold">${MODEL_DATA[agentConfig.model]?.cost}/hr</span>
                                            </div>
                                          </div>
                                        ) : agent.name === 'SAGE' ? (
                                          <div className="space-y-3">
                                            <span className="text-[7px] font-black uppercase text-rose-500 tracking-[0.3em] block text-center">Security Firewall</span>
                                            <div className="grid grid-cols-1 gap-2">
                                              <div className="bg-black/40 border border-white/5 p-2 rounded-lg flex justify-between items-center">
                                                <span className="text-[6px] text-zinc-500 uppercase">Encryption</span>
                                                <span className="text-[7px] text-white font-bold uppercase">AES-256</span>
                                              </div>
                                              <div className="bg-black/40 border border-white/5 p-2 rounded-lg flex justify-between items-center">
                                                <span className="text-[6px] text-zinc-500 uppercase">Pattern</span>
                                                <span className="text-[7px] text-emerald-500 font-bold uppercase">Active</span>
                                              </div>
                                            </div>
                                          </div>
                                        ) : (
                                          <>
                                            <div className="space-y-2">
                                              <span className="text-[8px] font-black uppercase text-zinc-500 tracking-widest block">Agent Count</span>
                                              <div className="flex items-center justify-between bg-black rounded-lg p-1 border border-white/5">
                                                <button onClick={(e) => {e.stopPropagation(); updateAgentSetting(agent.name, 'instances', Math.max(1, agentConfig.instances - 1))}} className="p-1 hover:text-emerald-400 transition-colors"><Minus size={12}/></button>
                                                <span className="text-sm font-black font-mono text-white">{agentConfig.instances}</span>
                                                <button onClick={(e) => {e.stopPropagation(); updateAgentSetting(agent.name, 'instances', agentConfig.instances + 1)}} className="p-1 hover:text-emerald-400 transition-colors"><Plus size={12}/></button>
                                              </div>
                                            </div>
                                
                                            <div className="space-y-2 pt-2 border-t border-white/5">
                                              <div className="flex justify-between items-end mb-1">
                                                <span className="text-[8px] font-black uppercase text-zinc-500 tracking-widest">Model & Cost</span>
                                                <span className="text-[10px] text-emerald-400 font-mono font-bold">${MODEL_DATA[agentConfig.model]?.cost}</span>
                                              </div>
                                              <select
                                                value={agentConfig.model}
                                                onChange={(e) => {e.stopPropagation(); updateAgentSetting(agent.name, 'model', e.target.value)}}
                                                className="w-full bg-[#121214] border border-white/10 rounded-lg py-2 px-2 text-[9px] font-black uppercase outline-none text-emerald-400 focus:border-emerald-500/50 transition-all"
                                              >
                                                {MODEL_LIST.map(m => <option key={m} value={m}>{m}</option>)}
                                              </select>
                                            </div>
                                          </>
                                        )}
                                      </div>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                            </div>
                        );
                    })}
                </div>
            </div>
          </div>
        </div>
 
        <div className="w-[320px] flex flex-col gap-6 shrink-0 overflow-y-auto no-scrollbar custom-scrollbar pr-1">
          <div className="flex flex-col gap-4 bg-gradient-to-br from-[#1a1d24] to-[#161920] border border-violet-500/20 rounded-3xl p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex flex-col">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-violet-400">Human Reviewer</label>
                <span className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">Assign members</span>
              </div>
              <button onClick={() => setEntryMode(entryMode === 'reviewers' ? null : 'reviewers')} className="p-1.5 rounded-lg bg-violet-600 text-white"><UserPlus size={16} /></button>
            </div>
           
            <div className="flex flex-col gap-2 max-h-[140px] overflow-y-auto no-scrollbar">
              <AnimatePresence>
                {entryMode === 'reviewers' && (
                  <motion.form initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} onSubmit={(e) => {
                    e.preventDefault(); if(!entryValue) return;
                    updateField('reviewers', [...activeData.reviewers, entryValue]);
                    setEntryValue(""); setEntryMode(null);
                  }} className="mb-1">
                    <input autoFocus value={entryValue} onChange={(e) => setEntryValue(e.target.value)} placeholder="Enter Name or Emp ID..." className="w-full bg-black border border-violet-500/50 rounded-xl py-2 px-3 text-xs outline-none text-white font-bold" />
                  </motion.form>
                )}
              </AnimatePresence>
              {activeData.reviewers.map((name, i) => (
                <div key={i} className="flex items-center justify-between bg-white/[0.03] border border-white/5 px-3 py-2 rounded-xl group hover:border-violet-500/30">
                  <span className="text-xs font-bold text-slate-200">{name}</span>
                  <button onClick={() => updateField('reviewers', activeData.reviewers.filter((_, idx) => idx !== i))} className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-500 transition-all"><Trash2 size={12} /></button>
                </div>
              ))}
            </div>
          </div>
 
          {renderPhaseSpecificFields()}
 
          <div className="bg-[#1a1d24] border border-white/10 rounded-3xl p-5 shadow-2xl flex flex-col gap-5">
              <div className="flex flex-col gap-3">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 flex items-center gap-2 px-1"><PencilLine size={14} className="text-violet-500" /> Instructions</label>
                  <textarea value={activeData.context} onChange={(e) => updateField('context', e.target.value)} placeholder="Define phase-specific guidelines..." className="h-20 bg-black/40 border border-white/5 rounded-xl p-3 text-xs text-slate-300 outline-none focus:border-violet-500/50 transition-all resize-none" />
              </div>
              <div className="flex flex-col gap-3">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 flex items-center gap-2 px-1"><LinkIcon size={14} className="text-violet-500" />Upload Inputs </label>
                  <div className="flex flex-col gap-2">
                      <div className="flex items-center bg-black/40 border border-white/5 rounded-xl px-3 py-2">
                          <Globe size={14} className="text-slate-600 mr-2" />
                          <input type="text" placeholder="Add source link" className="bg-transparent text-[11px] w-full outline-none text-slate-200" value={urlInput} onChange={(e) => setUrlInput(e.target.value)} />
                          <button onClick={() => { if(!urlInput) return; updateField('assets', [...activeData.assets, { type: 'link', value: urlInput }]); setUrlInput(""); }} className="ml-2 text-violet-400 hover:text-white"><Plus size={16} /></button>
                      </div>
                      <button onClick={() => fileInputRef.current.click()} className="w-full py-2 bg-slate-800 hover:bg-slate-700 border border-white/5 rounded-xl text-slate-300 text-[11px] font-bold flex items-center justify-center gap-2"><FileUp size={14} /> Attach File</button>
                      <input type="file" ref={fileInputRef} className="hidden" onChange={(e) => e.target.files[0] && updateField('assets', [...activeData.assets, { type: 'file', value: e.target.files[0].name }])} />
                  </div>
              </div>
          </div>
        </div>
      </main>
 
      <footer className="h-20 border-t border-white/5 bg-[#161920] flex items-center justify-between px-12 z-30 shrink-0">
        <button onClick={() => navigate(-1)} className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-600 hover:text-white transition-colors flex items-center gap-3"><ChevronLeft size={16} /> Back</button>
        <div className="flex items-center gap-4">
          <button
            onClick={handleSaveNext}
            className={`px-10 py-3 rounded-xl text-[11px] font-black uppercase transition-all flex items-center gap-3 ${
              isPhaseFilled ? "bg-violet-600 text-white shadow-violet-900/20" : "bg-slate-800 text-slate-400"
            }`}
          >
            {isPhaseFilled ? "Save & Next" : "Skip Phase"}
            <ArrowRight size={16} />
          </button>
 
          <button
            onClick={handleStartPipeline}
            disabled={!isPhaseFilled}
            className={`px-10 py-3 rounded-xl text-[11px] font-black uppercase transition-all flex items-center gap-3 ${
              isPhaseFilled ? "bg-emerald-600 text-white shadow-emerald-900/20" : "bg-slate-900 text-slate-600 grayscale opacity-50"
            }`}
          >
            Start Pipeline <Rocket size={16} />
          </button>
        </div>
      </footer>
 
      <style dangerouslySetInnerHTML={{ __html: `
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />
    </div>
  );
}
 
function EditableArtefactList({ title, list, color, type, entryMode, entryValue, setEntryValue, onAddClick, onConfirm, onDelete, onToggle }) {
  const isAdding = entryMode === type;
  return (
    <div className="flex flex-col gap-3">
      <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 px-1">{title}</h4>
      <div className="space-y-2">
        {list.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between bg-[#1a1d24] border border-white/5 rounded-2xl p-4 group transition-all">
            <div className="flex items-center gap-4 overflow-hidden">
              <div className={`w-1 h-5 rounded-full ${color === 'emerald' ? 'bg-emerald-500' : 'bg-violet-500'}`} />
              <span className={`text-[12px] font-bold truncate ${item.isMandatory ? 'text-amber-400' : 'text-slate-300'}`}>{item.text}</span>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all">
              <button onClick={() => onToggle(idx)} className={`p-2 rounded-xl ${item.isMandatory ? 'text-amber-500 bg-amber-500/10' : 'text-slate-700 hover:text-slate-300'}`}>
                {item.isMandatory ? <BookmarkCheck size={16} /> : <Bookmark size={16} />}
              </button>
              {!item.isMandatory && <button onClick={() => onDelete(idx)} className="p-2 text-slate-700 hover:text-rose-500"><Trash2 size={16} /></button>}
            </div>
          </div>
        ))}
        {isAdding ? (
          <form onSubmit={(e) => { e.preventDefault(); onConfirm(); }} className="relative">
            <input
              autoFocus
              value={entryValue}
              onChange={(e) => setEntryValue(e.target.value)}
              placeholder="New element..."
              className="w-full bg-black border border-violet-500/50 rounded-xl py-3 px-4 text-xs outline-none text-white pr-10"
            />
            <button type="submit" className="absolute right-3 top-2.5 text-violet-400"><Check size={18}/></button>
          </form>
        ) : (
          <button onClick={onAddClick} className="w-full py-3 border border-dashed border-slate-800 rounded-2xl flex items-center justify-center gap-2 text-slate-500 hover:text-violet-400 transition-all bg-white/[0.01]">
            <Plus size={16}/> <span className="text-[10px] font-black uppercase tracking-widest">add</span>
          </button>
        )}
      </div>
    </div>
  );
}
 