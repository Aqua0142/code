// import React, { useState, useEffect } from 'react';
// import { useLocation, useNavigate } from 'react-router-dom';
// import { motion, AnimatePresence } from 'framer-motion';
// import {
//   Plus, Minus, ChevronLeft, Settings, Cpu, 
//   Monitor, Zap, Users, Lock, ShieldCheck, Database, Bot, Activity
// } from 'lucide-react';

// // --- CONFIGURATION CONSTANTS ---
// const PHASE_NAME_MAP = {
//     p1: 'Requirement', p2: 'Planning', p3: 'Architecture', p4: 'Design',
//     p5: 'Development', p6: 'Testing', p7: 'NFR Testing', p8: 'UAT', p9: 'Deployment'
// };

// const AGENT_MAPPING = {
//   p1: [{ name: 'Product Owner' }],
//   p2: [{ name: 'Project Manager' }],
//   p3: [{ name: 'Solution Architect' }],
//   p4: [{ name: 'UI/UX Designer' }],
//   p5: [
//     { name: 'Frontend Developer' },
//     { name: 'Backend Developer' },
//     { name: 'Database Engineer' }
//   ],
//   p6: [{ name: 'System Testing' }, { name: 'Integration Testing' }],
//   p7: [{ name: 'Performance testing' }],
//   p8: [{ name: 'UAT Agent' }],
//   p9: [{ name: 'DevOps Engineer' }],
// };

// const MANDATORY_AGENTS = [
//     { name: 'Doc Maker' },
//     { name: 'SAGE' }
// ];

// const MODEL_DATA = {
//   'GPT-4o': { cost: '12.50', color: 'text-emerald-400' },
//   'GPT-5 (Flagship)': { cost: '11.25', color: 'text-emerald-400' },
//   'Claude Sonnet 4.6': { cost: '18.00', color: 'text-orange-400' },
//   'Claude Opus 4.6': { cost: '30.00', color: 'text-orange-400' },
//   'Gemini 3 Pro': { cost: '14', color: 'text-blue-400' },
//   'Llama 3.1': { cost: '3.30', color: 'text-purple-400' }
// };
// const MODEL_LIST = Object.keys(MODEL_DATA);

// const ICON_BASE_URL = "https://raw.githubusercontent.com/Aqua0142/agent-icons/main";
// const ICON_MAP = {
//   'Product Owner': 'Product Owner.png',
//   'Project Manager': 'Project Manager.png',
//   'Solution Architect': 'Architecture.png',
//   'UI/UX Designer': 'Designer.png',
//   'Frontend Developer': 'FE.png',
//   'Backend Developer': 'BE.png',
//   'Database Engineer': 'DB.png',
//   'System Testing': 'System Testing.png',
//   'Integration Testing': 'SIT.png',
//   'Performance testing': 'NFR_Tester.png',
//   'UAT Agent': 'UAT.png',
//   'DevOps Engineer': 'DevOps.png',
//   'Doc Maker': 'UAT.png',
//   'SAGE': 'UAT.png',
//   'default': 'UAT.png'
// };

// const AgentSelection = () => {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const projectDraft = location.state?.draft;
//   const selectedPhaseIds = projectDraft?.selectedPhaseIds || [];

//   const [activePhase, setActivePhase] = useState(null);
//   const [focusedAgent, setFocusedAgent] = useState(null);
//   const [isConfiguring, setIsConfiguring] = useState(false);
//   const [activeAgentConfigs, setActiveAgentConfigs] = useState({});
//   const [selectedAgents, setSelectedAgents] = useState([]);
//   const [showMandatory, setShowMandatory] = useState(true);

//   // 1. Calculate Phase Count
// const totalPhases = Object.keys(PHASE_NAME_MAP).length;

// // 2. Calculate Agent Count (Dynamic + Mandatory)
// const dynamicAgentCount = Object.values(AGENT_MAPPING).flat().length;
// const mandatoryCount = MANDATORY_AGENTS.length;
// const totalAgentDisplay = `${dynamicAgentCount} + ${mandatoryCount}`;

// // 3. Estimate Overall Project Cost
// const calculateProjectCost = () => {
//     let totalCost = 0;
    
//     Object.keys(AGENT_MAPPING).forEach(phaseKey => {
//         const agentsInPhase = AGENT_MAPPING[phaseKey];
//         agentsInPhase.forEach(agent => {
//             const selectedModel = activeAgentConfigs[agent.name]?.[0]?.model || 'GPT-4o';
//             const modelUnitCost = parseFloat(MODEL_DATA[selectedModel].cost);

//             const tokenWeight = (phaseKey === 'p5' || phaseKey === 'p6') ? 0.25 : 0.10; 
//             const estimatedTokensM = 1.5 * tokenWeight;
//             totalCost += estimatedTokensM * modelUnitCost;
//         });
//     });

//     // Add Mandatory Agents (SAGE and Tech Writer usually handle high context/docs)
//     const sageCost = parseFloat(MODEL_DATA['Claude Opus 4.6'].cost) * 0.3; // High reasoning
//     const writerCost = parseFloat(MODEL_DATA['GPT-4o'].cost) * 0.2; // Documentation
    
//     return (totalCost + sageCost + writerCost).toFixed(2);
// };


//   useEffect(() => {
//     if (selectedPhaseIds.length === 0) return;
//     const initialConfigs = {};
//     const initialSelected = [];

//     selectedPhaseIds.forEach(pId => {
//         AGENT_MAPPING[pId]?.forEach((agent, idx) => {
//             initialConfigs[agent.name] = [{ model: MODEL_LIST[0], instances: 1 }];
//             if (idx === 0) initialSelected.push(agent.name);
//         });
//     });
//     MANDATORY_AGENTS.forEach(ma => {
//         initialConfigs[ma.name] = [{ model: MODEL_LIST[0], instances: 1 }];
//         initialSelected.push(ma.name);
//     });

//     setActiveAgentConfigs(initialConfigs);
//     setSelectedAgents(initialSelected);
//     setActivePhase(selectedPhaseIds[0]);
//   }, [selectedPhaseIds]);

//   const toggleAgentSelection = (agentName) => {
//     const currentPhaseAgents = (activePhase === 'mandatory' ? MANDATORY_AGENTS : (AGENT_MAPPING[activePhase] || [])).map(a => a.name);
//     const selectedInPhase = selectedAgents.filter(name => currentPhaseAgents.includes(name));

//     setSelectedAgents(prev => {
//       if (prev.includes(agentName)) {
//         if (selectedInPhase.length <= 1) return prev;
//         return prev.filter(a => a !== agentName);
//       }
//       return [...prev, agentName];
//     });
//   };

//   const updateInstances = (agentName, rowIndex, value) => {
//     const newValue = Math.max(1, parseInt(value) || 0);
//     setActiveAgentConfigs(prev => {
//       const newRows = [...prev[agentName]];
//       newRows[rowIndex].instances = newValue;
//       return { ...prev, [agentName]: newRows };
//     });
//   };

//   const handleModelChange = (agentName, rowIndex, newModel) => {
//     setActiveAgentConfigs(prev => {
//       let rows = [...prev[agentName]];
//       rows[rowIndex].model = newModel;
//       return { ...prev, [agentName]: rows };
//     });
//   };

//   const getTotalPipelineNodes = () => {
//     return Object.keys(activeAgentConfigs)
//       .filter(name => selectedAgents.includes(name))
//       .reduce((sum, name) => sum + activeAgentConfigs[name].reduce((s, row) => s + row.instances, 0), 0);
//   };

//   const handleDeploy = () => {
//     if (!projectDraft) return;
//     const finalized = { 
//       ...projectDraft, 
//       id: Date.now(), 
//       agentConfigs: activeAgentConfigs, 
//       selectedAgents,
//       status: 'Running',
//       created: new Date().toISOString().split('T')[0]
//     };
//     const existing = JSON.parse(localStorage.getItem("projects") || "[]");
//     localStorage.setItem("projects", JSON.stringify([finalized, ...existing]));
//     navigate("/");
//   };

//   return (
//     <div className="flex h-screen w-full bg-[#050506] text-white overflow-hidden font-sans select-none text-[10px]">
      
//       {/* 1. LEFT SIDEBAR - CLEAN VERTICAL NAV */}
//       <div className="w-[240px] flex-shrink-0 border-r border-white/15 bg-[#08080a] flex flex-col">
//         <div className="h-20 px-6 border-b border-white/15 flex items-center gap-4">
//           <button onClick={() => navigate(-1)} className="p-1.5 rounded-lg bg-white/10 hover:bg-violet-500/10 text-zinc-500 hover:text-white transition-all">
//             <ChevronLeft size={16} />
//           </button>
//           <span className="font-black uppercase tracking-[0.3em] text-violet-500 text-[9px]">Pipeline Phases</span>
//         </div>

//         <div className="flex-1 overflow-y-auto no-scrollbar p-4 space-y-1">
//           {selectedPhaseIds.map(pId => {
//             // 🟢 Logic to calculate total instances for this specific phase
//             const phaseAgents = AGENT_MAPPING[pId] || [];
//             const phaseInstanceTotal = phaseAgents.reduce((total, agent) => {
//               // Only count if the agent is actually selected in the pool
//               if (selectedAgents.includes(agent.name)) {
//                 const agentNodes = activeAgentConfigs[agent.name]?.reduce((sum, row) => sum + row.instances, 0) || 0;
//                 return total + agentNodes;
//               }
//               return total;
//             }, 0);

//             const isActive = activePhase === pId;

//             return (
//               <button 
//                 key={pId}
//                 onClick={() => { setActivePhase(pId); setIsConfiguring(false); }}
//                 className={`w-full text-left px-4 py-3.5 rounded-xl transition-all flex items-center justify-between group 
//                   ${isActive 
//                     ? 'bg-violet-600/50 text-white shadow-lg shadow-violet-900/20' 
//                     : 'bg-white/5 border border-white/10 text-zinc-500 hover:bg-white/10 hover:text-zinc-300'}`}
//               >
//                 <div className="flex items-center justify-between w-full">
//                   <span className="font-bold uppercase tracking-[0.15em] text-[9px] truncate">
//                     {PHASE_NAME_MAP[pId]}
//                   </span>
                  
//                   {/* 🟢 Compact Single-Line Badge */}
//                   <span className={`text-[7px] font-black font-mono px-1.5 py-0.5 rounded-md border shrink-0 transition-colors
//                     ${isActive 
//                       ? 'bg-white text-violet-600 border-white' 
//                       : 'bg-zinc-900 text-zinc-500 border-white/10'
//                     }`}
//                   >
//                     {phaseInstanceTotal}
//                   </span>
//                 </div>

//                 {isActive && (
//                   <motion.div 
//                     layoutId="activeTabGlow"
//                     className="w-1 h-1 rounded-full bg-violet-500 shadow-[0_0_8px_#8b5cf6]" 
//                   />
//                 )}
//               </button>
//             );
//           })}
//         </div>
//       </div>

//       {/* 2. MAIN CONTENT AREA */}
//       <div className="flex-1 flex flex-col bg-[#050506] relative overflow-hidden">
//       {/* TOP BAR */}
//       <div className="h-20 px-10 border-b border-white/20 flex items-center justify-between bg-[#08080a]/50 backdrop-blur-md">
//           <div className="flex items-center gap-3">
//               <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${activePhase === 'mandatory' ? 'bg-amber-500' : 'bg-violet-500'}`} />
//               <h2 className="text-[10px] font-black uppercase tracking-[0.4em] text-zinc-400">
//                 {activePhase === 'mandatory' 
//                   ? `System Configuration // ${focusedAgent || 'Global Core'}` 
//                   : `${PHASE_NAME_MAP[activePhase]} // Available Pool`}
//               </h2>
//           </div>
//       </div>

//       <div className="flex-1 overflow-y-auto p-6 no-scrollbar relative">
//         <AnimatePresence mode="wait">
//           {activePhase === 'mandatory' ? (
//             /* 🟢 FULL SIZE CONFIGURATION WINDOW FOR MANDATORY AGENTS */
//             <motion.div 
//               key="mandatory-config"
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               exit={{ opacity: 0, y: -20 }}
//               className="max-w-4xl mx-auto w-full flex flex-col gap-6 items-center "
//             >
//               {/* IDENTITY HEADER */}
//               <div className="flex flex-col items-center gap-4">
//                 <div className="w-24 h-24 rounded-[2.5rem] border-2 border-amber-500/30 bg-[#0a0a0c] flex items-center justify-center shadow-2xl relative">
//                   <img src={`${ICON_BASE_URL}/${encodeURIComponent(ICON_MAP[focusedAgent])}`} alt="bot" className="w-14 h-14" />
//                   <div className="absolute -bottom-2 bg-amber-500 text-black px-3 py-0.5 rounded-full text-[7px] font-black uppercase tracking-widest">Protocol {focusedAgent === 'SAGE' ? '01' : '02'}</div>
//                 </div>
//                 <h1 className="text-xl font-black uppercase tracking-[0.4em] text-white italic">{focusedAgent}</h1>
//               </div>

//               <div className="w-full bg-[#0c0c0e] border border-white/10 rounded-[2rem] p-10 shadow-2xl relative overflow-hidden">
//                 <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-amber-500 to-transparent" />

//                 {focusedAgent === 'Doc Maker' ? (
//                   /* 🟢 DOCUMENTATION UNIT: ONLY MODEL SELECTION */
//                   <div className="space-y-6">
//                     <div className="text-center space-y-2 mb-8">
//                       <span className="text-[9px] font-black uppercase text-amber-500 tracking-[0.4em]">Documentation Engine</span>
//                       <p className="text-[8px] text-zinc-500 uppercase tracking-widest">Select model</p>
//                     </div>
//                     <div className="relative group max-w-md mx-auto">
//                       <Cpu size={18} className="absolute left-6 top-1/2 -translate-y-1/2 text-amber-500 z-10" />
//                       <select 
//                         value={activeAgentConfigs[focusedAgent]?.[0]?.model} 
//                         onChange={(e) => handleModelChange(focusedAgent, 0, e.target.value)}
//                         className="w-full bg-[#121214] border border-white/10 rounded-2xl py-5 pl-16 pr-10 text-[10px] font-black uppercase outline-none focus:border-amber-500/50 appearance-none transition-all cursor-pointer text-white"
//                       >
//                         {MODEL_LIST.map(m => <option key={m} value={m}>{m}</option>)}
//                       </select>
//                       <Settings size={14} className="absolute right-6 top-1/2 -translate-y-1/2 text-zinc-700" />
//                     </div>
//                   </div>
//                 ) : (
//                   /* 🟢 SECURITY UNIT (SAGE): SYSTEM PARAMETERS */
//                   <div className="space-y-8">
//                     <div className="text-center space-y-2 mb-4">
//                       <span className="text-[9px] font-black uppercase text-rose-500 tracking-[0.4em]">Security Firewall Parameters</span>
//                       <p className="text-[8px] text-zinc-500 uppercase tracking-widest">Read-only system level protection</p>
//                     </div>
                    
//                     <div className="grid grid-cols-2 gap-4">
//                       {[
//                         { label: 'Encryption Level', value: 'AES-256-GCM', status: 'Active' },
//                         { label: 'Threat Detection', value: 'Neural Pattern', status: 'Monitoring' },
//                         { label: 'Protocol Isolation', value: 'Layer 7', status: 'Secure' },
//                         { label: 'Authentication', value: 'Pod-Token V2', status: 'Verified' }
//                       ].map(param => (
//                         <div key={param.label} className="bg-black/40 border border-white/5 p-4 rounded-xl flex justify-between items-center">
//                             <div className="flex flex-col">
//                               <span className="text-[7px] text-zinc-600 font-bold uppercase tracking-widest">{param.label}</span>
//                               <span className="text-[10px] text-white font-black uppercase">{param.value}</span>
//                             </div>
//                             <div className="flex flex-col items-end">
//                               <div className="w-1 h-1 rounded-full bg-emerald-500 shadow-[0_0_5px_#10b981]" />
//                               <span className="text-[6px] text-emerald-500 font-bold mt-1 uppercase">{param.status}</span>
//                             </div>
//                         </div>
//                       ))}
//                     </div>
//                     <div className="p-4 bg-rose-500/5 border border-rose-500/20 rounded-xl text-center">
//                         <span className="text-[8px] font-black text-rose-500 uppercase tracking-[0.2em]">Hardware Lock: Standard Intelligence Selection Override</span>
//                     </div>
//                   </div>
//                 )}
//               </div>
//             </motion.div>
//           ) : (
//               <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full h-full flex flex-col items-start relative">
//                 <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-x-16 gap-y-16 p-4 w-full">
//                   {(activePhase === 'mandatory' ? MANDATORY_AGENTS : (AGENT_MAPPING[activePhase] || [])).map((agent, index) => {
//                     const isSelected = selectedAgents.includes(agent.name);
//                     const isBeingConfigured = isConfiguring && focusedAgent === agent.name;
//                     const totalInstances = activeAgentConfigs[agent.name]?.[0]?.instances || 1;
//                     const isNearRightEdge = (index + 1) % 4 === 0 || (index + 1) % 5 === 0;
                    
//                     return (
//                       <div key={agent.name} className="relative flex flex-col items-center">
//                         <div onClick={() => toggleAgentSelection(agent.name)} className={`relative group cursor-pointer transition-all duration-500 ${isBeingConfigured ? 'scale-110' : 'scale-100'}`}>
//                           {/* AGENT CORE */}
//                           <div className={`w-20 h-20 rounded-[2.2rem] border-2 transition-all duration-500 flex items-center justify-center relative ${isSelected ? 'bg-[#0a0a0c] border-violet-500 shadow-[0_0_30px_rgba(139,92,246,0.2)]' : 'bg-zinc-900/40 border-white/5 group-hover:border-white/20'}`}>
//                             <img src={`${ICON_BASE_URL}/${encodeURIComponent(ICON_MAP[agent.name] || ICON_MAP['default'])}`} alt={agent.name} className={`w-12 h-12 transition-all duration-500 ${isSelected ? 'opacity-100' : 'opacity-20 grayscale group-hover:grayscale-0'}`} />
                            
//                             {isSelected && (
//                               <>
//                                 <button onClick={(e) => { e.stopPropagation(); setFocusedAgent(agent.name); setIsConfiguring(!isBeingConfigured); }} className={`absolute -bottom-1 -left-1 w-9 h-9 rounded-2xl flex items-center justify-center border-2 transition-all z-30 shadow-2xl ${isBeingConfigured ? 'bg-violet-600 border-violet-400 text-white rotate-90' : 'bg-violet-600 border-violet-400 text-white hover:bg-violet-500'}`}>
//                                   <Settings size={16} strokeWidth={2.5} />
//                                 </button>
//                                 <div className="absolute -top-1 -right-1 min-w-[24px] h-6 px-2 bg-violet-600 rounded-full border-2 border-[#050506] flex items-center justify-center shadow-lg z-30">
//                                   <span className="text-[10px] font-black text-white font-mono">{totalInstances}</span>
//                                 </div>
//                               </>
//                             )}
//                           </div>
//                           <div className="text-center mt-4">
//                             <h3 className={`text-[10px] font-black uppercase tracking-widest transition-colors duration-300 ${isSelected ? 'text-white' : 'text-zinc-600'}`}>{agent.name}</h3>
//                             {isSelected && <motion.div layoutId="underline" className="h-[2px] w-6 bg-violet-500 mx-auto mt-2 rounded-full" />}
//                           </div>
//                         </div>

//                         {/* TETHERED CONFIG CARD (Logical & Cleaner) */}
//                         <AnimatePresence>
//                           {isBeingConfigured && (
//                             <div className={`absolute top-10 z-[100] w-[240px] ${isNearRightEdge ? 'right-full mr-6' : 'left-full ml-6'}`}>
//                               <motion.div initial={{ opacity: 0, x: isNearRightEdge ? 20 : -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, scale: 0.95 }} className="bg-[#0c0c0e] border border-violet-500/30 rounded-[2rem] p-6 space-y-4 shadow-[0_30px_60px_rgba(0,0,0,0.8)] backdrop-blur-xl">
//                                 <div className="space-y-3">
//                                   <span className="text-[8px] font-black uppercase text-zinc-500 tracking-[0.2em]">Instance Count</span>
//                                   <div className="flex items-center justify-between bg-black/60 rounded-xl p-1.5 border border-white/5">
//                                       <button onClick={() => updateInstances(agent.name, 0, activeAgentConfigs[agent.name][0].instances - 1)} className="w-8 h-8 flex items-center justify-center text-zinc-500 hover:text-white transition-colors"><Minus size={14}/></button>
//                                       <span className="text-lg font-black text-white font-mono">{activeAgentConfigs[agent.name][0].instances}</span>
//                                       <button onClick={() => updateInstances(agent.name, 0, activeAgentConfigs[agent.name][0].instances + 1)} className="w-8 h-8 flex items-center justify-center text-zinc-500 hover:text-white transition-colors"><Plus size={14}/></button>
//                                   </div>
//                                 </div>
//                                 <div className="space-y-3 pt-2 border-t border-white/5">
//                                     <div className="flex justify-between items-center px-1">
//                                         <span className="text-[8px] font-black uppercase text-zinc-500 tracking-[0.2em]">
//                                             Avg Cost / 1M Tokens
//                                         </span>
//                                         <span className={`text-[9px] font-black ${MODEL_DATA[activeAgentConfigs[agent.name][0].model].color}`}>
//                                             ${MODEL_DATA[activeAgentConfigs[agent.name][0].model].cost}
//                                         </span>
//                                     </div>
//                                     <select 
//                                         value={activeAgentConfigs[agent.name][0].model} 
//                                         onChange={(e) => handleModelChange(agent.name, 0, e.target.value)} 
//                                         className={`w-full bg-[#121214] border border-white/10 rounded-xl py-3 px-3 text-[9px] font-black uppercase outline-none focus:border-violet-500 transition-all ${MODEL_DATA[activeAgentConfigs[agent.name][0].model].color}`}
//                                     >
//                                         {MODEL_LIST.map(m => <option key={m} value={m}>{m}</option>)}
//                                     </select>
//                                 </div>
//                               </motion.div>
//                             </div>
//                           )}
//                         </AnimatePresence>
//                       </div>
//                     );
//                   })}
//                 </div>
//               </motion.div>
//             )}
//           </AnimatePresence>
//         </div>
//       </div>

//       {/* 3. RIGHT SIDEBAR - UNIFIED SUMMARY & LAUNCH */}
// <div className="w-[320px] flex-shrink-0 border-l border-white/20 bg-[#08080a] flex flex-col font-sans">
//   {/* TOP HEADER */}
//   <div className="h-20 px-8 border-b border-white/20 flex items-center justify-center bg-[#050506]">
//       <span className="text-[9px] font-black text-white uppercase tracking-[0.5em]">Pod Configuration</span>
//   </div>

//   <div className="flex-1 flex flex-col overflow-y-auto no-scrollbar">
    
//     {/* SECTION 1: CORE METRICS */}
//     <div className="p-8 space-y-8 border-b border-white/5">
//       <div className="flex items-center gap-5">
//         <div className="w-14 h-14 rounded-2xl bg-violet-600 flex items-center justify-center shadow-2xl shadow-violet-600/20">
//           <Users size={24} className="text-white" />
//         </div>
//         <div>
//           <div className="flex items-baseline gap-2">
//             <span className="text-3xl font-black text-white leading-none tracking-tighter">
//               {getTotalPipelineNodes()}
//             </span>
//           </div>
//           <span className="text-[9px] font-black text-violet-400 uppercase tracking-[0.2em] mt-1 block">Total Agents Active</span>
//         </div>
//       </div>

//       <div className="flex items-center gap-4 pt-2">
//         <span className="text-3xl font-black text-white tracking-tighter leading-none">{selectedPhaseIds.length}</span>
//         <div className="flex flex-col">
//           <span className="text-[9px] font-black text-zinc-500 uppercase tracking-[0.2em]">Phases Selected</span>
//           <div className="w-24 h-1 bg-zinc-800 rounded-full mt-2 overflow-hidden">
//             <motion.div 
//               className="h-full bg-violet-500" 
//               initial={{ width: 0 }} 
//               animate={{ width: `${(selectedPhaseIds.length / 9) * 100}%` }} 
//             />
//           </div>
//         </div>
//       </div>
//     </div>

//     {/* SECTION 2: SYSTEM SERVICES (MANDATORY AGENTS) */}
//     <div className="p-8 space-y-4 border-b border-white/5">
//       <button 
//         onClick={() => setShowMandatory(!showMandatory)}
//         className="w-full flex items-center justify-between group cursor-pointer"
//       >
//         <div className="flex items-center gap-3">
//           <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
//             <Lock size={12} className="text-amber-500" />
//           </div>
//           <span className="text-[9px] font-black uppercase tracking-[0.3em] text-amber-500">Mandatory Agents</span>
//         </div>
//         <ChevronLeft 
//           size={14} 
//           className={`text-zinc-600 group-hover:text-amber-500 transition-all duration-500 ${showMandatory ? '-rotate-90' : 'rotate-0'}`} 
//         />
//       </button>

//       <AnimatePresence>
//         {showMandatory && (
//           <motion.div 
//             initial={{ height: 0, opacity: 0 }}
//             animate={{ height: 'auto', opacity: 1 }}
//             exit={{ height: 0, opacity: 0 }}
//             className="space-y-2 overflow-hidden pt-2"
//           >
//             {MANDATORY_AGENTS.map((ma) => {
//               const isActive = activePhase === 'mandatory' && focusedAgent === ma.name;
//               return (
//                 <button 
//                   key={ma.name}
//                   onClick={() => { setActivePhase('mandatory'); setFocusedAgent(ma.name); setIsConfiguring(false); }}
//                   className={`w-full p-4 rounded-xl transition-all duration-300 flex items-center gap-4 border
//                     ${isActive 
//                       ? 'bg-amber-500/10 border-amber-500/50' 
//                       : 'bg-white/5 border-transparent hover:bg-white/10'}`}
//                 >
//                   <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all
//                     ${isActive ? 'bg-amber-500 text-black' : 'bg-zinc-900 text-zinc-600'}`}>
//                     <img 
//                       src={`${ICON_BASE_URL}/${encodeURIComponent(ICON_MAP[ma.name] || ICON_MAP['default'])}`} 
//                       alt={ma.name} 
//                       className={`w-5 h-5 ${isActive ? 'brightness-0' : 'opacity-40'}`} 
//                     />
//                   </div>
//                   <div className="flex flex-col items-start text-left flex-1">
//                     <span className={`text-[9px] font-black uppercase tracking-widest ${isActive ? 'text-white' : 'text-zinc-500'}`}>{ma.name}</span>
//                     <span className="text-[6px] font-bold text-zinc-700 uppercase">System Intelligence</span>
//                   </div>
//                   {isActive && <div className="w-1 h-1 rounded-full bg-amber-500 shadow-[0_0_8px_#f59e0b]" />}
//                 </button>
//               );
//             })}
//           </motion.div>
//         )}
//       </AnimatePresence>
//     </div>

//     {/* SECTION 3: FINANCIAL PROJECTION */}
//     <div className="p-8 space-y-4">
//       <div className="flex flex-col">
//         <span className="text-[9px] font-black text-violet-400 uppercase tracking-[0.3em]">Financial Projection</span>
//         <div className="flex items-baseline gap-2 mt-3">
//           <span className="text-4xl font-black text-white tracking-tighter">${calculateProjectCost()}</span>
//           <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest">/ Feature</span>
//         </div>
//         <p className="text-[8px] text-zinc-600 mt-4 leading-relaxed italic border-l border-violet-500/30 pl-3">
//           *Estimate based on 1.5M total token flow across SDLC clusters.
//         </p>
//       </div>
//     </div>
//   </div>

//   {/* ACTION AREA */}
//   <div className="p-8 border-t border-white/10 bg-[#050506]">
//     <button 
//       onClick={handleDeploy} 
//       className="w-full py-6 bg-white text-black font-black uppercase tracking-[0.4em] rounded-[2rem] hover:bg-violet-600 hover:text-white transition-all shadow-2xl active:scale-95 text-[11px]"
//     >
//       Launch Pod
//     </button>
//   </div>
// </div>
//     </div>
//   );
// };

// export default AgentSelection;