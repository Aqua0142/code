import React from "react";
import { 
  FileText, Github, Link2, ExternalLink, Download, 
  Database, RefreshCcw, Layers, MessageSquare, Briefcase 
} from "lucide-react";

export default function RequirementsTab({ project, onRerunStage }) {
  // Mock source data - in a real app, this would be part of your project object
  const sources = [
    { id: 1, type: "manual", name: "Problem Statement", content: project?.description || "Initial scope for E-commerce V2", date: "2024-05-15" },
    { id: 2, type: "upload", name: "business_requirements_v1.pdf", size: "2.4 MB", date: "2024-05-15" },
    { id: 3, type: "jira", name: "EPIC-402: Cart Service", link: "https://jira.atlassian.com/EPIC-402", date: "2024-05-16" },
    { id: 4, type: "confluence", name: "Platform Roadmap 2024", link: "#", date: "2024-05-16" },
    { id: 5, type: "github", name: "README.md (Legacy Repo)", link: "https://github.com/org/legacy-cart", date: "2024-05-17" }
  ];

  const getSourceBadge = (type) => {
    const styles = {
      manual: "bg-violet-500/10 text-violet-400 border-violet-500/20",
      upload: "bg-sky-500/10 text-sky-400 border-sky-500/20",
      jira: "bg-blue-500/10 text-blue-400 border-blue-500/20",
      confluence: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
      github: "bg-zinc-500/10 text-zinc-400 border-zinc-500/20",
    };
    return styles[type] || styles.manual;
  };

  return (
    <div className="flex flex-col gap-8 p-8 max-w-7xl mx-auto w-full animate-in fade-in duration-500 pb-20">
      
      {/* --- HEADER ACTIONS --- */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Source Intelligence</h2>
          <p className="text-xs text-zinc-500 mt-1">Audit trail of all inputs used to generate User Stories</p>
        </div>
        <button 
          onClick={() => onRerunStage('G1')}
          className="flex items-center gap-2 px-5 py-2.5 bg-violet-600/10 hover:bg-violet-600/20 text-violet-400 border border-violet-500/20 rounded-xl text-xs font-black uppercase tracking-widest transition-all group"
        >
          <RefreshCcw size={14} className="group-hover:rotate-180 transition-transform duration-500" />
          Edit & Re-run Requirements Stage
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LEFT COL: MERGED REQUIREMENTS (The "AI Memory") */}
        <div className="lg:col-span-2 space-y-6">
          <section className="bg-[#0b0b0d] border border-zinc-800/60 rounded-[2rem] p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Layers size={120} className="text-violet-400" />
            </div>
            
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-violet-500/20 rounded-lg text-violet-400">
                <Database size={18} />
              </div>
              <h3 className="text-sm font-bold text-zinc-200 uppercase tracking-widest">Merged Context</h3>
            </div>

            <div className="space-y-4 text-sm text-zinc-400 leading-relaxed font-mono bg-black/20 p-6 rounded-2xl border border-zinc-800/40">
              <p>The following context was synthesized for the autonomous architect:</p>
              <p className="text-zinc-300">"Build a high-performance e-commerce engine focusing on concurrency and real-time inventory. Primary tech stack prioritized is PostgreSQL and Next.js. Integration requirements include legacy Github README specs and Jira Epic 402..."</p>
              <div className="h-px bg-zinc-800/50 my-4" />
              <p className="text-[10px] text-zinc-500 italic uppercase">System Note: This text is read-only. To change logic, use the Re-run button above.</p>
            </div>
          </section>

          {/* SOURCE GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sources.map(source => (
              <div key={source.id} className="bg-[#09090b] border border-zinc-800 rounded-2xl p-5 hover:border-zinc-700 transition-all flex flex-col group">
                <div className="flex items-start justify-between mb-4">
                  <div className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter border ${getSourceBadge(source.type)}`}>
                    {source.type}
                  </div>
                  {source.link && (
                    <a href={source.link} target="_blank" rel="noreferrer" className="text-zinc-500 hover:text-white transition-colors">
                      <ExternalLink size={14} />
                    </a>
                  )}
                  {source.type === 'upload' && (
                    <button className="text-zinc-500 hover:text-sky-400 transition-colors">
                      <Download size={14} />
                    </button>
                  )}
                </div>
                
                <h4 className="text-sm font-bold text-zinc-200 mb-1 group-hover:text-violet-400 transition-colors">{source.name}</h4>
                <p className="text-[10px] text-zinc-500 font-mono">Imported on: {source.date}</p>
                
                {source.content && (
                  <p className="mt-3 text-xs text-zinc-400 line-clamp-2 italic">"{source.content}"</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT COL: STATS & SUMMARY */}
        <div className="space-y-6">
          <div className="bg-[#0b0b0d] border border-zinc-800 rounded-[2rem] p-6 space-y-6">
            <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] px-2">Discovery Analytics</h3>
            
            <div className="space-y-4">
               <div className="flex justify-between items-center p-4 bg-zinc-900/40 rounded-2xl border border-zinc-800/50">
                  <span className="text-xs text-zinc-400">Total Sources</span>
                  <span className="text-lg font-mono font-bold text-white">{sources.length}</span>
               </div>
               <div className="flex justify-between items-center p-4 bg-zinc-900/40 rounded-2xl border border-zinc-800/50">
                  <span className="text-xs text-zinc-400">Data Points</span>
                  <span className="text-lg font-mono font-bold text-violet-400">42</span>
               </div>
               <div className="flex justify-between items-center p-4 bg-zinc-900/40 rounded-2xl border border-zinc-800/50">
                  <span className="text-xs text-zinc-400">External Links</span>
                  <span className="text-lg font-mono font-bold text-sky-400">3</span>
               </div>
            </div>

            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
               <div className="flex items-center gap-2 mb-2">
                  <RefreshCcw size={12} className="text-emerald-500" />
                  <span className="text-[10px] font-black text-emerald-500 uppercase">Sync Status</span>
               </div>
               <p className="text-[10px] text-zinc-500 leading-relaxed">External sources (Jira/Confluence) were last synced 4 hours ago.</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-violet-600/10 to-transparent border border-violet-500/10 rounded-[2rem] p-6">
             <div className="flex items-center gap-2 mb-3">
                <MessageSquare size={14} className="text-violet-400" />
                <span className="text-[10px] font-black text-violet-400 uppercase">Context Note</span>
             </div>
             <p className="text-xs text-zinc-400 italic leading-relaxed">
               "The AI agent prioritized the Jira Epic requirements over the manual statement due to higher detail density."
             </p>
          </div>
        </div>

      </div>
    </div>
  );
}