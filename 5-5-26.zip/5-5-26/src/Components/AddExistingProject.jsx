import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Globe, Server, Smartphone, Building2, Puzzle, X, Plus,
  FileText, Trash2, Link as LinkIcon, Cpu, Database, Check, ChevronRight, ArrowLeft,
  Zap, Clock
} from "lucide-react";

const TECH_CATALOG = {
  language: { label: "Language", icon: Cpu, options: [
    { name: "Python", value: "python" }, { name: "Java", value: "java" },
    { name: "TypeScript", value: "typescript" }, { name: "Go", value: "go" }
  ]},
  frontend: { label: "Frontend", icon: Globe, options: [
    { name: "React", value: "react" }, { name: "Next.js", value: "nextjs" },
    { name: "Vue.js", value: "vue" }, { name: "None", value: "none" }
  ]},
  backend: { label: "Backend", icon: Server, options: [
    { name: "FastAPI", value: "fastapi" }, { name: "Django", value: "django" },
    { name: "Express.js", value: "express" }, { name: "Spring Boot", value: "spring_boot" }
  ]},
  database: { label: "Database", icon: Database, options: [
    { name: "PostgreSQL", value: "postgresql" }, { name: "MySQL", value: "mysql" },
    { name: "MongoDB", value: "mongodb" }
  ]}
};

const RUNTIME_MAP = {
  "python": "Python 3.12", "fastapi": "Uvicorn", "react": "Vite + Node 20",
  "nextjs": "Node 20", "typescript": "Node 20", "go": "Go 1.22", "java": "OpenJDK 21"
};

export default function AddExistingProject({ onBack = null, onProjectImported = null }) {
  const navigate = useNavigate();

  // Core States
  const [projectName, setProjectName] = useState("");
  const [projectType, setProjectType] = useState("");
  const [uploadType, setUploadType] = useState("file");
  const [files, setFiles] = useState([]);
  const [repoUrls, setRepoUrls] = useState([]);
  const [currentUrl, setCurrentUrl] = useState("");

  // Technology States
  const [activeTab, setActiveTab] = useState(null);
  const [selections, setSelections] = useState({});
  const [runtimeParts, setRuntimeParts] = useState({});
  const [deployment, setDeployment] = useState("");

  const [basePath, setBasePath] = useState("/home/user/projects/my-app");
  const [modification, setModification] = useState("");
  const [isRuntimeFocused, setIsRuntimeFocused] = useState(false);

  // Sync Path with Project Name
  useEffect(() => {
    setBasePath(`/home/user/projects/${projectName || "my-app"}`);
  }, [projectName]);

  // Sync Deployment/Runtime values based on Technology Selections
  useEffect(() => {
    const allRuntimes = Object.values(runtimeParts).flat().filter(Boolean);
    setDeployment([...new Set(allRuntimes)].join(", "));
  }, [runtimeParts]);

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files).map(f => ({ type: 'file', name: f.name, data: f }));
    setFiles((prev) => [...prev, ...selectedFiles]);
  };

  const removeFile = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const addUrl = () => {
    if (currentUrl.trim()) {
      setRepoUrls((prev) => [...prev, currentUrl.trim()]);
      setCurrentUrl("");
    }
  };

  const removeUrl = (index) => {
    setRepoUrls((prev) => prev.filter((_, i) => i !== index));
  };

  const handleTechSelect = (categoryKey, tech) => {
    const currentCategorySelections = selections[categoryKey] || [];
    const isAlreadySelected = currentCategorySelections.some(item => item.value === tech.value);

    let newSels;
    let newRuns;

    if (isAlreadySelected) {
      newSels = currentCategorySelections.filter(item => item.value !== tech.value);
      newRuns = (runtimeParts[categoryKey] || []).filter(r => r !== RUNTIME_MAP[tech.value]);
    } else {
      newSels = [...currentCategorySelections, tech];
      newRuns = [...(runtimeParts[categoryKey] || []), RUNTIME_MAP[tech.value]];
    }

    setSelections(prev => ({ ...prev, [categoryKey]: newSels }));
    setRuntimeParts(prev => ({ ...prev, [categoryKey]: newRuns }));
  };

  const handleAddProject = () => {
    if (!projectName) return alert("Project Name required.");

    const importedProjectDraft = {
      id: Date.now(),
      projectName: projectName,
      projectType: projectType,
      requirements: modification, // Mapping modifications to requirements for config step
      status: 'Running',
      isImported: true,
      created: new Date().toISOString().split('T')[0],
      sources: uploadType === "file" ? files.map(f => f.name) : repoUrls,
      selections,
      deployment,
      basePath: basePath,
      // Defaulting stages for configuration hydration
      stages: [
        { id: 'G1', state: 'approved' },
        { id: 'G2', state: 'executing' },
      ]
    };

    // 🟢 Step 1: Handle Callback if exists
    if (onProjectImported) {
      onProjectImported(importedProjectDraft);
    } 
    
    // 🟢 Step 2: Push to unique configure endpoint with state
    navigate("/", { state: { draft: importedProjectDraft } });
  };

  const handleBack = () => {
    if (onBack) onBack();
    else navigate("/"); // Go back to Dashboard endpoint
  };

  return (
    <div className="flex-1 min-h-screen bg-[#09090b] text-white flex justify-center p-8 font-sans overflow-y-auto custom-scrollbar">
      <style>{`.no-scrollbar::-webkit-scrollbar { display: none; }`}</style>
      <div className="w-full max-w-5xl space-y-6">

        {/* HEADER */}
        <div className="flex items-center gap-4 border-b border-zinc-800/50 pb-6">
          <button onClick={handleBack} className="p-2 hover:bg-zinc-800 rounded-xl text-zinc-400 border border-zinc-800 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-3xl font-black tracking-tighter bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent uppercase leading-none">
                Import Project
            </h1>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-1 ml-1">Connect existing codebase to AI Pod</p>
          </div>
        </div>

        {/* BASIC IDENTITY */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Project Name</label>
            <input
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="my-app"
              className="w-full p-3 bg-[#111] border border-zinc-800 rounded-xl outline-none focus:border-violet-500 text-sm transition-all"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Project Category</label>
            <input
              value={projectType}
              onChange={(e) => setProjectType(e.target.value)}
              placeholder="e.g. SaaS, internal-tool"
              className="w-full p-3 bg-[#111] border border-zinc-800 rounded-xl outline-none focus:border-violet-500 text-sm transition-all"
            />
          </div>
        </div>

        {/* IMPORT SOURCE SECTION */}
        <div className="bg-[#0c0c0e] p-6 rounded-2xl border border-zinc-800/50 space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-[10px] font-black text-violet-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <LinkIcon size={12}/> Import Source
            </h2>
            {uploadType === 'file' && files.length > 0 && (
              <button onClick={() => setFiles([])} className="text-[9px] font-black text-red-500 hover:text-red-400 uppercase tracking-widest flex items-center gap-1">
                <Trash2 size={12}/> Clear Files
              </button>
            )}
          </div>
          
          <div className="flex bg-[#111] p-1 rounded-xl w-fit border border-zinc-800">
            <button
              onClick={() => setUploadType("file")}
              className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${uploadType === "file" ? "bg-violet-600 text-white" : "text-zinc-500 hover:text-white"}`}
            >
              Files
            </button>
            <button
              onClick={() => setUploadType("url")}
              className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${uploadType === "url" ? "bg-violet-600 text-white" : "text-zinc-500 hover:text-white"}`}
            >
              URLs
            </button>
          </div>

          {uploadType === "file" ? (
            <div className="space-y-3">
              <label className="w-full cursor-pointer block">
                <div className="flex items-center justify-between p-6 bg-zinc-950 border-2 border-dashed border-zinc-800 rounded-2xl hover:border-violet-500/50 transition group">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-violet-600/10 rounded-xl text-violet-400 group-hover:bg-violet-600/20 transition">
                        <Plus size={24} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-zinc-300">Drop your project files here</p>
                      <p className="text-[10px] text-zinc-600 uppercase font-black tracking-widest mt-1">ZIP, JSON, or Source Files</p>
                    </div>
                  </div>
                  <div className="text-[10px] font-black uppercase tracking-[0.2em] text-violet-400 bg-violet-400/5 px-3 py-1.5 rounded-lg border border-violet-400/10">Browse</div>
                </div>
                <input type="file" multiple onChange={handleFileChange} className="hidden" />
              </label>

              {files.length > 0 && (
                <div className="max-h-[160px] overflow-y-auto no-scrollbar grid grid-cols-1 md:grid-cols-2 gap-2">
                  {files.map((f, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-zinc-900/40 border border-zinc-800 rounded-xl animate-in fade-in slide-in-from-top-1">
                      <div className="flex items-center gap-3 truncate">
                        <FileText size={16} className="text-violet-400 flex-shrink-0" />
                        <span className="text-[11px] font-medium text-zinc-300 truncate">{f.name}</span>
                      </div>
                      <button onClick={() => removeFile(index)} className="p-1.5 hover:bg-red-500/10 rounded-lg transition-colors group">
                         <X size={14} className="text-zinc-600 group-hover:text-red-500" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  value={currentUrl}
                  onChange={(e) => setCurrentUrl(e.target.value)}
                  placeholder="https://github.com/repository"
                  className="flex-1 p-3 bg-zinc-950 border border-zinc-800 rounded-xl outline-none focus:border-violet-500 text-sm font-mono text-zinc-400"
                />
                <button onClick={addUrl} className="bg-violet-600 px-5 rounded-xl hover:bg-violet-500 transition-all active:scale-95 shadow-lg shadow-violet-900/20">
                  <Plus size={20}/>
                </button>
              </div>
              {repoUrls.length > 0 && (
                <div className="max-h-[160px] overflow-y-auto no-scrollbar space-y-2">
                  {repoUrls.map((url, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-zinc-900/40 border border-zinc-800 rounded-xl">
                      <div className="flex items-center gap-3 truncate">
                        <LinkIcon size={16} className="text-violet-400 flex-shrink-0" />
                        <span className="text-[11px] font-mono text-zinc-300 truncate">{url}</span>
                      </div>
                      <X size={16} className="text-zinc-600 hover:text-red-500 cursor-pointer p-1" onClick={() => removeUrl(index)} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* TECHNOLOGY STACK */}
        <div className="bg-[#0c0c0e] p-6 rounded-2xl border border-zinc-800/50 space-y-4">
          <h2 className="text-[10px] font-black text-violet-400 uppercase tracking-[0.2em] flex items-center gap-2">
            <Puzzle size={12}/> Detected Technology
          </h2>

          <div className="flex flex-wrap gap-2">
            {Object.keys(TECH_CATALOG).map((key) => {
              const category = TECH_CATALOG[key];
              const categorySelections = selections[key] || [];
              const hasSelection = categorySelections.length > 0;
              const isActive = activeTab === key;
              const Icon = category.icon;
              return (
                <button
                  key={key}
                  onClick={() => setActiveTab(isActive ? null : key)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-[10px] font-bold transition-all duration-300 ${
                    isActive ? 'border-violet-500 bg-violet-600 text-white shadow-lg shadow-violet-500/20' :
                    hasSelection ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400' :
                    'border-zinc-800 bg-zinc-950 text-zinc-500 hover:text-zinc-200'
                  }`}
                >
                  {hasSelection ? <Check size={10}/> : <Icon size={10}/>}
                  {category.label} {hasSelection && `(${categorySelections.length})`}
                </button>
              );
            })}
          </div>

          {activeTab && (
            <div className="p-4 bg-zinc-950 border border-zinc-800/60 rounded-xl animate-in fade-in slide-in-from-top-1">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                  <ChevronRight size={12} className="text-violet-500"/> Identify {TECH_CATALOG[activeTab].label}
                </span>
                <X size={14} className="text-zinc-600 cursor-pointer hover:text-white" onClick={() => setActiveTab(null)}/>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {TECH_CATALOG[activeTab].options.map(opt => {
                  const isOptSelected = (selections[activeTab] || []).some(s => s.value === opt.value);
                  return (
                    <button
                      key={opt.value}
                      onClick={() => handleTechSelect(activeTab, opt)}
                      className={`py-2 px-1 rounded-lg border text-[11px] font-medium transition-all ${
                        isOptSelected
                        ? 'border-violet-400 bg-violet-600 text-white'
                        : 'border-zinc-800 bg-[#111] text-zinc-400 hover:border-violet-500/50'
                      }`}
                    >
                      {opt.name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* FOOTER: RUNTIME & PATH */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <h2 className={`text-[10px] font-black uppercase tracking-widest ml-1 transition-colors ${isRuntimeFocused ? "text-violet-400" : "text-zinc-500"}`}>
              Runtime Environment
            </h2>
            <input
              value={deployment}
              readOnly
              onFocus={() => setIsRuntimeFocused(true)}
              onBlur={() => setIsRuntimeFocused(false)}
              className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-xl outline-none text-violet-300/80 font-mono italic cursor-default text-xs"
            />
          </div>
          <div className="space-y-1">
            <h2 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Installation Path</h2>
            <input value={basePath} onChange={(e) => setBasePath(e.target.value)} className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-xl outline-none focus:border-violet-500 text-xs font-mono text-white" />
          </div>
        </div>

        <div className="space-y-1">
          <h2 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Project Modifications</h2>
          <textarea
            value={modification}
            onChange={(e) => setModification(e.target.value)}
            placeholder="e.g. Integrate existing DB, update CSS variables..."
            className="w-full p-4 bg-zinc-950 border border-zinc-800 rounded-xl outline-none focus:border-violet-500 h-28 text-sm no-scrollbar resize-none font-medium italic"
          />
        </div>

        <div className="flex justify-end pt-6">
            <button
                onClick={handleAddProject}
                className="group flex items-center gap-3 px-10 py-4 bg-violet-600 hover:bg-violet-500 rounded-2xl transition-all duration-300 active:scale-95 shadow-xl shadow-violet-900/20"
            >
                <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white">
                    Confirm Import
                </span>
                <Zap size={16} className="text-white group-hover:scale-110 transition-transform" />
            </button>
        </div>
      </div>
    </div>
  );
}