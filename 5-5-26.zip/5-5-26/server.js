const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors()); // Allows your React app to talk to this server
app.use(express.json());

app.post('/api/github-explorer', async (req, res) => {
  const { repoUrl, path } = req.body;

  try {
    // Extract owner and repo from the URL
    const match = repoUrl.match(/github\.com\/([^/]+)\/([^/?#\s]+)/);
    if (!match) return res.status(400).json({ error: "Invalid GitHub URL" });

    const owner = match[1];
    const repo = match[2].replace(".git", "");
    
    // Call GitHub API with your secret token
    const response = await axios.get(
      `https://api.github.com/repos/${owner}/${repo}/contents/${path || ''}`,
      {
        headers: {
          'Authorization': `token ${process.env.GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github+json'
        }
      }
    );

    res.json(response.data);
  } catch (error) {
    res.status(error.response?.status || 500).json({ error: "GitHub API Error" });
  }
});

app.listen(5000, () => console.log('Backend running on http://localhost:5000'));