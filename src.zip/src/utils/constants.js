import {
  ShieldCheck,
  Settings,
  Cpu,
  Code,
  Activity,
  Rocket,
  UserCheck,
  Server,
  Globe,
  Database
} from "lucide-react";

// From Project Setup

export const TECH_CATALOG = {
  frontend: {
    label: "Presentation Layer",
    icon: Globe,
    options: [
      { name: "React", value: "react" },
      { name: "Next.js", value: "nextjs" },
      { name: "Vue.js", value: "vue" },
      { name: "Angular", value: "Angular" },
    ],
  },
  backend: {
    label: "Application Layer",
    icon: Server,
    options: [
      { name: "Python", value: "python" },
      { name: "Java", value: "java" },
      { name: "TypeScript", value: "typescript" },
      { name: "Go", value: "go" },
    ],
  },
  database: {
    label: "Data Store",
    icon: Database,
    options: [
      { name: "PostgreSQL", value: "postgresql" },
      { name: "MySQL", value: "mysql" },
      { name: "MongoDB", value: "mongodb" },
    ],
  },
};
 
export const RUNTIME_MAP = {
  python: "Python 3.12",
  fastapi: "Uvicorn",
  react: "Vite + Node 20",
  nextjs: "Node 20",
  typescript: "Node 20",
  go: "Go 1.22",
  java: "OpenJDK 21",
};

// From Phase Selection

export const ICON_BASE_URL = "https://raw.githubusercontent.com/Aqua0142/agent-icons/main";

export const ICON_MAP = {
  "Product Owner": "Product Owner.png",
  "Project Manager": "Project Manager.png",
  "Solution Architect": "Architecture.png",
  "UI/UX Designer": "Designer.png",
  "Frontend Developer": "FE.png",
  "Backend Developer": "BE.png",
  "Database Engineer": "DB.png",
  "System Testing": "System Testing.png",
  "Integration Testing": "SIT.png",
  "Performance testing": "NFR_Tester.png",
  "UAT Agent": "UAT.png",
  "DevOps Engineer": "DevOps.png",
  "Doc Maker": "UAT.png",
  SAGE: "UAT.png",
  default: "UAT.png",
};

export const MODEL_DATA = {
  "GPT-4o": { cost: "12.50", color: "text-emerald-400" },
  "GPT-5 (Flagship)": { cost: "11.25", color: "text-emerald-400" },
  "Claude Sonnet 4.6": { cost: "18.00", color: "text-orange-400" },
  "Claude Opus 4.6": { cost: "30.00", color: "text-orange-400" },
  "Gemini 3 Pro": { cost: "14", color: "text-blue-400" },
  "Llama 3.1": { cost: "3.30", color: "text-purple-400" },
};

export const MODEL_LIST = Object.keys(MODEL_DATA);

export const AGENT_MAPPING = {
  p1: [{ name: "Product Owner" }],
  p2: [{ name: "Project Manager" }],
  p3: [{ name: "Solution Architect" }],
  p4: [
    { name: "Frontend Developer" },
    { name: "Backend Developer" },
    { name: "Database Engineer" },
  ],
  p5: [{ name: "System Testing" }, { name: "Integration Testing" }],
  p6: [{ name: "Performance testing" }],
  p7: [{ name: "UAT Agent" }],
  p8: [{ name: "DevOps Engineer" }],
};

export const MANDATORY_AGENTS = [{ name: "Doc Maker" }, { name: "SAGE" }];

export const STAGES = [
  { id: "p1", label: "Requirements", icon: ShieldCheck },
  { id: "p2", label: "Planning", icon: Settings },
  { id: "p3", label: "Architecture", icon: Cpu },
  { id: "p4", label: "Development", icon: Code },
  { id: "p5", label: "Testing", icon: Activity },
  { id: "p6", label: "NFR Testing", icon: ShieldCheck },
  { id: "p7", label: "UAT", icon: UserCheck },
  { id: "p8", label: "Deployment", icon: Rocket },
];

export const STAGE_IO_DEFAULTS = {
  p1: {
    inputs: [
      { text: "Problem Statement", isMandatory: true },
      { text: "Business Objective", isMandatory: false },
    ],
    outputs: [
      { text: "BRD Document", isMandatory: true },
      { text: "User Stories Document", isMandatory: true },
    ],
  },

  p2: {
    inputs: [
      { text: "User Stories Document", isMandatory: true },
      { text: "NFR Tabel", isMandatory: true },
    ],
    outputs: [
      { text: "Sprint Plan", isMandatory: true },
      { text: "Dependency Graph", isMandatory: true },
      { text: "Risk Mitigation Plan", isMandatory: false },
    ],
  },

  p3: {
    inputs: [
      { text: "BRD & NFR Document", isMandatory: true },
      { text: "Functional Specs", isMandatory: true },
      { text: "Sprint Plan & Dependency Graph", isMandatory: false },
    ],
    outputs: [
      { text: "Architecture Blueprint", isMandatory: true },
      { text: "System Design Diagram", isMandatory: true },
      { text: "API Contract", isMandatory: true },
    ],
  },

  p4: {
    inputs: [
      { text: "Architecture Blueprint", isMandatory: true },
      { text: "API Contract", isMandatory: true },
      { text: "Design Specification", isMandatory: false },
    ],
    outputs: [
      { text: "Source Code", isMandatory: true },
      { text: "Unit Test Results", isMandatory: true },
    ],
  },

  p5: {
    inputs: [
      { text: "Source Code", isMandatory: true },
      { text: "Test Plan", isMandatory: true },
    ],
    outputs: [
      { text: "Test Reports", isMandatory: true },
      { text: "Bug Report", isMandatory: true },
    ],
  },

  p6: {
    inputs: [
      { text: "Verified Code", isMandatory: true },
      { text: "BRD & NFR Document", isMandatory: true },
      { text: "Compliance Standards", isMandatory: false },
    ],
    outputs: [
      { text: "Performance Report", isMandatory: true },
      { text: "Security Audit Log", isMandatory: true },
      { text: "Optimization Guide", isMandatory: false },
    ],
  },

  p7: {
    inputs: [
      { text: "BRD Document", isMandatory: true },
      { text: "Acceptance Criteria", isMandatory: true },
      { text: "Verified Code", isMandatory: true },
    ],
    outputs: [
      { text: "UAT Sign-off", isMandatory: true },
      { text: "UAT Summary", isMandatory: false },
    ],
  },

  p8: {
    inputs: [
      { text: "Software Artifacts", isMandatory: true },
      { text: "Test Report", isMandatory: true },
      { text: "Rollback Plan", isMandatory: true },
    ],
    outputs: [
      { text: "Live Environment URL", isMandatory: true },
      { text: "Deployment Log", isMandatory: true },
    ],
  },
};

export const phaseDependencies = {
  planning: "requirements",
  architecture: "planning",
  development: "architecture",
  testing: "development",
  nfr: "testing",
};

export const PHASE_REPO_CONFIG = {
  p1: ["doc"], // Requirements
  p2: ["doc"], // Planning
  p3: ["doc"], // Architecture
  p4: ["code", "doc"], // Development (Both)
  p5: ["code"], // Testing
  p6: ["code"], // NFR Testing
  p7: ["doc"], // UAT
  p8: ["code"], // Deployment
};

// From Dashboard

export const MOCK_PROJECT = { 
  id: 1, 
  name: 'E-commerce Platform V2', 
  status: 'Running', 
  stage: 'Deployment', 
  cost: '$1,245.50', 
  created: '2026-03-15', 
  pending: true, 
  progress: 7,
  stages: [
    { id: 'G1', name: 'Requirements', state: 'approved' },
    { id: 'G2', name: 'Planning', state: 'approved' },
    { id: 'G3', name: 'Architecture', state: 'approved' },
    { id: 'G4', name: 'Design', state: 'approved' },
    { id: 'G5', name: 'Development', state: 'approved' },
    { id: 'G6', name: 'Code Review', state: 'approved' },
    { id: 'G7', name: 'Testing', state: 'gate_pending' },
    { id: 'G8', name: 'Security', state: 'pending' },
    { id: 'G9', name: 'UAT', state: 'pending' },
    { id: 'G10', name: 'Deployment', state: 'pending' },
  ],
};

export const PROJECT_STATUS_STYLES = {
  Running: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  Paused: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
  Completed: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  Failed: 'bg-red-500/10 text-red-400 border-red-500/20',
};
