import React, { useState, useRef, useEffect } from "react";
import { 
  LayoutDashboard, PanelLeftOpen, PanelLeftClose, 
  Bell, BarChart3, Terminal, User, LogOut, ChevronUp 
} from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";

import Login from "../../features/auth/Login";

export default function Sidebar({ projects = [] }) {
  const [leftCollapsed, setLeftCollapsed] = useState(false);
  const [showAdminMenu, setShowAdminMenu] = useState(false);
  const adminMenuRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();

  const [user, setUser] = useState({ name: "Praveen", role: "Developer" });

  useEffect(() => {
    const savedUser = localStorage.getItem("currentUser");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const pendingGatesCount = projects.filter(p => p.pending || p.status === 'Needs Review').length;
  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("currentUser");
    navigate("/login");
  };

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (adminMenuRef.current && !adminMenuRef.current.contains(event.target)) {
        setShowAdminMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <aside 
      className={`
        /* 🟢 Always absolute to allow the 'overlap' on expansion 🟢 */
        absolute left-0 top-0 bottom-0 
        z-[100] 
        border-r border-zinc-800/50 
        flex flex-col bg-[#09090b] 
        transition-all duration-300 shrink-0
        /* 🟢 Closed: Matches the main window's padding. Open: Overlaps 🟢 */
        ${leftCollapsed ? 'w-20 shadow-none' : 'w-64 shadow-[20px_0_60px_rgba(0,0,0,0.9)]'}
      `}
    >
      {/* LOGO SECTION */}
      <div className="p-6 flex items-center justify-between">
        {!leftCollapsed && (
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-violet-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-violet-600/20">
              <LayoutDashboard size={20} className="text-white" />
            </div>
            <span className="font-bold text-lg tracking-tighter uppercase whitespace-nowrap text-white">
              ELITE<span className="text-violet-500 italic font-black"> AI</span> SQUAD
            </span>
          </div>
        )}
        <button onClick={() => setLeftCollapsed(!leftCollapsed)} className="p-1.5 hover:bg-zinc-800 rounded-md text-zinc-500 mx-auto transition-colors">
          {leftCollapsed ? <PanelLeftOpen size={18} /> : <PanelLeftClose size={18} />}
        </button>
      </div>

      <nav className="flex-1 px-3 space-y-1.5">
        <button 
          onClick={() => navigate('/action-center')} 
          className={`w-full flex items-center ${leftCollapsed ? 'justify-center' : 'justify-between'} px-4 py-3 mb-6 rounded-2xl transition-all group border
            ${isActive('/action-center') 
              ? 'bg-red-500/10 border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.1)]' 
              : 'bg-red-500/[0.03] border-red-500/10 hover:bg-red-500/10 hover:border-red-500/30'}`}
        >
          <div className="flex items-center gap-3">
            <Bell size={18} className={`${isActive('/action-center') ? 'text-red-500' : 'text-red-400/80'} ${pendingGatesCount > 0 ? 'animate-pulse' : ''}`} />
            {!leftCollapsed && (
              <span className={`text-[11px] font-black uppercase tracking-wider ${isActive('/action-center') ? 'text-red-500' : 'text-red-400/80'}`}>
                Pending Gate
              </span>
            )}
          </div>
          {!leftCollapsed && (
            <span className="bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full font-black shadow-lg shadow-red-500/40">
              {pendingGatesCount || 1}
            </span>
          )}
        </button>

        <NavItem icon={LayoutDashboard} label="Projects" active={isActive('/')} collapsed={leftCollapsed} onClick={() => navigate('/')} />
        <NavItem icon={BarChart3} label="Metrics" collapsed={leftCollapsed} />
        <NavItem icon={Terminal} label="System" collapsed={leftCollapsed} />
      </nav>

      {/* ADMIN FOOTER */}
      <div className="p-4 border-t border-zinc-800/50 relative" ref={adminMenuRef}>
        <AnimatePresence>
          {showAdminMenu && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute bottom-20 left-4 right-4 bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl z-[60]"
            >
              <button 
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3.5 text-rose-400 hover:bg-rose-500/10 transition-colors group"
              >
                <LogOut size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">Logout</span>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <button 
          onClick={() => setShowAdminMenu(!showAdminMenu)}
          className={`w-full flex items-center ${leftCollapsed ? 'justify-center' : 'gap-3 px-3'} py-3 rounded-2xl bg-zinc-900/30 border ${showAdminMenu ? 'border-violet-500/50' : 'border-transparent'} hover:border-zinc-800 transition-all group`}
        >
          <div className="w-10 h-10 rounded-full bg-violet-600/10 border border-violet-500/20 flex items-center justify-center shrink-0">
            <User size={20} className="text-violet-500" />
          </div>
          {!leftCollapsed && (
            <div className="overflow-hidden flex-1 text-left">
              <p className="text-xs font-black truncate text-zinc-100 uppercase tracking-tight leading-none mb-1">
                {user.name}
              </p>
              <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest leading-none truncate">
                {user.role}
              </p>
            </div>
          )}
          {!leftCollapsed && <ChevronUp size={14} className={`text-zinc-600 transition-transform ${showAdminMenu ? 'rotate-180' : ''}`} />}
        </button>
      </div>
    </aside>
  );
}

function NavItem({ icon: Icon, label, active, collapsed, onClick }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl transition-all border-2 border-transparent
        ${active 
          ? 'bg-[#18181b] text-violet-400 border-violet-500/10 shadow-xl shadow-black/20' 
          : 'text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800/50'}`}
    >
      <Icon size={20} className={active ? "text-violet-500" : ""} />
      {!collapsed && <span className="text-[11px] font-black uppercase tracking-wider">{label}</span>}
    </button>
  );
}