import { forwardRef } from 'react';

const Select = forwardRef(({ 
  label, 
  error, 
  options = [],
  required = false,
  placeholder = 'Select...',
  className = '', 
  containerClassName = '',
  ...props 
}, ref) => {
  const baseStyles = 'w-full bg-black/40 border rounded-xl p-2.5 text-[10px] font-bold outline-none focus:border-violet-500/50 transition-all';
  
  const errorStyles = error ? 'border-rose-500/30' : 'border-white/10';
  const valueStyles = props.value ? 'text-white' : 'text-slate-500';

  return (
    <div className={containerClassName}>
      {label && (
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1 mb-3 flex items-center gap-2">
          {label}
          {required && <span className="text-rose-500 ml-0.5">*</span>}
        </label>
      )}
      <select
        ref={ref}
        className={`${baseStyles} ${errorStyles} ${valueStyles} ${className}`}
        {...props}
      >
        <option value="" disabled>
          {placeholder}
        </option>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      {error && (
        <p className="text-rose-400 text-[10px] mt-1 ml-1">{error}</p>
      )}
    </div>
  );
});

Select.displayName = 'Select';

export default Select;
