import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';

const Toggle = ({ 
  checked = false, 
  onChange, 
  label,
  size = 'md',
  disabled = false,
  className = '' 
}) => {
  const sizes = {
    sm: { container: 'w-10 h-5', thumb: 'w-4 h-4', translate: 20, icon: 10 },
    md: { container: 'w-14 h-7', thumb: 'w-5 h-5', translate: 28, icon: 12 },
    lg: { container: 'w-16 h-8', thumb: 'w-6 h-6', translate: 32, icon: 14 },
  };

  const currentSize = sizes[size];

  return (
    <div className={`flex items-center gap-4 ${className}`}>
      {label && (
        <span className="text-[10px] font-black uppercase tracking-widest text-slate-300">
          {label}
        </span>
      )}
      <div
        onClick={() => !disabled && onChange?.(!checked)}
        className={`relative ${currentSize.container} rounded-full cursor-pointer transition-all duration-300 p-1 ${
          checked
            ? 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
            : 'bg-slate-700'
        } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <motion.div
          animate={{ x: checked ? currentSize.translate : 0 }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
          className={`${currentSize.thumb} bg-white rounded-full shadow-lg flex items-center justify-center`}
        >
          {checked ? (
            <Check size={currentSize.icon} className="text-emerald-600" strokeWidth={4} />
          ) : (
            <X size={currentSize.icon} className="text-slate-400" strokeWidth={4} />
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default Toggle;
