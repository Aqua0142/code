import { forwardRef } from 'react';

const Input = forwardRef(({ 
  label, 
  error, 
  icon: Icon,
  required = false,
  className = '', 
  containerClassName = '',
  ...props 
}, ref) => {
  const baseStyles = 'w-full p-3 bg-white/5 border border-white/20 rounded-xl outline-none transition-all hover:border-violet-500/50 focus:border-violet-500 text-slate-100 text-sm shadow-inner placeholder:text-slate-600';
  
  const errorStyles = error ? 'border-rose-500/50 focus:border-rose-500' : '';

  return (
    <div className={containerClassName}>
      {label && (
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1 mb-3 flex items-center gap-2">
          {label}
          {required && <span className="text-rose-500 ml-0.5">*</span>}
        </label>
      )}
      <div className="relative">
        {Icon && (
          <Icon 
            size={16} 
            className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" 
          />
        )}
        <input
          ref={ref}
          className={`${baseStyles} ${errorStyles} ${Icon ? 'pl-12' : ''} ${className}`}
          {...props}
        />
      </div>
      {error && (
        <p className="text-rose-400 text-[10px] mt-1 ml-1">{error}</p>
      )}
    </div>
  );
});

Input.displayName = 'Input';

export default Input;
