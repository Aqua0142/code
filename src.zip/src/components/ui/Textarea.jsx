import { forwardRef } from 'react';

const Textarea = forwardRef(({ 
  label, 
  error, 
  required = false,
  className = '', 
  containerClassName = '',
  rows = 4,
  ...props 
}, ref) => {
  const baseStyles = 'w-full p-3 bg-white/5 border border-white/20 rounded-xl outline-none transition-all hover:border-violet-500/50 focus:border-violet-500 text-slate-100 text-sm shadow-inner placeholder:text-slate-600 resize-y custom-scrollbar';
  
  const errorStyles = error ? 'border-rose-500/50 focus:border-rose-500' : '';

  return (
    <div className={containerClassName}>
      {label && (
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1 mb-3 flex items-center gap-2">
          {label}
          {required && <span className="text-rose-500 ml-0.5">*</span>}
        </label>
      )}
      <textarea
        ref={ref}
        rows={rows}
        className={`${baseStyles} ${errorStyles} ${className}`}
        {...props}
      />
      {error && (
        <p className="text-rose-400 text-[10px] mt-1 ml-1">{error}</p>
      )}
    </div>
  );
});

Textarea.displayName = 'Textarea';

export default Textarea;
