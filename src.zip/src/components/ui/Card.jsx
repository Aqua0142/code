const Card = ({ 
  children, 
  variant = 'default',
  padding = 'md',
  className = '',
  ...props 
}) => {
  const baseStyles = 'rounded-3xl border transition-all';
  
  const variants = {
    default: 'bg-white/5 border-white/10',
    elevated: 'bg-[#1a1d24] border-white/10 shadow-2xl',
    gradient: 'bg-gradient-to-br from-[#1a1d24] to-[#161920] border-violet-500/20 shadow-2xl',
    dark: 'bg-[#08080a] border-white/10',
  };

  const paddings = {
    none: '',
    sm: 'p-3',
    md: 'p-5',
    lg: 'p-6',
  };

  return (
    <div 
      className={`${baseStyles} ${variants[variant]} ${paddings[padding]} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};

export default Card;
