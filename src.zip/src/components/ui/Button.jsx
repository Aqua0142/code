import { forwardRef } from 'react';

const Button = forwardRef(({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  className = '', 
  disabled = false,
  ...props 
}, ref) => {
  const baseStyles = 'font-bold uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-2';
  
  const variants = {
    primary: 'bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-600/20',
    secondary: 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10',
    success: 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg',
    danger: 'bg-rose-600 hover:bg-rose-500 text-white',
    ghost: 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10',
    outline: 'bg-transparent border-2 border-violet-500 text-violet-400 hover:bg-violet-500/10',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-[10px] rounded-lg',
    md: 'px-5 py-2.5 text-xs rounded-xl',
    lg: 'px-8 py-3 text-xs rounded-xl',
  };

  const disabledStyles = 'opacity-50 cursor-not-allowed pointer-events-none';

  return (
    <button
      ref={ref}
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${disabled ? disabledStyles : ''} ${className}`}
      disabled={disabled}
      {...props}
    >
      {children}
    </button>
  );
});

Button.displayName = 'Button';

export default Button;
