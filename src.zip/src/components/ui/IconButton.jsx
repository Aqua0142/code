import { forwardRef } from 'react';

const IconButton = forwardRef(({ 
  icon: Icon,
  variant = 'default',
  size = 'md',
  className = '',
  ...props 
}, ref) => {
  const baseStyles = 'rounded-xl transition-all active:scale-95 flex items-center justify-center';
  
  const variants = {
    default: 'bg-slate-800/50 hover:bg-slate-700 text-slate-400 border border-white/10',
    primary: 'bg-violet-600 hover:bg-violet-500 text-white',
    danger: 'bg-rose-600 hover:bg-rose-500 text-white',
    ghost: 'bg-transparent hover:bg-white/10 text-slate-400',
  };

  const sizes = {
    sm: 'p-1.5',
    md: 'p-2.5',
    lg: 'p-3',
  };

  const iconSizes = {
    sm: 14,
    md: 18,
    lg: 20,
  };

  return (
    <button
      ref={ref}
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {Icon && <Icon size={iconSizes[size]} />}
    </button>
  );
});

IconButton.displayName = 'IconButton';

export default IconButton;
