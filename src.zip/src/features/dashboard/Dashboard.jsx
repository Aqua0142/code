import React, { useState, useMemo, useEffect } from 'react';
import { 
  Plus, PlusCircle, FolderInput, Search as SearchIcon, 
  ArrowUpDown, ArrowUp, ArrowDown 
} from 'lucide-react';
import { useNavigate, Outlet, useLocation } from "react-router-dom";
import { useProjects } from '../../hooks/useProjects';
import ProjectCard from './ProjectCard';

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { projects, setProjects, deleteProject } = useProjects();

  const itemsPerPage = 12;
  const [currentPage, setCurrentPage] = useState(1);
  const [filter, setFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState(''); 
  const [showCreateOptions, setShowCreateOptions] = useState(false);
  const [activeMenu, setActiveMenu] = useState(null); 
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [sortBy, setSortBy] = useState('Date'); 
  const [sortOrder, setSortOrder] = useState('desc');

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filter, searchQuery, sortBy, sortOrder]);

  const isDashboardHome = location.pathname === "/" || location.pathname === "/dashboard";

  const handleCreateNew = () => {
    setShowCreateOptions(false);
    navigate("/setup");
  };

  const handleEditClick = (project) => {
    setActiveMenu(null);
    navigate(`/edit/${project.id}`);
  };

  const handleDelete = (id) => {
    deleteProject(id);
    setActiveMenu(null);
  };

  const handleSort = (type) => {
    if (sortBy === type) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(type);
      setSortOrder('desc');
    }
  };

  // Combined Filter, Sort, and Paginate Logic
  const { paginatedProjects, totalPages } = useMemo(() => {
    let result = projects.filter(p => {
      const matchesFilter = filter === 'All' || p.status === filter;
      const matchesSearch = (p.name || "").toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    });

    result.sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'Date') comparison = new Date(a.created) - new Date(b.created);
      else if (sortBy === 'Cost') {
        const valA = parseFloat((a.cost || "$0").replace(/[$,]/g, ''));
        const valB = parseFloat((b.cost || "$0").replace(/[$,]/g, ''));
        comparison = valA - valB;
      } else if (sortBy === 'Progress') comparison = a.progress - b.progress;
      return sortOrder === 'desc' ? -comparison : comparison;
    });

    const total = Math.ceil(result.length / itemsPerPage);
    const start = (currentPage - 1) * itemsPerPage;
    return {
      paginatedProjects: result.slice(start, start + itemsPerPage),
      totalPages: total
    };
  }, [projects, filter, searchQuery, sortBy, sortOrder, currentPage, itemsPerPage]);

  return (
    <div className="flex h-screen bg-[#09090b] text-zinc-100 font-sans overflow-hidden" 
      onClick={() => { 
        setShowCreateOptions(false); 
        setActiveMenu(null); 
        setShowSortMenu(false); 
      }}
    >
      <main className="flex-1 flex flex-col min-w-0 bg-zinc-950/30 overflow-hidden">
        {isDashboardHome ? (
          <>
            <header className="h-20 flex items-center justify-between px-8 bg-[#09090b]/40 backdrop-blur-md border-b border-zinc-800/30 shrink-0 relative z-50">
              <div className="flex gap-2 overflow-x-auto scrollbar-hide">
                {['All', 'Running', 'Paused', 'Completed', 'Failed'].map((s) => (
                  <button 
                    key={s} 
                    onClick={() => setFilter(s)} 
                    className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all border ${filter === s ? 'bg-zinc-100 text-zinc-950 border-white' : 'bg-zinc-900/50 text-zinc-500 border-zinc-800 hover:text-zinc-200'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <div className="relative group">
                  <SearchIcon 
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-violet-400 transition-colors" 
                    size={16} 
                  />
                  <input 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search Project..." 
                    className="h-8 bg-zinc-900 border border-zinc-800 rounded-xl pl-10 pr-4 text-sm w-44 focus:w-60 focus:border-violet-500/50 outline-none transition-all text-white placeholder:text-zinc-600"
                  />
                </div>

                <div className="relative">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setShowSortMenu(!showSortMenu); }}
                    className="h-8 flex items-center gap-2 px-4 bg-zinc-900 border border-zinc-800 rounded-xl text-xs font-bold text-zinc-400 hover:text-zinc-200 transition-all active:scale-95"
                  >
                    <ArrowUpDown size={14} className={sortBy !== 'Date' ? 'text-violet-400' : ''} />
                    <span>Sort: {sortBy}</span>
                    {sortOrder === 'asc' ? <ArrowUp size={12} className="text-violet-400" /> : <ArrowDown size={12} className="text-violet-400" />}
                  </button>

                  {showSortMenu && (
                    <div className="absolute right-0 mt-2 w-40 bg-[#1c1c21] border border-zinc-800 rounded-xl shadow-2xl py-1 z-50">
                      {['Date', 'Cost', 'Progress'].map((type) => (
                        <button 
                          key={type} 
                          onClick={() => handleSort(type)} 
                          className={`w-full px-4 py-2.5 text-left text-xs font-bold flex items-center justify-between ${sortBy === type ? 'text-violet-400' : 'text-zinc-400 hover:bg-zinc-800'}`}
                        >
                          {type}
                          {sortBy === type && (sortOrder === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="relative">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setShowCreateOptions(!showCreateOptions); }}
                    className="h-8 bg-violet-600 hover:bg-violet-500 text-white px-5 rounded-xl text-xs font-bold shadow-lg shadow-violet-600/20 active:scale-95 transition-all flex items-center gap-2"
                  >
                    <Plus size={16} /> Create Project
                  </button>

                  {showCreateOptions && (
                    <div className="absolute right-0 mt-3 w-56 bg-[#16161a] border border-zinc-800 rounded-2xl shadow-2xl py-2 z-[200]">
                      <button onClick={handleCreateNew} className="w-full px-4 py-3 text-left hover:bg-zinc-800 flex items-center gap-3 transition-colors">
                        <PlusCircle className="text-violet-400" size={18} />
                        <div>
                          <p className="text-xs font-bold text-zinc-200">New Project</p>
                          <p className="text-[10px] text-zinc-500">Initialize from scratch</p>
                        </div>
                      </button>
                      <button onClick={() => navigate("/import")} className="w-full px-4 py-3 text-left hover:bg-zinc-800 flex items-center gap-3 transition-colors border-t border-zinc-800/50">
                        <FolderInput className="text-sky-400" size={18} />
                        <div>
                          <p className="text-xs font-bold text-zinc-200">Add Existing</p>
                          <p className="text-[10px] text-zinc-500">Import from GitHub/Jira</p>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </header>

            <div className="flex-1 overflow-y-auto p-5 flex flex-col">
              {paginatedProjects.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center">
                  <h3 className="text-lg font-bold text-zinc-400 uppercase">No Projects Found</h3>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 pb-6">
                    {paginatedProjects.map((p) => (
                      <ProjectCard 
                        key={p.id} 
                        project={p} 
                        onClick={() => navigate(`/project/${p.id}`)}
                        onEdit={() => handleEditClick(p)} 
                        onDelete={() => handleDelete(p.id)}                       
                        isMenuOpen={activeMenu === p.id}
                        onToggleMenu={(e) => { e.stopPropagation(); setActiveMenu(activeMenu === p.id ? null : p.id); }}
                      />
                    ))}
                  </div>

                  {totalPages > 1 && (
                    <div className="flex items-center justify-center gap-2 py-6">
                      <button
                        onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                        disabled={currentPage === 1}
                        className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-bold text-zinc-400 hover:text-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                      >
                        Previous
                      </button>
                      
                      <div className="flex gap-1">
                        {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                          <button
                            key={page}
                            onClick={() => setCurrentPage(page)}
                            className={`w-10 h-10 rounded-lg text-xs font-bold transition-all ${
                              currentPage === page
                                ? 'bg-violet-600 text-white border border-violet-500'
                                : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-zinc-200'
                            }`}
                          >
                            {page}
                          </button>
                        ))}
                      </div>

                      <button
                        onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                        disabled={currentPage === totalPages}
                        className="px-4 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-bold text-zinc-400 hover:text-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                      >
                        Next
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>
          </>
        ) : (
          <Outlet context={{ projects, setProjects }} />
        )}
      </main>
    </div>
  );
}
