import React from 'react';
import { MoreHorizontal, Edit2, Trash2 } from 'lucide-react';
import { PROJECT_STATUS_STYLES, STAGES } from '../../utils/constants';

export default function ProjectCard({ project, onEdit, onDelete, isMenuOpen, onToggleMenu, onClick }) {
  const phaseIds = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];

  const getPhaseStatus = (phaseId) => {
    if (project.selectedPhaseIds && !project.selectedPhaseIds.includes(phaseId)) {
      return 'skipped';
    }
    const currentStageId = phaseIds.find(id => 
      STAGES.find(s => s.id === id)?.label === project.stage
    ) || 'p1';

    const currentIndex = phaseIds.indexOf(currentStageId);
    const targetIndex = phaseIds.indexOf(phaseId);

    if (targetIndex < currentIndex) return 'completed';
    if (targetIndex === currentIndex) return 'active';
    return 'unreached';
  };

  const getMiniDotColor = (status) => {
    switch (status) {
      case 'completed': 
        return 'bg-emerald-500';
      case 'active': 
        return 'bg-violet-500';
      case 'unreached': 
        return 'bg-amber-500';
      case 'skipped': 
        return 'bg-zinc-900 border border-zinc-600 border-dashed';
      default: 
        return 'bg-zinc-800';
    }
  };

  return (
    <div 
      onClick={onClick} 
      className="cursor-pointer bg-[#16161a]/60 border border-zinc-500/60 rounded-[1.5rem] p-5 group hover:border-violet-500/80 transition-all flex flex-col h-[200px] relative"
    >
      <div className="flex justify-between items-start mb-2 shrink-0">
        <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black uppercase border ${PROJECT_STATUS_STYLES[project.status]}`}>
          {project.status}
        </span>
        <div className="relative">
          <button 
            onClick={(e) => { 
              e.stopPropagation(); 
              onToggleMenu(e); 
            }} 
            className="text-zinc-700 hover:text-white p-1 rounded-md hover:bg-zinc-800"
          >
            <MoreHorizontal size={20} />
          </button>
          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-32 bg-[#1c1c21] border border-zinc-800 rounded-xl py-2 z-[110] shadow-2xl">
              <button 
                onClick={(e) => { e.stopPropagation(); onEdit(); }} 
                className="w-full px-4 py-2 text-left text-xs text-zinc-300 hover:bg-zinc-800 flex items-center gap-2 font-bold"
              >
                <Edit2 size={12} className="text-violet-400" /> Edit
              </button>
              <button 
                onClick={(e) => { e.stopPropagation(); onDelete(); }} 
                className="w-full px-4 py-2 text-left text-xs text-red-400 hover:bg-red-500/10 flex items-center gap-2 border-t border-zinc-800/50 mt-1 font-bold"
              >
                <Trash2 size={12} /> Delete
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-center">
        <h3 className="text-lg font-bold text-zinc-100 group-hover:text-violet-400 truncate">{project.name}</h3>
        <p className="text-zinc-500 text-[10px] font-medium uppercase tracking-widest mb-4 italic">
          Stage: {project.stage || 'Initializing'}
        </p>
        
        <div className="my-2 flex gap-1.5 items-center w-full">
          {phaseIds.map((id) => (
            <div 
              key={id} 
              className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${getMiniDotColor(getPhaseStatus(id))}`} 
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 border-t border-zinc-800/80 pt-4 mt-auto">
        <div className="text-left">
          <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest leading-none mb-1">Cost</p>
          <p className="text-xs font-mono text-zinc-300 font-bold">${project.totalCost || project.cost}</p>
        </div>
        <div className="text-right">
          <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-widest leading-none mb-1">Created</p>
          <p className="text-xs font-mono text-zinc-300 font-bold">{project.created}</p>
        </div>
      </div>
    </div>
  );
}
