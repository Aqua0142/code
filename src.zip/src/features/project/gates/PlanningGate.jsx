import React from "react";
import {
  Calendar,
  Layers,
  AlertCircle,
  GripVertical,
  Trash2,
  Zap,
  ChevronRight
} from "lucide-react";

export default function PlanningGate({ project, onUpdateProject, editMode }) {
  const stories = project?.requirements || [];
  const sprints = ["Sprint 1", "Sprint 2", "Sprint 3", "Backlog"];
  const velocityTarget = 15;

  const setStories = (newStories) => {
    onUpdateProject({
      ...project,
      requirements: newStories,
    });
  };

  const updateStory = (id, field, value) => {
    setStories(stories.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const moveSprint = (id, newSprint) => {
    updateStory(id, "sprint", newSprint);
  };

  const deleteStory = (id) => {
    setStories(stories.filter(s => s.id !== id));
  };

  const calculateSprintPoints = (sprintName) => {
    return stories
      .filter(s => (s.sprint || "Backlog") === sprintName)
      .reduce((acc, curr) => acc + (Number(curr.points) || 0), 0);
  };

  const totalEffort = stories.reduce((acc, s) => acc + (Number(s.points) || 0), 0);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      {/* --- STRATEGIC OVERVIEW --- */}
      <section className="grid grid-cols-3 gap-4">
        <div className="bg-[#0b0b0d] border border-zinc-800 p-5 rounded-2xl shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-violet-500 opacity-50" />
          <div className="text-[9px] text-zinc-500 uppercase font-black tracking-widest mb-1">Target Velocity</div>
          <div className="text-2xl font-mono text-violet-400">{velocityTarget} <span className="text-[10px] text-zinc-600">pts/spr</span></div>
        </div>
        <div className="bg-[#0b0b0d] border border-zinc-800 p-5 rounded-2xl shadow-xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500 opacity-50" />
          <div className="text-[9px] text-zinc-500 uppercase font-black tracking-widest mb-1">Total Backlog</div>
          <div className="text-2xl font-mono text-emerald-400">{totalEffort} <span className="text-[10px] text-zinc-600">pts</span></div>
        </div>
        <div className="bg-[#0b0b0d] border border-zinc-800 p-5 rounded-2xl shadow-xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-1 h-full bg-orange-500 opacity-50" />
          <div className="text-[9px] text-zinc-500 uppercase font-black tracking-widest mb-1">Allocation Risk</div>
          <div className="text-2xl font-mono text-orange-400">{totalEffort > (velocityTarget * 3) ? "HIGH" : "LOW"}</div>
        </div>
      </section>

      {/* --- SPRINT CHANNELS --- */}
      <div className="space-y-12">
        {sprints.map(sprint => {
          const sprintStories = stories.filter(item => (item.sprint || "Backlog") === sprint);
          const totalPoints = calculateSprintPoints(sprint);
          const isOverCapacity = totalPoints > velocityTarget && sprint !== "Backlog";

          return (
            <div key={sprint} className="space-y-4">
              <div className="flex items-center justify-between border-b border-zinc-800/50 pb-3 px-1">
                <div className="flex items-center gap-3">
                  <div className={`p-1.5 rounded-lg ${sprint === 'Backlog' ? 'bg-zinc-800/50 text-zinc-400' : 'bg-violet-500/10 text-violet-400'}`}>
                    <Calendar size={14} />
                  </div>
                  <h3 className="text-sm font-bold text-zinc-100 tracking-tight">{sprint}</h3>
                  <div className={`text-[10px] px-2 py-0.5 rounded font-mono border ${
                    isOverCapacity 
                    ? "bg-red-500/10 text-red-400 border-red-500/20" 
                    : "bg-zinc-900 text-zinc-500 border-zinc-800"
                  }`}>
                    {totalPoints} / {sprint === "Backlog" ? "∞" : velocityTarget} PTS
                  </div>
                </div>
                {isOverCapacity && (
                  <div className="flex items-center gap-1.5 text-[9px] font-black text-red-500 uppercase tracking-tighter animate-pulse">
                    <AlertCircle size={12} /> Capacity Breach
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 gap-3">
                {sprintStories.map(story => (
                  <div
                    key={story.id}
                    className={`group relative bg-[#09090b] border ${
                      story.isBlocked ? "border-red-900/40 bg-red-950/5" : "border-zinc-800/60"
                    } rounded-2xl p-4 hover:border-zinc-500 transition-all shadow-sm`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        {editMode && (
                          <div className="mt-1 cursor-grab active:cursor-grabbing text-zinc-700 hover:text-zinc-500 transition-colors">
                            <GripVertical size={16} />
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                             <span className="text-[9px] font-mono text-zinc-600 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800">{story.id}</span>
                             {story.isBlocked && (
                                <span className="text-[8px] font-black text-red-500 uppercase bg-red-500/10 px-1.5 rounded">Blocked</span>
                             )}
                          </div>
                          <h4 className="text-xs font-semibold text-zinc-200 truncate">{story.title}</h4>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        {editMode ? (
                          <div className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-lg px-2 py-1">
                             <span className="text-[9px] font-black text-zinc-600 uppercase">SPRINT</span>
                             <select
                                value={story.sprint || "Backlog"}
                                onChange={(e) => moveSprint(story.id, e.target.value)}
                                className="bg-transparent text-[10px] font-bold text-violet-400 outline-none cursor-pointer"
                              >
                                {sprints.map(s => <option key={s} value={s}>{s}</option>)}
                              </select>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5 text-[10px] font-bold text-zinc-500 bg-zinc-900/80 px-2.5 py-1.5 rounded-lg border border-zinc-800">
                            <Zap size={10} className="text-amber-500" />
                            {story.points}
                          </div>
                        )}
                      </div>
                    </div>

                    {editMode && (
                      <div className="mt-4 pt-3 border-t border-zinc-800/50 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                           <div className="flex items-center gap-2">
                              <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest">Weight:</label>
                              <input
                                type="number"
                                value={story.points}
                                onChange={(e) => updateStory(story.id, "points", e.target.value)}
                                className="w-10 bg-black border border-zinc-700 rounded px-1 text-[10px] text-center text-emerald-400 font-mono"
                              />
                           </div>
                           <button
                              onClick={() => updateStory(story.id, "isBlocked", !story.isBlocked)}
                              className={`text-[9px] font-black uppercase px-2 py-1 rounded transition-all ${story.isBlocked ? 'bg-red-500 text-white' : 'bg-zinc-800 text-zinc-500 hover:text-red-400'}`}
                            >
                              {story.isBlocked ? "Unblock" : "Flag Blocker"}
                            </button>
                        </div>
                        <button onClick={() => deleteStory(story.id)} className="text-zinc-700 hover:text-red-500 transition-colors p-1">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}

                {sprintStories.length === 0 && (
                  <div className="border border-dashed border-zinc-800/50 rounded-2xl py-10 flex flex-col items-center justify-center text-zinc-700 bg-zinc-900/5">
                    <Layers size={20} className="mb-2 opacity-20" />
                    <p className="text-[10px] font-bold uppercase tracking-widest italic opacity-40">No items allocated</p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}