import React from "react";
import {
  Database,
  Globe,
  ShieldCheck,
  Server,
  Plus,
  Trash2,
  AlertCircle,
  Code2,
  ChevronRight,
  MessageSquare
} from "lucide-react";

export default function ArchitectureGate({ project, onUpdateProject, editMode }) {
  // Pull data from project or use fallbacks
  const techStack = project?.architecture?.techStack || [
    { id: 1, tech: "PostgreSQL", category: "Database", rationale: "Relational data with ACID compliance", alternative: "MongoDB", status: "Approved" },
    { id: 2, tech: "Redis", category: "Caching", rationale: "Low latency session management", alternative: "Memcached", status: "Approved" },
    { id: 3, tech: "Next.js", category: "Frontend", rationale: "SSR capabilities for SEO", alternative: "React SPA", status: "Approved" }
  ];

  const apiContracts = project?.architecture?.apiContracts || [
    { id: "api-1", path: "/auth/login", method: "POST", request: "{ email, password }", response: "{ token, user }" },
    { id: "api-2", path: "/projects", method: "GET", request: "None", response: "Array<Project>" }
  ];

  // Helper to sync changes to global project state
  const syncChanges = (newTech, newApi) => {
    onUpdateProject({
      ...project,
      architecture: {
        techStack: newTech || techStack,
        apiContracts: newApi || apiContracts
      }
    });
  };

  const updateDecision = (id, field, value) => {
    const updated = techStack.map(item => item.id === id ? { ...item, [field]: value } : item);
    syncChanges(updated, null);
  };

  const toggleReview = (id) => {
    const updated = techStack.map(item =>
      item.id === id ? { ...item, status: item.status === "Review" ? "Approved" : "Review" } : item
    );
    syncChanges(updated, null);
  };

  const addEndpoint = () => {
    const newApi = {
      id: `api-${Date.now()}`,
      path: "/new-endpoint",
      method: "GET",
      request: "{}",
      response: "{}"
    };
    syncChanges(null, [...apiContracts, newApi]);
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      
      {/* --- TECH STACK DECISIONS --- */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 border-b border-zinc-800 pb-3">
          <Server size={18} className="text-violet-400" />
          <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-zinc-200">System Blueprint</h3>
        </div>
        
        <div className="grid gap-4">
          {techStack.map((item) => (
            <div key={item.id} className={`group p-5 rounded-2xl border transition-all shadow-xl ${item.status === "Review" ? "bg-orange-500/5 border-orange-500/30" : "bg-[#09090b] border-zinc-800/60"}`}>
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-4">
                  <span className="text-[9px] font-black bg-zinc-800 text-zinc-400 px-2 py-1 rounded-md uppercase tracking-tighter border border-zinc-700">
                    {item.category}
                  </span>
                  {editMode ? (
                    <input
                      className="bg-zinc-900/50 border-b border-violet-500/50 text-sm font-bold text-white outline-none px-2 py-1 focus:bg-zinc-900 transition-all rounded-t-md"
                      value={item.tech}
                      onChange={(e) => updateDecision(item.id, "tech", e.target.value)}
                    />
                  ) : (
                    <h4 className="text-sm font-bold text-zinc-100">{item.tech}</h4>
                  )}
                </div>
                
                {editMode && (
                  <button
                    onClick={() => toggleReview(item.id)}
                    className={`flex items-center gap-2 text-[10px] font-black uppercase px-3 py-1.5 rounded-xl border transition-all ${
                      item.status === "Review"
                      ? "bg-orange-600 text-white border-orange-400 shadow-lg shadow-orange-900/20"
                      : "text-zinc-500 border-zinc-800 hover:border-orange-500/50 hover:text-orange-400"
                    }`}
                  >
                    <MessageSquare size={12} /> {item.status === "Review" ? "Under Audit" : "Flag Decision"}
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-6 bg-black/20 p-4 rounded-xl border border-zinc-800/30">
                <div>
                  <label className="text-[9px] uppercase text-zinc-600 font-black tracking-widest block mb-2">Rationale</label>
                  <p className="text-xs text-zinc-400 italic leading-relaxed">"{item.rationale}"</p>
                </div>
                <div>
                  <label className="text-[9px] uppercase text-zinc-600 font-black tracking-widest block mb-2">Technical Debt / Alts</label>
                  <p className="text-xs text-zinc-500 font-medium">{item.alternative}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- API CONTRACTS --- */}
      <section className="space-y-6">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <Globe size={18} className="text-emerald-400" />
            <h3 className="text-sm font-bold uppercase tracking-[0.2em] text-zinc-200">Interface Contracts</h3>
          </div>
          {editMode && (
            <button 
              onClick={addEndpoint}
              className="text-[10px] font-black uppercase bg-violet-600/10 text-violet-400 border border-violet-500/20 px-4 py-1.5 rounded-xl hover:bg-violet-600/20 transition-all flex items-center gap-2"
            >
              <Plus size={14} /> Register Endpoint
            </button>
          )}
        </div>

        <div className="grid gap-4">
          {apiContracts.map((api) => (
            <div key={api.id} className="bg-[#09090b] border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
              <div className="bg-zinc-900/40 px-5 py-3 flex items-center justify-between border-b border-zinc-800/50">
                <div className="flex items-center gap-4">
                  <span className={`text-[10px] font-black px-2.5 py-1 rounded-md border ${
                    api.method === "POST" ? "bg-amber-500/10 text-amber-500 border-amber-500/20" : "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"
                  }`}>
                    {api.method}
                  </span>
                  <code className="text-[11px] font-mono text-zinc-300 tracking-tight">{api.path}</code>
                </div>
                <div className="flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                   <span className="text-[8px] font-black text-zinc-500 uppercase tracking-tighter">Schema Valid</span>
                </div>
              </div>
              <div className="p-5 grid grid-cols-2 gap-6 bg-zinc-950/30">
                <div>
                  <div className="text-[9px] text-zinc-600 uppercase font-black mb-3 flex items-center gap-2 tracking-widest">
                    <Code2 size={10} className="text-violet-500" /> Request Payload
                  </div>
                  <pre className="text-[10px] font-mono text-violet-300 bg-black/40 p-3 rounded-xl border border-zinc-800/50 leading-relaxed overflow-x-auto">
                    {api.request}
                  </pre>
                </div>
                <div>
                  <div className="text-[9px] text-zinc-600 uppercase font-black mb-3 flex items-center gap-2 tracking-widest">
                    <ChevronRight size={10} className="text-emerald-500" /> Response Schema
                  </div>
                  <pre className="text-[10px] font-mono text-emerald-300 bg-black/40 p-3 rounded-xl border border-zinc-800/50 leading-relaxed overflow-x-auto">
                    {api.response}
                  </pre>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- SECURITY & INFRA --- */}
      <section className="bg-violet-600/5 border border-violet-500/20 rounded-[2rem] p-8 relative overflow-hidden group shadow-inner">
        <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <ShieldCheck size={120} className="text-violet-400" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-violet-500/20 rounded-lg text-violet-400">
                <ShieldCheck size={20} />
            </div>
            <h3 className="text-sm font-bold text-zinc-100 tracking-tight">Encryption & Security Protocol</h3>
          </div>
          <p className="text-xs text-zinc-400 leading-relaxed max-w-2xl italic">
            The system utilizes <span className="text-violet-400 font-bold not-italic">OAuth2.0 with JWT</span> for stateless identity management. 
            All cross-origin requests are governed by a strictly defined CORS policy, and sensitive data is encrypted at rest using <span className="text-white font-medium not-italic">AES-256-GCM</span>.
          </p>
        </div>
      </section>
    </div>
  );
}