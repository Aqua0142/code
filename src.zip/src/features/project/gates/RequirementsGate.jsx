import React from "react";
import { Hash, Trash2, Plus, CheckCircle2, ListChecks } from "lucide-react";

export default function RequirementsGate({ project, onUpdateProject, editMode }) {
  // Pull requirements from the project object or default to an empty list
  const stories = project?.requirements || [];

  // Helper to push updates back to the global project state
  const setStories = (newStories) => {
    onUpdateProject({
      ...project,
      requirements: newStories,
    });
  };

  const updateStory = (id, field, value) => {
    setStories(stories.map((s) => (s.id === id ? { ...s, [field]: value } : s)));
  };

  const deleteStory = (id) => {
    setStories(stories.filter((s) => s.id !== id));
  };

  const addStory = (epicName) => {
    console.log("Add Story Triggered for epic:", epicName);
    if (typeof onUpdateProject !== 'function') {
      alert("Error: Update function missing");
      return;
    }

    const newStory = {
      id: `US-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      title: "New User Story",
      epic: epicName || "General",
      description: "As a user, I want to...",
      criteria: "Requirement met when...",
      points: 1,
    };

    const updatedProject = {
      ...project,
      requirements: [...stories, newStory]
    };
    onUpdateProject(updatedProject);
  };

  // Get unique epics; if none exist, start with "General"
  const epics = stories.length > 0 
    ? [...new Set(stories.map((s) => s.epic))] 
    : ["General"];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-10">
      {/* Header Section */}
      <div className="flex flex-col gap-1 border-b border-zinc-800/50 pb-6">
        <h3 className="text-sm font-bold text-violet-400 flex items-center gap-2 uppercase tracking-widest">
          <Hash size={16} /> User Story Backlog
        </h3>
        <p className="text-xs text-zinc-500">
          Review and refine the generated user stories. Use **Override Mode** to manually adjust logic.
        </p>
      </div>

      <div className="space-y-10">
        {epics.map((epic) => (
          <div key={epic} className="space-y-4">
            {/* EPIC HEADER */}
            <div className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.25em] flex items-center justify-between gap-4 px-1">
              <span className="flex-shrink-0 bg-zinc-800/80 text-zinc-300 px-3 py-1 rounded-md border border-zinc-700/50">
                Epic: {epic}
              </span>
              <div className="h-px flex-1 bg-zinc-800/50" />
              {editMode && (
                <button
                  onClick={() => addStory(epic)}
                  className="flex items-center gap-1 text-violet-400 hover:text-violet-300 transition-all font-bold group"
                >
                  <Plus size={14} className="group-hover:rotate-90 transition-transform" /> 
                  ADD STORY
                </button>
              )}
            </div>

            {/* STORIES GRID */}
            <div className="grid grid-cols-1 gap-4">
              {stories
                .filter((s) => s.epic === epic)
                .map((story) => (
                  <div
                    key={story.id}
                    className={`group bg-[#09090b] border ${editMode ? 'border-violet-500/50 ring-1 ring-violet-500/20' : 'border-zinc-800/60'} rounded-2xl p-6 hover:border-violet-500/40 transition-all relative shadow-xl overflow-hidden`}
                  >
                    <div className="absolute top-0 left-0 w-1 h-full bg-zinc-800 group-hover:bg-violet-500 transition-colors" />

                    <div className="flex justify-between items-start mb-4 gap-6">
                      <div className="flex-1">
                        {editMode ? (
                          <input
                            className="bg-zinc-900/50 border-b border-violet-500/50 text-sm font-bold text-zinc-100 outline-none px-2 py-1 w-full transition-all"
                            value={story.title}
                            onChange={(e) => updateStory(story.id, "title", e.target.value)}
                          />
                        ) : (
                          <h4 className="text-sm font-bold text-zinc-100">{story.title}</h4>
                        )}
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[8px] font-black px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 uppercase tracking-tighter">
                          Verified
                        </span>
                        {editMode && (
                          <button 
                            onClick={() => deleteStory(story.id)} 
                            className="text-zinc-600 hover:text-red-400 transition-colors p-1.5 hover:bg-red-500/5 rounded-lg"
                          >
                            <Trash2 size={15} />
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-[9px] font-black text-zinc-600 uppercase tracking-widest mb-1.5 block">Description</label>
                        {editMode ? (
                          <textarea
                            className="w-full bg-[#111114] border border-violet-500/30 rounded-xl p-3 text-xs text-zinc-400 italic outline-none focus:border-violet-500 resize-none min-h-[70px] leading-relaxed transition-all"
                            value={story.description}
                            onChange={(e) => updateStory(story.id, "description", e.target.value)}
                          />
                        ) : (
                          <p className="text-xs text-zinc-400 italic leading-relaxed bg-zinc-900/20 p-3 rounded-xl border border-zinc-800/30">
                            "{story.description}"
                          </p>
                        )}
                      </div>

                      <div className="bg-black/40 p-4 rounded-xl border border-zinc-800/50 flex flex-col gap-2">
                        <div className="flex items-center gap-2">
                           <CheckCircle2 size={12} className="text-violet-500" />
                           <span className="text-[9px] font-black text-zinc-500 uppercase tracking-[0.15em]">Acceptance Criteria</span>
                        </div>
                        {editMode ? (
                          <input
                            className="bg-zinc-900/50 border-b border-violet-500/30 outline-none w-full text-[11px] text-zinc-300 italic font-mono px-1 py-0.5"
                            value={story.criteria}
                            onChange={(e) => updateStory(story.id, "criteria", e.target.value)}
                          />
                        ) : (
                          <p className="text-[11px] text-zinc-300 italic font-mono opacity-80 pl-1">
                            {story.criteria}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              {stories.filter((s) => s.epic === epic).length === 0 && (
                <div className="py-10 text-center border-2 border-dashed border-zinc-900 rounded-[2rem] bg-zinc-900/5">
                   <p className="text-zinc-600 text-xs font-bold uppercase tracking-widest">No active stories in this epic</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}