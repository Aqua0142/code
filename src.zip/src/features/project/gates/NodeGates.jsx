import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  X, CheckCircle2, RotateCcw, Edit3, Save, Clock, 
  Hash, Microscope, ShieldCheck, Send, AlertCircle, 
  Terminal, ListChecks, Info, ArrowLeft, AlertTriangle 
} from "lucide-react";

import RequirementsGate from "./RequirementsGate";
import PlanningGate from "./PlanningGate";
import ArchitectureGate from "./ArchitectureGate";

export default function NodeGates({ nodeId, project, onApprove, onUpdateProject, onClose }) {
  const navigate = useNavigate();
  const activeNodeId = nodeId || "G1";
  
  const [editMode, setEditMode] = useState(false);
  const [supplementalContext, setSupplementalContext] = useState("");
  const [showConfirmModal, setShowConfirmModal] = useState(false); // 🟢 Modal State

  // Checklist state
  const [gateChecklists, setGateChecklists] = useState({
    G1: [
      { id: "g1-1", label: "User stories cover all edge cases", completed: false },
      { id: "g1-2", label: "Acceptance criteria are testable", completed: false },
      { id: "g1-3", label: "Compliance & Legal review passed", completed: false }
    ],
    G2: [
      { id: "g2-1", label: "Sprint velocity targets confirmed", completed: false },
      { id: "g2-2", label: "External dependencies mapped", completed: false },
      { id: "g2-3", label: "Resource availability verified", completed: false },
      { id: "g2-4", label: "Risk mitigation plan logged", completed: false }
    ],
    G3: [
      { id: "g3-1", label: "Tech stack rationale validated", completed: false },
      { id: "g3-2", label: "API schemas match data models", completed: false },
      { id: "g3-3", label: "Security & Auth strategy approved", completed: false }
    ],
    G4: [
      { id: "g4-1", label: "UI Mockups match brand guidelines", completed: false },
      { id: "g4-2", label: "Responsive layouts verified", completed: false }
    ],
    G6: [
        { id: "g6-1", label: "Security scan passed without criticals", completed: false },
        { id: "g6-2", label: "Logic flow matches requirements", completed: false }
    ]
  });

  const currentChecklist = gateChecklists[activeNodeId] || [
    { id: "default-1", label: "Manual artifact verification complete", completed: false }
  ];
  
  // 🟢 CALCULATE COMPLETION
  const isFullyVerified = currentChecklist.every(item => item.completed);
  const progress = (currentChecklist.filter(i => i.completed).length / currentChecklist.length) * 100 || 0;

  const toggleCheckItem = (id) => {
    setGateChecklists(prev => ({
      ...prev,
      [activeNodeId]: prev[activeNodeId].map(item => item.id === id ? { ...item, completed: !item.completed } : item)
    }));
  };

  // 🟢 INTERCEPT APPROVAL
  const handleApproveClick = () => {
    if (!isFullyVerified) {
      setShowConfirmModal(true);
    } else {
      onApprove(activeNodeId);
    }
  };

  const gateConfigs = {
    G1: { title: "Requirements Analysis", agent: "Product Architect", color: "violet", icon: Hash },
    G2: { title: "Planning", agent: "Planning", color: "violet"},
    G3: { title: "Architecture Review", agent: "Product Architect", color: "violet"},
    G4: { title: "Design Review", agent: "UI/UX Designer", color: "violet"},
    G5: { title: "Development Code Review", agent: "Development", color: "violet"},
    G6: { title: "Security Audit", agent: "Security Engine", color: "violet", icon: ShieldCheck }
  };

  const config = gateConfigs[activeNodeId] || { title: "Agent Review", agent: "Autonomous Agent", color: "zinc", icon: AlertCircle };

  return (
    <div className="absolute inset-0 bg-[#09090b] text-white z-[100] flex flex-col font-sans overflow-hidden animate-in slide-in-from-bottom duration-300">
      
      {/* --- COMMAND HEADER --- */}
      <div className="h-20 border-b border-zinc-800 flex items-center justify-between px-8 bg-[#0b0b0d] shrink-0">
        <div className="flex items-center gap-6">
          <button onClick={onClose} className="p-2 hover:bg-zinc-800 rounded-xl text-zinc-500 hover:text-white transition-all border border-zinc-800/50">
            <ArrowLeft size={20} />
          </button>
          <div className="flex items-center gap-4">
            <div className={`bg-${config.color}-500/10 text-${config.color}-400 px-3 py-1 rounded-full text-[10px] font-black border border-${config.color}-500/20 uppercase tracking-widest`}>
              {activeNodeId} CRITICAL GATE
            </div>
            <h1 className="text-lg font-bold text-white tracking-tight">{config.title}</h1>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-zinc-500 text-xs font-mono">
            <Clock size={14} />
            <span>SESSION: <span className="text-white font-bold">04:12</span></span>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-white">
            <X size={24} />
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden relative">
        {/* --- LEFT PANEL --- */}
        <div className="w-[58%] border-r border-zinc-800 flex flex-col bg-[#09090b]">
          <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/10 shrink-0">
            <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500">Output Analysis</h2>
            <button
              onClick={() => setEditMode(!editMode)}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold transition-all ${
                editMode ? "bg-violet-600 text-white" : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
              }`}
            >
              {editMode ? <Save size={14} /> : <Edit3 size={14} />}
              {editMode ? "Confirm Changes" : "Override Mode"}
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-10 no-scrollbar pb-32">
            {activeNodeId === 'G1' && (<RequirementsGate project={project} onUpdateProject={onUpdateProject} editMode={editMode} />)}
            {activeNodeId === 'G2' && (<PlanningGate project={project} onUpdateProject={onUpdateProject} editMode={editMode} />)}
            {activeNodeId === 'G3' && (<ArchitectureGate project={project} onUpdateProject={onUpdateProject} editMode={editMode} />)}
          </div>
        </div>

        {/* --- RIGHT PANEL --- */}
        <div className="w-[42%] flex flex-col bg-[#0b0b0d]">
          <div className="flex-1 overflow-y-auto p-10 space-y-12 no-scrollbar">
            <section className="space-y-6">
              <div className="flex justify-between items-end px-1">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 flex items-center gap-2">
                  <ListChecks size={12} /> Gate Verification
                </h3>
                <span className={`text-xs font-mono font-bold ${isFullyVerified ? 'text-emerald-400' : 'text-zinc-500'}`}>
                  {Math.round(progress)}%
                </span>
              </div>
              <div className="h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div className={`h-full transition-all duration-500 ${isFullyVerified ? 'bg-emerald-500 shadow-[0_0_10px_#10b981]' : 'bg-violet-500'}`} style={{ width: `${progress}%` }} />
              </div>
              <div className="space-y-3">
                {currentChecklist.map(item => (
                  <label key={item.id} className="group flex items-center gap-4 p-5 bg-zinc-900/20 border border-zinc-800/50 rounded-2xl cursor-pointer hover:bg-zinc-900/40 transition-all">
                    <div className="relative flex items-center justify-center shrink-0">
                      <input
                        type="checkbox"
                        checked={item.completed}
                        onChange={() => toggleCheckItem(item.id)}
                        className="peer w-6 h-6 appearance-none bg-zinc-900 border border-zinc-700 rounded-lg checked:bg-violet-600 checked:border-violet-500 transition-all cursor-pointer shadow-inner"
                      />
                      <CheckCircle2 size={14} className="absolute text-white opacity-0 peer-checked:opacity-100 transition-opacity" />
                    </div>
                    <span className={`text-xs font-medium transition-colors ${item.completed ? "text-zinc-200" : "text-zinc-500"}`}>
                      {item.label}
                    </span>
                  </label>
                ))}
              </div>
            </section>

            <section className="space-y-4">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-500 flex items-center gap-2">
                <Info size={12} /> Revision Memo
              </h3>
              <div className="relative">
                <textarea
                  value={supplementalContext}
                  onChange={(e) => setSupplementalContext(e.target.value)}
                  placeholder="Provide guidance for the next cycle..."
                  className="w-full bg-[#09090b] border border-zinc-800 rounded-2xl p-6 text-xs h-40 outline-none focus:border-violet-500/50 transition-all text-zinc-200 placeholder:text-zinc-700 resize-none font-mono"
                />
                <div className="absolute bottom-4 right-4"><Terminal size={14} className="text-zinc-800" /></div>
              </div>
            </section>
          </div>

          {/* ACTION BAR */}
          <div className="p-8 bg-[#09090b] border-t border-zinc-800 grid grid-cols-2 gap-4">
            <button 
              onClick={handleApproveClick} 
              /* 🟢 DYNAMIC BUTTON COLOR */
              className={`py-4 rounded-2xl font-black text-[10px] uppercase shadow-lg transition-all active:scale-95 ${
                isFullyVerified 
                ? "bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/20" 
                : "bg-zinc-800 hover:bg-zinc-700 text-zinc-400 border border-zinc-700/50"
              }`}
            >
              Approve
            </button>
            <button onClick={onClose} className="py-4 bg-zinc-800 hover:bg-zinc-700 text-white rounded-2xl font-black text-[10px] uppercase active:scale-95 transition-all">
              Re-run
            </button>
          </div>
        </div>

        {/* 🟢 CUSTOM ALERT MODAL */}
        {showConfirmModal && (
          <div className="absolute inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="bg-[#111114] border border-zinc-800 w-full max-w-sm rounded-[2rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
              <div className="w-12 h-12 bg-orange-500/10 text-orange-500 rounded-xl flex items-center justify-center mb-6">
                <AlertTriangle size={24} />
              </div>
              <h2 className="text-lg font-bold text-white mb-2">Checklist Incomplete</h2>
              <p className="text-zinc-400 text-xs leading-relaxed mb-8">
                Not all verification conditions have been met. Approving now may cause issues in the next stage.
              </p>
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => { setShowConfirmModal(false); onApprove(activeNodeId); }}
                  className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-white rounded-xl font-bold text-[10px] uppercase tracking-widest transition-all"
                >
                  Continue Anyway
                </button>
                <button 
                  onClick={() => setShowConfirmModal(false)}
                  className="w-full py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl font-bold text-[10px] uppercase tracking-widest transition-all"
                >
                  Recheck Conditions
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}