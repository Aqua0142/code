import { Pause, RotateCcw, StopCircle } from "lucide-react";

export default function PipelineControlBar({ project }) {
  return (
    <div className="flex items-center gap-4 bg-[#111114]/90 backdrop-blur-xl border border-zinc-700 py-2 px-6 rounded-full max-w-4xl mx-auto mt-12 shadow-2xl relative z-20 shrink-0 mb-6">
      <div className="pr-2 border-r border-zinc-800 flex items-center gap-3">
        <div className="relative flex items-center justify-center shrink-0">
          <div className="w-2 h-2 rounded-full bg-violet-400 animate-ping absolute" />
          <div className="w-2 h-2 rounded-full bg-violet-400 relative z-10" />
        </div>
        <div className="flex flex-col min-w-[120px]">
          <span className="text-[7px] font-black uppercase text-zinc-400 tracking-[0.2em] leading-none mb-1">
            Engine State
          </span>
          <span className="text-[10px] font-bold text-zinc-100 uppercase tracking-tight leading-none">
            Sprint 1: Dev
          </span>
        </div>
      </div>

      <div className="flex-1 flex justify-center gap-1">
        <ControlButton icon={Pause} label="Pause" />
        <ControlButton icon={RotateCcw} label="Re-run" />
        <ControlButton icon={StopCircle} label="End" variant="danger" />
      </div>

      <div className="pl-6 border-l border-zinc-800 flex items-center gap-6">
        <ToggleControl label="Auto" active={true} />
      </div>
    </div>
  );
}

function ControlButton({ icon: Icon, label, variant }) {
  const isDanger = variant === "danger";
  return (
    <button className="group flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all hover:bg-zinc-800 active:scale-95">
      <div
        className={`p-1.5 rounded-lg transition-colors ${
          isDanger
            ? "text-red-500"
            : "text-zinc-400 group-hover:text-violet-400"
        }`}
      >
        <Icon size={18} />
      </div>
      <span className="text-[8px] font-black uppercase tracking-widest text-zinc-500 group-hover:text-zinc-300">
        {label}
      </span>
    </button>
  );
}

function ToggleControl({ label, active }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex flex-col items-end">
        <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest leading-none">
          {label}
        </span>
        <span className="text-[7px] font-bold text-violet-500/60 mt-0.5">
          {active ? "ON" : "OFF"}
        </span>
      </div>
      <div
        className={`w-8 h-4 rounded-full relative cursor-pointer transition-all duration-300 p-0.5 ${
          active ? "bg-violet-600" : "bg-zinc-800"
        }`}
      >
        <div
          className={`w-3 h-3 bg-white rounded-full shadow-lg transition-all transform ${
            active ? "translate-x-4" : "translate-x-0"
          }`}
        />
      </div>
    </div>
  );
}
