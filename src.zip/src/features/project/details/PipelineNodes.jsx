import { CheckCircle2, Lock, Play } from "lucide-react";

export function GateNode({ stage, status, onClick, data }) {
  const isApproved = status === "approved";
  const isGate = status === "gate_pending";
  const theme = isApproved
    ? "bg-emerald-500/10 border-emerald-500 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
    : isGate
      ? "bg-violet-500/10 border-violet-500 text-violet-400 animate-pulse"
      : "bg-white/5 border-white text-white shadow-[0_0_15px_rgba(255,255,255,0.2)]";

  return (
    <div
      onClick={onClick}
      className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center transition-all cursor-pointer group relative hover:scale-110 active:scale-95 bg-black z-20 ${theme}`}
    >
      {isApproved ? (
        <CheckCircle2 size={24} />
      ) : isGate ? (
        <Lock size={20} />
      ) : (
        <Play size={20} />
      )}

      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-y-2 group-hover:translate-y-0 z-50">
        <div className="bg-zinc-900/90 border border-white/20 rounded-xl p-3 shadow-2xl min-w-[180px] backdrop-blur-xl">
          <div className="flex flex-col gap-2">
            <div className="flex flex-col">
              <span className="text-[7px] font-black text-white/40 uppercase">
                Input
              </span>
              <span className="text-[10px] text-white font-bold">
                {data?.input}
              </span>
            </div>
            <div className="h-px bg-white/10" />
            <div className="flex flex-col">
              <span className="text-[7px] font-black text-white/40 uppercase">
                Output
              </span>
              <span className="text-[10px] text-blue-400 font-bold">
                {data?.output}
              </span>
            </div>
          </div>
          <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-zinc-900 border-r border-b border-white/20 rotate-45 -translate-y-1" />
        </div>
      </div>

      <div className="absolute -bottom-10 flex flex-col items-center">
        <span
          className={`text-[9px] font-black uppercase tracking-[0.2em] whitespace-nowrap ${
            isApproved
              ? "text-emerald-400"
              : isGate
                ? "text-violet-400"
                : "text-white"
          }`}
        >
          {stage.label}
        </span>
      </div>
    </div>
  );
}

export function AgentNode({ icon, label, status, color }) {
  const getTheme = () => {
    switch (color) {
      case "amber":
        return "text-amber-400 border-amber-500/40 bg-amber-500/10 shadow-[0_0_20px_rgba(245,158,11,0.15)]";
      case "emerald":
        return "text-emerald-400 border-emerald-500/30 bg-emerald-500/10 shadow-[0_0_20px_rgba(16,185,129,0.15)]";
      case "white":
      default:
        return "text-white border-white bg-zinc-900/50 shadow-none opacity-80";
    }
  };

  return (
    <div
      className={`flex items-center gap-2 px-3 py-1.5 border-2 rounded-xl backdrop-blur-xl min-w-[130px] group relative transition-all duration-500 ${getTheme()}`}
    >
      {icon}
      <div className="flex flex-col">
        <span
          className={`text-[9px] font-bold ${
            color === "white" ? "text-zinc-400" : "text-white"
          }`}
        >
          {label}
        </span>
        <span className="text-[7px] font-black uppercase tracking-widest opacity-80">
          {status}
        </span>
      </div>

      {color !== "white" && (
        <div
          className={`ml-auto w-1 h-1 rounded-full animate-pulse ${
            color === "amber"
              ? "bg-amber-400 shadow-[0_0_10px_#f59e0b]"
              : "bg-emerald-400"
          }`}
        />
      )}

      <div className="absolute left-full ml-4 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 -translate-x-2 group-hover:translate-x-0 z-50">
        <div className="bg-zinc-900 border border-white/10 rounded-lg p-2 shadow-2xl min-w-[140px] backdrop-blur-md">
          <span className="text-[8px] text-white font-bold whitespace-nowrap">
            Agent status: {status}
          </span>
        </div>
      </div>
    </div>
  );
}
