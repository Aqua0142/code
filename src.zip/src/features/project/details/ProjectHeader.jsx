import { ArrowLeft } from "lucide-react";

export default function ProjectHeader({ project, onBack, activeTab, onTabChange, tabs }) {
  return (
    <div className="px-8 mt-4 shrink-0 relative z-30 bg-[#09090b]">
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={onBack}
          className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-500 hover:text-white transition-all"
        >
          <ArrowLeft size={18} />
        </button>
        <h1 className="text-lg font-bold tracking-tight text-white">
          {project?.name || "Project Details"}
        </h1>
      </div>

      <div className="flex gap-8 border-b border-zinc-800">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => onTabChange(tab)}
            className={`pb-2 text-[11px] font-black uppercase tracking-widest transition-all relative ${
              activeTab === tab
                ? "text-violet-400"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            {tab}
            {activeTab === tab && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-violet-500 shadow-[0_0_10px_rgba(139,92,246,0.5)]" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
