import React, { useState, useMemo, useEffect } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";

import NodeGates from "../gates/NodeGates";
import PipelineCanvas from "./tabs/PipelineTab";
import ArtifactsTab from "./tabs/ArtifactsTab";
import EventsTab from "./tabs/EventsTab";
import GatesTab from "./tabs/GatesTab";
import MetricsTab from "./tabs/MetricsTab";
import ProjectHeader from "./ProjectHeader";
import PipelineControlBar from "./PipelineControlBar";

const TABS = ["Pipeline", "Artifacts", "Events", "Gates", "Metrics"];

export default function ProjectDetails({ project: propProject, onBack, onUpdateProject }) {
  const [activeTab, setActiveTab] = useState('Pipeline');
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const { projectId, gateId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (gateId) {
      setSelectedNodeId(gateId);
    } else {
      setSelectedNodeId(null);
    }
  }, [gateId]);

  const handleCloseGate = () => {
    setSelectedNodeId(null);
    navigate(`/project/${projectId}`); // 🟢 Clear the review path from URL
  };

  const project = useMemo(() => {
    if (propProject) return propProject;
    if (location.state?.project) return location.state.project;
    
    const saved = JSON.parse(localStorage.getItem("projects") || "[]");
    return saved.find(p => p.id.toString() === projectId);
  }, [propProject, projectId, location.state]);

  // Handlers

  const handleApprove = (nodeId) => {
    const currentIndex = project.stages.findIndex(s => s.id === nodeId);
    if (currentIndex === -1) return;
    const updatedStages = [...project.stages];
    updatedStages[currentIndex].state = 'approved';
    if (currentIndex + 1 < updatedStages.length) updatedStages[currentIndex + 1].state = 'executing';
    onUpdateProject({ ...project, stages: updatedStages });
    setSelectedNodeId(null);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case "Pipeline":
        return (
          <div className="flex flex-col items-center justify-between h-full animate-in fade-in duration-700 overflow-visible">
            <PipelineCanvas onNodeClick={(id) => setSelectedNodeId(id)} />
            <PipelineControlBar project={project} />
          </div>
        );
      case "Artifacts":
        return <ArtifactsTab project={project} />;
      case "Events":
        return <EventsTab project={project} />;
      case "Gates":
        return <GatesTab project={project} />;
      case "Metrics":
        return <MetricsTab project={project} />;
      default:
        return null;
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#09090b] overflow-hidden relative animate-in fade-in duration-500">
      <ProjectHeader
        project={project}
        onBack={onBack}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        tabs={TABS}
      />

      <div className="flex flex-col overflow-y-auto custom-scrollbar relative mt-1 px-4 pb-2 z-10">
        {renderTabContent()}
      </div>

      {selectedNodeId && (
        <NodeGates
          nodeId={selectedNodeId}
          project={project}
          onUpdateProject={onUpdateProject}
          onApprove={handleApprove}
          onClose={handleCloseGate}
        />
      )}
    </div>
  );
}