import React, { useState, useMemo } from "react";
import { useNavigate, useLocation, useParams } from "react-router-dom";
import { Lock, Play, Layout, Cpu, Users, CheckCircle2, Layers, RefreshCcw, ChevronLeft, XCircle } from "lucide-react";
 
const STAGE_DATA = {
  G1: { input: "Product Vision", output: "User Stories / Backlog" },
  G2: { input: "Backlog", output: "Sprint Schedule / Tasks" },
  G3: { input: "Requirements", output: "System Design / Schema" },
  G4: { input: "Architecture", output: "UI Mockups / Prototypes" },
  G5_DE: { input: "UI Design", output: "Logic / Features" },
  G5_UT: { input: "Source Code", output: "Test Coverage" },
  G6: { input: "Build", output: "System Reports" },
  G7: { input: "Verified Code", output: "Integrated Build" },
  G8: { input: "Codebase", output: "Vulnerability Scan" },
  G9: { input: "Staging App", output: "User Sign-off" },
  G10: { input: "Production Artifacts", output: "Live URL" },
};
 
const ID_MAP = {
    G1: "p1", G2: "p2", G3: "p3", G4: "p4", G5_DE: "p4", G5_UT: "p4", G6: "p5", G7: "p5", G8: "p6", G9: "p7", G10: "p8"
};
 
const SETUP_STAGES = [
  { id: "G1", label: "Requirements", x: 160, y: 150 },
  { id: "G2", label: "Planning", x: 280, y: 250 },
  { id: "G3", label: "Architecture", x: 400, y: 150 },
];
 
const SPRINT_STAGES = [
  
  { id: "G5_DE", label: "Development", x: 800, y: 180, variant: "elongated", icon: <Layout size={14}/> },
  { id: "G5_UT", label: "Unit Testing", x: 800, y: 310, variant: "elongated", icon: <Cpu size={14}/> },
];
 
const FINAL_STAGES = [
  { id: "G7", label: "Functional Testing", x: 1180, y: 150 },
  { id: "G8", label: "NFR Testing", x: 1320, y: 280 },
  { id: "G9", label: "UAT", x: 1460, y: 180 },
  { id: "G10", label: "Deployment", x: 1600, y: 280 },
];
 
const STORY_CARDS = [
  { id: 's1', title: "Auth Module Setup" },
  { id: 's2', title: "Payment API Integ" },
  { id: 's3', title: "User Profile CRUD" },
];
 
const SPRINT_LIST = Array.from({ length: 20 }, (_, i) => i + 1);
 
export default function PipelineCanvas() {
  const navigate = useNavigate();
  const location = useLocation();
  const { projectId } = useParams();

  const project = useMemo(() => {
    if (location.state?.project) return location.state.project;
    const saved = JSON.parse(localStorage.getItem("projects") || "[]");
    return saved.find(p => p.id.toString() === projectId);
  }, [projectId, location.state]);

   const phaseConfigs =
      location.state?.phaseConfigs ||
      JSON.parse(localStorage.getItem("projects") || "[]")[0]?.phaseConfigs;
    const dynamicSprintCount = phaseConfigs?.p2?.planning?.sprints || 5;
    const SPRINT_LIST = Array.from(
      { length: dynamicSprintCount },
      (_, i) => i + 1,
    );
 
  const approvedPhaseIds = project?.selectedPhaseIds || ["p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8"];

  const [viewingSprint, setViewingSprint] = useState(1);
  const [selectedStory, setSelectedStory] = useState(null);
  const [forceExpandStructure, setForceExpandStructure] = useState(false);
  const isSprintActive = viewingSprint === 1;
 
  const getStatus = (stageId) => {
      const selectionId = ID_MAP[stageId];
      
      // 🟢 Logic: If the mapped phase ID is not in our approved list, it is skipped
      if (selectionId && !approvedPhaseIds.includes(selectionId)) return "skipped";
      
      // Handle active state for the Sprint box
      if (stageId.startsWith("G5") || stageId === "G4" || stageId === "G6") {
          return (selectedStory || forceExpandStructure) ? "gate_pending" : "pending";
      }

      // Default logic for requirements/planning/architecture
      if (SETUP_STAGES.some(s => s.id === stageId)) return "approved";
      return "pending";
  };
 
  const getLineColor = (targetStageId, activeColor = "#10b981") => {
    const status = getStatus(targetStageId);
    if (status === "skipped") return "#3f3f46";
    if (status === "pending") return "#f59e0b";
    return activeColor;
  };
 
  const isDevSelected = approvedPhaseIds.includes("p4");
  const isShrunkNode = !isDevSelected && !selectedStory && !forceExpandStructure;
  const showInternalStructure = selectedStory || (forceExpandStructure && !isDevSelected);
 
  const currentBoxWidth = isShrunkNode ? 44 : (showInternalStructure ? 580 : 380);
  const currentBoxHeight = isShrunkNode ? 44 : 380;
  const currentBoxTop = isShrunkNode ? 300 : 40;
  const offset = 580 - currentBoxWidth;
 
  return (
    
    <div className="w-[1600px] h-[550px] top-5 bg-[#020203] relative overflow-hidden rounded-[40px] border border-white/10 font-sans text-white">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:40px_40px]" />
     
        <div className="absolute left-3/4 -translate-x-1/4 flex items-center gap-6 bg-[#0a0a0c]/80 backdrop-blur-md border border-white/5 p-3 px-5 rounded-2xl z-50 shadow-2xl">
          <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
              <span className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Completed</span>
          </div>
          <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-violet-500 shadow-[0_0_8px_#8b5cf6]" />
               <span className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Active</span>
          </div>
          <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-[0_0_8px_#f59e0b]" />
              <span className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Waiting</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full border border-zinc-600 border-dashed" />
              <span className="text-[9px] font-black uppercase tracking-widest text-zinc-400">Skipped</span>
        </div>
      </div>

      <div className="relative w-full h-full overflow-x-auto no-scrollbar">
       
        <div
            onClick={() => isShrunkNode && setForceExpandStructure(true)}
            className={`absolute border-2 border-dashed transition-all duration-700 ease-in-out flex items-center justify-center
                ${isShrunkNode
                    ? "rounded-2xl border-zinc-700 bg-transparent z-30 cursor-pointer"
                    : "rounded-[40px] z-10 " + ((selectedStory || forceExpandStructure) ? "border-violet-500/40 bg-[#08080a]" : "border-white/10 bg-transparent")
                }`}
            style={{
                left: 540,
                top: currentBoxTop,
                width: currentBoxWidth,
                height: currentBoxHeight
            }}
        >
            {isShrunkNode ? (
                <div className="flex flex-col items-center justify-center text-zinc-600">
                    <XCircle size={20} />
                    <span className="absolute -bottom-8 text-[8px] font-black uppercase tracking-widest">Sprint</span>
                </div>
            ) : (
                <>
                <div className="absolute -left-5 top-12 flex flex-col gap-2 p-1 bg-[#0a0a0c] rounded-full border border-white/10 shadow-2xl z-40 max-h-[260px] overflow-y-auto no-scrollbar">
                    {SPRINT_LIST.map(num => (
                        <button key={num} onClick={(e) => { e.stopPropagation(); setViewingSprint(num); setSelectedStory(null); setForceExpandStructure(false); }} className={`relative w-8 h-8 flex items-center justify-center flex-shrink-0 rounded-full transition-all ${viewingSprint === num ? "text-white" : "text-zinc-600 hover:text-white"}`}>
                            {viewingSprint === num && <div className={`absolute inset-0 rounded-full ${num === 1 ? "bg-violet-600 shadow-[0_0_15px_#8b5cf6]" : "bg-white/20"}`} />}
                            <div className="relative z-10 flex flex-col items-center">
                              <RefreshCcw size={10} className={viewingSprint === num && num === 1 ? "animate-spin-slow" : ""} />
                              <span className="text-[6px] font-black">{num}</span>
                            </div>
                        </button>
                    ))}
                </div>
 
                {!showInternalStructure ? (
                  <div className="p-8 h-full flex flex-col pl-10 w-full">
                    <h3 className={`text-[10px] font-black tracking-[0.4em] uppercase mb-6 ${isSprintActive ? "text-violet-400" : "text-white opacity-40"}`}>
                      Sprint {viewingSprint} {isSprintActive ? "Backlog" : "(Upcoming)"}
                    </h3>
                    <div className="space-y-3 overflow-y-auto no-scrollbar pr-1">
                      {STORY_CARDS.map(story => (
                        <div
                            key={story.id}
                            onClick={(e) => { e.stopPropagation(); isSprintActive && setSelectedStory(story.id); }}
                            className={`p-5 rounded-2xl border transition-all group ${
                                isSprintActive
                                ? "bg-[#0d0d0f] border-white/5 hover:border-violet-500/50 cursor-pointer"
                                : "bg-white/5 border-white/10 opacity-50 cursor-not-allowed"
                            }`}
                        >
                          <div className="flex items-center justify-between">
                            <p className={`text-[11px] font-black uppercase ${isSprintActive ? "text-zinc-300 group-hover:text-white" : "text-white"}`}>{story.title}</p>
                            {isSprintActive ? <Play size={10} className="text-zinc-700 group-hover:text-violet-400" /> : <Lock size={10} className="text-white/20"/>}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="absolute top-5 left-10 z-50">
                    <button onClick={(e) => { e.stopPropagation(); setSelectedStory(null); setForceExpandStructure(false); }} className="flex items-center gap-2 text-[8px] font-black text-violet-400 hover:text-white uppercase mb-1 bg-transparent border-none cursor-pointer">
                       <ChevronLeft size={14} /> Back to Backlog
                    </button>
                    <h2 className="text-[12px] font-black uppercase tracking-tight text-white border-b border-violet-500/30 pb-1">
                        {selectedStory ? STORY_CARDS.find(s=>s.id===selectedStory)?.title : "Sprint Structure (Bypassed)"}
                    </h2>
                  </div>
                )}
 
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 opacity-20 text-white pointer-events-none">
                     <Layers size={10} />
                     <span className="text-[8px] font-black tracking-widest uppercase italic">Execution Engine</span>
                </div>
                </>
            )}
        </div>
 
      <svg className="absolute inset-0 w-[2000px] h-full pointer-events-none z-20 transition-all duration-700">
          {/* Requirements to Planning */}
        <path
            d="M 204 150 C 240 150, 240 250, 280 250"
            stroke={getLineColor("G2")}
            strokeWidth="2"
            fill="none"
            opacity="0.6"
          />

          {/* Planning to Architecture */}
        <path
            d="M 324 250 C 360 250, 360 150, 400 150"
            stroke={getLineColor("G3")}
            strokeWidth="2"
            fill="none"
            opacity="0.6"
          />
        
          {/* 🟢 CONNECTING: Architecture (G3) to Fan-out point inside Sprint Box */}
        <path
            d={`M 444 150 C 480 150, 500 250, ${showInternalStructure ? 674 : 540} 250`}
            stroke={getLineColor("G5_DE")}
            strokeWidth="2"
            strokeDasharray={isShrunkNode ? "4 4" : "0"}
            fill="none"
            opacity="0.6"
          />
        
      {showInternalStructure && (
        <g>

              {/* Fan-out to Development */}
          <path
              d="M 674 250 C 730 250, 740 180, 800 180"
              stroke={getLineColor("G5_DE", "#8b5cf6")}
              strokeWidth="2"
              fill="none"
              opacity="0.5"
            />

              {/* Fan-out to Unit Testing */}
          <path
              d="M 674 250 C 730 250, 740 310, 800 310"
              stroke={getLineColor("G5_UT", "#8b5cf6")}
              strokeWidth="2"
              fill="none"
              opacity="0.5"
            />
        
              {/* Development to Fan-in */}
          <path
              d="M 940 180 C 1010 180, 1030 250, 1070 250"
              stroke={getLineColor("G7", "#8b5cf6")}
              strokeWidth="2"
              fill="none"
              opacity="0.5"
            />

              {/* Unit Testing to Fan-in */}
          <path
              d="M 940 310 C 1010 310, 1030 250, 1070 250"
              stroke={getLineColor("G7", "#8b5cf6")}
              strokeWidth="2"
              fill="none"
              opacity="0.5"
            />
        
              {/* 🟢 CONNECTING: Fan-in point directly to SIT (G7) */}
          <path
                d={`M 1070 250 C 1120 250, 1140 150, ${1180 - offset} 150`}
                stroke={getLineColor("G7", "#8b5cf6")}
                strokeWidth="2"
                fill="none"
                opacity="0.6"
              />
        </g>
      )}
        
          {/* Bypassed dashed line when box is closed */}

          {!showInternalStructure && (
            <path
                d={`M ${540 + currentBoxWidth} 250 C ${1100 - offset} 250, ${1140 - offset} 150, ${1180 - offset} 150`}
                stroke="#3f3f46"
                strokeWidth="2"
                strokeDasharray="4 4"
                fill="none"
              />
          )}
        
          {/* SIT to NFR Testing */}
          <path
            d={`M ${1224 - offset} 150 C ${1280 - offset} 150, ${1280 - offset} 280, ${1320 - offset} 280`}
            stroke={getLineColor("G8", "#8b5cf6")}
            strokeWidth="2"
            fill="none"
            opacity="0.6"
          />

          {/* NFR Testing to UAT */}
          <path
            d={`M ${1364 - offset} 280 C ${1420 - offset} 280, ${1420 - offset} 180, ${1460 - offset} 180`}
            stroke={getLineColor("G9", "#3b82f6")}
            strokeWidth="2"
            fill="none"
            opacity="0.4"
          />

          {/* UAT to Deployment */}
          <path
            d={`M ${1504 - offset} 180 C ${1560 - offset} 180, ${1560 - offset} 280, ${1600 - offset} 280`}
            stroke={getLineColor("G10", "#3b82f6")}
            strokeWidth="2"
            fill="none"
            opacity="0.4"
          />
      </svg>
 
 
        {[...SETUP_STAGES, ...SPRINT_STAGES, ...FINAL_STAGES].map(stage => {
          const isSprintNode = SPRINT_STAGES.some(s => s.id === stage.id);
          if (isSprintNode && !showInternalStructure) return null;
         
          const isPostSprint = FINAL_STAGES.some(f => f.id === stage.id);
          const currentX = isPostSprint ? stage.x - offset : stage.x;
 
          return (
            <div key={stage.id} style={{ left: currentX, top: stage.y }} className="absolute -translate-y-1/2 z-30 transition-all duration-700 ease-in-out" >
              <GateNode
                stage={stage}
                status={getStatus(stage.id)}
                // 🟢 Update click logic to use the specific review endpoint
                onClick={() => {
                  if (getStatus(stage.id) === "approved") {
                    navigate(`/project/${projectId}/review/${stage.id}`);
                  }
                }}
                variant={stage.variant}
              />
            </div>
          );
        })}
 
        
      </div>
    </div>
  );
}
 
function GateNode({ stage, status, onClick, variant }) {
    const isApproved = status === "approved";
    const isGate = status === "gate_pending";
    const isSkipped = status === "skipped";
    const isElongated = variant === "elongated";
   
    let theme = "";
    if (isApproved) {
        theme = "border-emerald-500 text-emerald-400 bg-emerald-500/10 shadow-[0_0_20px_#10b981]";
    } else if (isSkipped) {
        theme = "border-zinc-700 border-dashed text-zinc-500 bg-transparent shadow-none";
    } else if (isGate) {
        theme = "border-violet-500 text-violet-400 bg-violet-500/10 shadow-[0_0_20px_#8b5cf6]";
    } else {
        theme = "border-amber-500 text-amber-400 bg-amber-500/5 shadow-[0_0_15px_rgba(245,158,11,0.2)]";
    }
 
    return (
      <div
        onClick={isSkipped ? null : onClick}
        className={`relative flex items-center justify-center cursor-pointer bg-black group transition-all border-2
          ${isElongated ? "w-[140px] h-[54px] rounded-xl px-4" : "w-11 h-11 rounded-2xl"}
          ${theme} ${!isSkipped && "hover:scale-105"}`}
      >
          <div className={isElongated ? "absolute left-4 opacity-80" : ""}>
             {isApproved ? <CheckCircle2 size={isElongated ? 16 : 20} />
              : isSkipped ? <XCircle size={isElongated ? 16 : 18} />
              : <Lock size={isElongated ? 16 : 18} />}
          </div>
 
          {isElongated ? (
              <div className="flex flex-col items-center text-center">
                <span className={`text-[10px] font-black uppercase tracking-tight ${isSkipped ? "text-zinc-600" : "text-white"}`}>{stage.label}</span>
                <span className="text-[7px] font-bold uppercase opacity-60">
                    {isSkipped ? "Bypassed" : (isApproved ? "Completed" : "Awaiting")}
                </span>
              </div>
          ) : (
            <span className={`absolute -bottom-8 text-[8px] font-black uppercase tracking-[0.2em] whitespace-nowrap ${isSkipped ? "text-zinc-600" : "text-white"}`}>
                {stage.label}
            </span>
          )}
      </div>
    );
}
 