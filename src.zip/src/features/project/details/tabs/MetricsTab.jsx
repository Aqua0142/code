import React from "react";
import { 
  BarChart3, PiggyBank, Timer, Cpu, 
  ArrowUpRight, Zap, Globe, HardDrive 
} from "lucide-react";

export default function MetricsTab({ project }) {
  // Mock Metric Data
  const stats = [
    { label: "Total Tokens", value: "1.4M", change: "+12%", icon: Zap, color: "text-amber-400" },
    { label: "Total Cost", value: "$42.50", change: "+5%", icon: PiggyBank, color: "text-emerald-400" },
    { label: "Avg. Duration", value: "4m 12s", change: "-8%", icon: Timer, color: "text-sky-400" },
    { label: "Agent Success", value: "98.2%", change: "+2%", icon: Cpu, color: "text-violet-400" },
  ];

  const stageMetrics = [
    { stage: "Requirements (G1)", tokens: 450000, cost: 12.40, duration: 180, success: 100 },
    { stage: "Planning (G2)", tokens: 120000, cost: 4.20, duration: 45, success: 95 },
    { stage: "Architecture (G3)", tokens: 680000, cost: 22.80, duration: 320, success: 92 },
    { stage: "Design (G4)", tokens: 150000, cost: 3.10, duration: 90, success: 100 },
  ];

  const maxTokens = Math.max(...stageMetrics.map(s => s.tokens));
  const maxCost = Math.max(...stageMetrics.map(s => s.cost));

  return (
    <div className="flex flex-col gap-8 p-8 max-w-[1500px] mx-auto w-full animate-in fade-in duration-500 pb-20">
      
      {/* --- TOP KPl CARDS --- */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-[#0b0b0d] border border-zinc-800 p-6 rounded-[2rem] shadow-xl relative overflow-hidden group">
            <div className="flex justify-between items-start mb-4">
              <div className={`p-3 rounded-2xl bg-zinc-900 border border-zinc-800 ${stat.color}`}>
                <stat.icon size={20} />
              </div>
              <div className="flex items-center gap-1 text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-lg">
                <ArrowUpRight size={10} /> {stat.change}
              </div>
            </div>
            <div className="text-[11px] font-black text-zinc-500 uppercase tracking-widest mb-1">{stat.label}</div>
            <div className="text-2xl font-mono font-bold text-white">{stat.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* --- TOKEN USAGE (Input vs Output) --- */}
        <section className="bg-[#0b0b0d] border border-zinc-800 rounded-[2.5rem] p-8 shadow-2xl">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <BarChart3 size={20} className="text-violet-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-widest">Token Distribution</h3>
            </div>
            <div className="flex gap-4 text-[10px] font-black uppercase text-zinc-500">
               <span className="flex items-center gap-1.5"><div className="w-2 h-2 bg-violet-500 rounded-full" /> Input</span>
               <span className="flex items-center gap-1.5"><div className="w-2 h-2 bg-sky-500 rounded-full" /> Output</span>
            </div>
          </div>

          <div className="space-y-6">
            {stageMetrics.map((m, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex justify-between text-[11px] font-bold text-zinc-400 uppercase tracking-tighter">
                  <span>{m.stage}</span>
                  <span className="font-mono text-zinc-200">{m.tokens.toLocaleString()} tokens</span>
                </div>
                <div className="h-3 w-full bg-zinc-900/50 rounded-full overflow-hidden flex border border-zinc-800/50">
                  <div className="h-full bg-violet-500 shadow-[0_0_10px_#8b5cf6]" style={{ width: `${(m.tokens / maxTokens) * 60}%` }} />
                  <div className="h-full bg-sky-500 shadow-[0_0_10px_#0ea5e9]" style={{ width: `${(m.tokens / maxTokens) * 30}%` }} />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* --- COST BY STAGE --- */}
        <section className="bg-[#0b0b0d] border border-zinc-800 rounded-[2.5rem] p-8 shadow-2xl">
          <div className="flex items-center gap-3 mb-8">
            <PiggyBank size={20} className="text-emerald-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-widest">Burn Rate per Stage</h3>
          </div>

          <div className="space-y-6">
            {stageMetrics.map((m, idx) => (
              <div key={idx} className="space-y-2">
                <div className="flex justify-between text-[11px] font-bold text-zinc-400 uppercase tracking-tighter">
                  <span>{m.stage}</span>
                  <span className="font-mono text-emerald-400">${m.cost.toFixed(2)}</span>
                </div>
                <div className="relative h-6 w-full bg-zinc-900/50 rounded-lg border border-zinc-800/50 overflow-hidden">
                   <div 
                    className="absolute inset-y-0 left-0 bg-emerald-500/20 border-r border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)] transition-all duration-1000"
                    style={{ width: `${(m.cost / maxCost) * 100}%` }}
                   />
                   <span className="absolute inset-0 flex items-center px-3 text-[10px] font-mono text-zinc-500 italic">
                      {((m.cost / 42.5) * 100).toFixed(1)}% of total burn
                   </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* --- DURATION BREAKDOWN --- */}
        <section className="bg-[#0b0b0d] border border-zinc-800 rounded-[2.5rem] p-8 shadow-2xl lg:col-span-2">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Timer size={20} className="text-sky-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-widest">Velocity & Latency Audit</h3>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stageMetrics.map((m, idx) => (
              <div key={idx} className="flex flex-col items-center p-6 bg-zinc-900/30 rounded-[2rem] border border-zinc-800/50 relative overflow-hidden group hover:border-sky-500/30 transition-all">
                <div className="text-[10px] font-black text-zinc-500 uppercase mb-4 tracking-widest text-center">{m.stage}</div>
                
                {/* Circular Progress (Simplified) */}
                <div className="relative w-24 h-24 flex items-center justify-center mb-4">
                   <svg className="w-full h-full -rotate-90">
                      <circle cx="48" cy="48" r="40" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-zinc-800" />
                      <circle cx="48" cy="48" r="40" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray="251.2" strokeDashoffset={251.2 - (251.2 * (m.success / 100))} className="text-sky-500 transition-all duration-1000" />
                   </svg>
                   <div className="absolute flex flex-col items-center">
                      <span className="text-lg font-mono font-bold text-white">{m.duration}s</span>
                   </div>
                </div>

                <div className="flex items-center gap-2">
                   <div className={`w-1.5 h-1.5 rounded-full ${m.success > 95 ? 'bg-emerald-500' : 'bg-orange-500'}`} />
                   <span className="text-[10px] font-black text-zinc-400 uppercase tracking-tighter">Success: {m.success}%</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}