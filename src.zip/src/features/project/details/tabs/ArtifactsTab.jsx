import React, { useState } from "react";
import { 
  FileCode, Box, Download, ChevronRight, ChevronDown, 
  Terminal, Database, Layout, ShieldCheck, Cpu 
} from "lucide-react";

export default function ArtifactsTab({ project }) {
  const [expandedId, setExpandedId] = useState(null);

  // Grouped Artifacts Data (Mocking project outputs)
  const artifactGroups = [
    {
      stage: "Requirements (G1)",
      icon: Database,
      color: "text-violet-400",
      items: [
        { id: "art-1", name: "user_stories_final.json", type: "JSON", agent: "Product Architect", version: "v1.4", size: "24 KB", time: "14:20:05", content: JSON.stringify(project?.requirements || {}, null, 2) },
        { id: "art-2", name: "market_analysis.md", type: "Markdown", agent: "Research Bot", version: "v1.0", size: "12 KB", time: "14:18:22", content: "# Market Analysis\nTargeting high-concurrency users..." }
      ]
    },
    {
      stage: "Architecture (G3)",
      icon: Cpu,
      color: "text-emerald-400",
      items: [
        { id: "art-3", name: "system_schema.sql", type: "SQL", agent: "Systems Engineer", version: "v2.1", size: "8 KB", time: "16:45:10", content: "CREATE TABLE users (\n  id UUID PRIMARY KEY,\n  email TEXT UNIQUE\n);" },
        { id: "art-4", name: "api_contracts.json", type: "JSON", agent: "Integration Specialist", version: "v1.2", size: "15 KB", time: "16:50:00", content: JSON.stringify(project?.architecture?.apiContracts || {}, null, 2) }
      ]
    }
  ];

  const toggleExpand = (id) => setExpandedId(expandedId === id ? null : id);

  return (
    <div className="flex flex-col gap-8 p-8 max-w-[1500px] mx-auto w-full animate-in fade-in duration-500 pb-20">
      
      {/* HEADER */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-6">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Project Artifacts</h2>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono text-zinc-500">
           <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500" /> System Live</span>
           <span className="text-zinc-700">|</span>
           <span>Storage: 142 MB / 1 GB</span>
        </div>
      </div>

      {/* ARTIFACT LIST */}
      <div className="space-y-10">
        {artifactGroups.map((group) => (
          <div key={group.stage} className="space-y-4">
            {/* STAGE GROUP HEADER */}
            <div className="flex items-center gap-3 px-2">
              <group.icon size={18} className={group.color} />
              <h3 className="text-sm font-black text-zinc-300 uppercase tracking-[0.2em]">{group.stage}</h3>
              <div className="h-px flex-1 bg-zinc-800/50" />
            </div>

            <div className="space-y-2">
              {group.items.map((item) => (
                <div key={item.id} className="bg-[#0b0b0d] border border-zinc-800/80 rounded-2xl overflow-hidden shadow-lg transition-all hover:border-zinc-700">
                  
                  {/* ARTIFACT ROW */}
                  <div 
                    onClick={() => toggleExpand(item.id)}
                    className="flex items-center justify-between p-5 cursor-pointer group active:bg-zinc-900/50"
                  >
                    <div className="flex items-center gap-5 flex-1">
                      {expandedId === item.id ? <ChevronDown size={18} className="text-violet-500" /> : <ChevronRight size={18} className="text-zinc-600" />}
                      <div className="p-2.5 bg-zinc-900 rounded-xl border border-zinc-800">
                        <FileCode size={20} className="text-zinc-400 group-hover:text-violet-400 transition-colors" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-sm font-bold text-zinc-100 group-hover:text-white transition-colors truncate">{item.name}</h4>
                        <div className="flex items-center gap-4 mt-1 text-[11px] text-zinc-500 font-medium">
                          <span className="flex items-center gap-1.5"><Box size={12} /> {item.agent}</span>
                          <span className="text-zinc-800">•</span>
                          <span>{item.time}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-8 shrink-0">
                      <div className="hidden md:flex items-center gap-6 text-[11px] font-mono font-bold text-zinc-500">
                        <span className="bg-zinc-900 px-2 py-1 rounded border border-zinc-800 uppercase text-zinc-400">{item.type}</span>
                        <span>{item.version}</span>
                        <span>{item.size}</span>
                      </div>
                      <button className="p-2.5 hover:bg-violet-600/20 text-zinc-500 hover:text-violet-400 rounded-xl border border-transparent hover:border-violet-500/30 transition-all">
                        <Download size={18} />
                      </button>
                    </div>
                  </div>

                  {/* EXPANDED CONTENT VIEW */}
                  {expandedId === item.id && (
                    <div className="border-t border-zinc-800 bg-black/40 p-6 animate-in slide-in-from-top-2 duration-300">
                      <div className="flex items-center justify-between mb-4 px-2">
                        <div className="flex items-center gap-2">
                          <Terminal size={14} className="text-violet-400" />
                          <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Source Code / Data View</span>
                        </div>
                        <button className="text-[10px] font-black text-violet-400 hover:text-white uppercase tracking-tighter">Copy to Clipboard</button>
                      </div>
                      <pre className="text-[13px] font-mono leading-relaxed text-zinc-300 bg-[#050505] p-6 rounded-2xl border border-zinc-800/50 overflow-x-auto shadow-inner max-h-[500px] custom-scrollbar">
                        <code>{item.content}</code>
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}