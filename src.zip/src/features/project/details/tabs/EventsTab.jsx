import React, { useState, useEffect, useRef } from "react";
import { 
  Activity, Terminal, Cpu, ShieldAlert, CheckCircle2, 
  Clock, Filter, Zap, Play, Pause, Trash2 
} from "lucide-react";

export default function EventsTab({ project }) {
  const [isLive, setIsLive] = useState(true);
  const [filter, setFilter] = useState("All");
  const scrollRef = useRef(null);

  // Mock WebSocket Data Stream
  const [events, setEvents] = useState([
    { id: 10, time: "18:05:22", type: "system", desc: "WebSocket Connection Established", data: "SID: 882-991-XP", priority: "low" },
    { id: 9, time: "18:04:10", type: "agent", desc: "Architect Agent analyzing G3 Schema", data: "Latency: 450ms", priority: "medium" },
    { id: 8, time: "17:59:45", type: "gate", desc: "Critical Gate G2 Approved by Admin", data: "Auth: SuperUser", priority: "high" },
    { id: 7, time: "17:55:12", type: "error", desc: "Validation Failed: US-102 Criteria Mismatch", data: "Error code: E-404", priority: "urgent" },
    { id: 6, time: "17:50:00", type: "system", desc: "Automated Backup Completed", data: "Size: 1.2GB", priority: "low" }
  ]);

  const getBadgeStyle = (type) => {
    const styles = {
      system: "bg-zinc-800 text-zinc-400 border-zinc-700",
      agent: "bg-violet-500/10 text-violet-400 border-violet-500/20",
      gate: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
      error: "bg-red-500/10 text-red-400 border-red-500/20",
    };
    return styles[type] || styles.system;
  };

  const filteredEvents = events.filter(e => filter === "All" || e.type === filter.toLowerCase());

  return (
    <div className="flex flex-col h-full max-w-[1500px] mx-auto w-full p-8 animate-in fade-in duration-500">
      
      {/* --- STREAM CONTROL HEADER --- */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-8 bg-[#0b0b0d] p-6 rounded-[2rem] border border-zinc-800 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-violet-500/10 rounded-2xl text-violet-400">
            <Activity size={24} className={isLive ? "animate-pulse" : ""} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Telemetry Log</h2>
            <div className="flex items-center gap-2 mt-1">
              <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-zinc-700'}`} />
              <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">
                {isLive ? 'Live WebSocket Stream' : 'Stream Paused'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-black/40 p-2 rounded-2xl border border-zinc-800/50">
          <div className="flex gap-1 border-r border-zinc-800 pr-3 mr-1">
            {['All', 'Agent', 'Gate', 'Error'].map(t => (
              <button 
                key={t}
                onClick={() => setFilter(t)}
                className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase transition-all ${filter === t ? 'bg-zinc-100 text-zinc-950' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                {t}
              </button>
            ))}
          </div>
          <button 
            onClick={() => setIsLive(!isLive)}
            className={`p-2 rounded-xl transition-all ${isLive ? 'text-orange-500 hover:bg-orange-500/10' : 'text-emerald-500 hover:bg-emerald-500/10'}`}
          >
            {isLive ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button className="p-2 text-zinc-600 hover:text-red-500 transition-all">
            <Trash2 size={20} />
          </button>
        </div>
      </div>

      {/* --- EVENT LOG --- */}
      <div className="flex-1 overflow-y-auto custom-scrollbar space-y-3 pr-4 pb-20">
        {filteredEvents.map((event) => (
          <div 
            key={event.id} 
            className="group flex items-start gap-6 p-5 bg-[#09090b] border border-zinc-800/60 rounded-2xl hover:border-zinc-700 hover:bg-zinc-900/20 transition-all animate-in slide-in-from-top-2"
          >
            {/* Timestamp */}
            <div className="text-sm font-mono font-bold text-zinc-600 shrink-0 pt-1 group-hover:text-violet-400 transition-colors">
              {event.time}
            </div>

            {/* Content Body */}
            <div className="flex-1 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border tracking-tighter ${getBadgeStyle(event.type)}`}>
                    {event.type}
                  </span>
                  <h4 className="text-sm font-bold text-zinc-200 tracking-tight">{event.desc}</h4>
                </div>
                <p className="text-xs text-zinc-500 font-medium italic">Payload: <span className="text-zinc-400 font-mono">{event.data}</span></p>
              </div>

              {/* Status Icons */}
              <div className="flex items-center gap-3 shrink-0">
                 {event.priority === 'urgent' ? (
                   <ShieldAlert size={16} className="text-red-500 animate-bounce" />
                 ) : event.type === 'gate' ? (
                   <CheckCircle2 size={16} className="text-emerald-500" />
                 ) : (
                   <Zap size={16} className="text-zinc-800 group-hover:text-amber-500 transition-colors" />
                 )}
              </div>
            </div>
          </div>
        ))}

        {filteredEvents.length === 0 && (
          <div className="h-64 flex flex-col items-center justify-center text-zinc-700 opacity-20">
            <Terminal size={48} className="mb-4" />
            <span className="font-black uppercase tracking-widest text-sm">Waiting for incoming packets...</span>
          </div>
        )}
      </div>
    </div>
  );
}