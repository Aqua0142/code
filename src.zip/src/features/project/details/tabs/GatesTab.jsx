import React, { useState } from "react";
import { 
  History, CheckCircle2, Edit3, RotateCcw, ChevronDown, 
  ChevronRight, User, Clock, FileDiff, MessageSquare, 
  Filter, ArrowRightLeft, Info, Search
} from "lucide-react";

export default function GatesTab({ project }) {
  const [expandedDecision, setExpandedDecision] = useState(null);
  const [filterAction, setFilterAction] = useState("All");

  // Mock Decision History Data
  const decisions = [
    {
      id: "dec-104",
      gateId: "G1",
      stage: "Requirements",
      agent: "Product Architect",
      action: "approved-with-edits",
      reviewer: "Aqua (Admin)",
      timestamp: "2026-04-02 14:20",
      revisions: 2,
      notes: "Expanded high-concurrency requirements to include Redis failover logic. The initial agent draft missed the soft-lock TTL specs.",
      contextInjected: "Standard Fintech Scalability Protocol v2.1",
      modifications: [
        { field: "US-102 Criteria", from: "Lock items during checkout", to: "Redis-based TTL lock (10m); Auto-release on timeout" },
        { field: "Epic: Core Engine", from: "Cart Service", to: "High-Concurrency Cart Service" }
      ]
    },
    {
      id: "dec-103",
      gateId: "G2",
      stage: "Planning",
      agent: "Scrum Master",
      action: "approved",
      reviewer: "System (Auto)",
      timestamp: "2026-04-01 10:15",
      revisions: 1,
      notes: "All stories mapped to sprints within velocity limits. Verified by compliance engine.",
      contextInjected: null,
      modifications: []
    },
    {
      id: "dec-102",
      gateId: "G1",
      stage: "Requirements",
      agent: "Product Architect",
      action: "revised",
      reviewer: "Aqua (Admin)",
      timestamp: "2026-03-30 09:00",
      revisions: 1,
      notes: "Initial user stories were too generic. Requested focus on semantic search vectors.",
      contextInjected: "Competitor Analysis PDF",
      modifications: [
        { field: "US-201", from: "Basic Search", to: "AI-Powered Semantic Search" }
      ]
    }
  ];

  const getActionStyle = (action) => {
    const styles = {
      'approved': "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
      'approved-with-edits': "bg-violet-500/10 text-violet-400 border-violet-500/20",
      'revised': "bg-orange-500/10 text-orange-400 border-orange-500/20",
      'rolled-back': "bg-red-500/10 text-red-400 border-red-500/20"
    };
    return styles[action] || "bg-zinc-800 text-zinc-400 border-zinc-700";
  };

  const filteredDecisions = decisions.filter(d => filterAction === "All" || d.action === filterAction.toLowerCase().replace(/ /g, '-'));

  return (
    <div className="flex flex-col gap-8 p-8 max-w-[1500px] mx-auto w-full animate-in fade-in duration-500 pb-20">
      
      {/* --- AUDIT HEADER & FILTERS --- */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 bg-[#0b0b0d] p-6 rounded-[2rem] border border-zinc-800 shadow-2xl">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 rounded-2xl text-emerald-400">
            <History size={24} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Intervention Ledger</h2>
            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] mt-1">Timeline of Human-AI Alignment</p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-black/40 p-1.5 rounded-xl border border-zinc-800/50">
          {['All', 'Approved', 'Revised', 'Rolled Back'].map(a => (
            <button 
              key={a}
              onClick={() => setFilterAction(a)}
              className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${filterAction === a ? 'bg-zinc-100 text-zinc-950 shadow-lg' : 'text-zinc-500 hover:text-zinc-200'}`}
            >
              {a}
            </button>
          ))}
        </div>
      </div>

      {/* --- DECISION TIMELINE --- */}
      <div className="space-y-4 relative before:absolute before:left-8 before:top-0 before:bottom-0 before:w-px before:bg-zinc-800/50">
        {filteredDecisions.map((dec) => (
          <div key={dec.id} className="relative pl-16 group">
            {/* Timeline Marker */}
            <div className={`absolute left-6 top-6 w-4 h-4 rounded-full border-4 border-[#09090b] z-10 transition-transform group-hover:scale-125 ${
              dec.action.includes('approved') ? 'bg-emerald-500' : 'bg-orange-500'
            }`} />

            <div className={`bg-[#0b0b0d] border border-zinc-800/80 rounded-2xl overflow-hidden transition-all hover:border-zinc-600 ${expandedDecision === dec.id ? 'ring-1 ring-violet-500/30 shadow-2xl shadow-violet-500/5' : ''}`}>
              
              {/* SUMMARY ROW */}
              <div 
                onClick={() => setExpandedDecision(expandedDecision === dec.id ? null : dec.id)}
                className="p-6 cursor-pointer flex items-center justify-between gap-6"
              >
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono font-bold text-violet-400 bg-violet-400/5 px-2 py-0.5 rounded border border-violet-400/10">
                      {dec.gateId} | {dec.stage}
                    </span>
                    <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${getActionStyle(dec.action)}`}>
                      {dec.action.replace(/-/g, ' ')}
                    </span>
                    <span className="text-[10px] text-zinc-600 font-bold uppercase tracking-tighter">
                      Rev: {dec.revisions}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-zinc-100 group-hover:text-white transition-colors">{dec.notes}</h3>
                  <div className="flex items-center gap-4 text-[11px] text-zinc-500 font-medium">
                    <span className="flex items-center gap-1.5"><User size={12} /> {dec.reviewer}</span>
                    <span className="flex items-center gap-1.5"><Clock size={12} /> {dec.timestamp}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  {dec.modifications.length > 0 && <FileDiff size={18} className="text-zinc-700" />}
                  {expandedDecision === dec.id ? <ChevronDown size={20} className="text-violet-400" /> : <ChevronRight size={20} className="text-zinc-600" />}
                </div>
              </div>

              {/* EXPANDED DETAIL VIEW */}
              {expandedDecision === dec.id && (
                <div className="border-t border-zinc-800/50 bg-black/40 p-8 space-y-8 animate-in slide-in-from-top-2 duration-300">
                  
                  {/* Notes & Feedback */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-zinc-400">
                        <MessageSquare size={14} className="text-violet-400" />
                        <span className="text-[10px] font-black uppercase tracking-widest">Reviewer Feedback</span>
                      </div>
                      <p className="text-xs text-zinc-300 italic leading-relaxed bg-zinc-900/30 p-4 rounded-xl border border-zinc-800/50">
                        "{dec.notes}"
                      </p>
                    </div>

                    {dec.contextInjected && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 text-zinc-400">
                          <Info size={14} className="text-sky-400" />
                          <span className="text-[10px] font-black uppercase tracking-widest">Supplemental Context</span>
                        </div>
                        <div className="text-xs text-sky-400 font-mono bg-sky-400/5 p-4 rounded-xl border border-sky-400/10">
                          {dec.contextInjected}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Inline Diff Summary */}
                  {dec.modifications.length > 0 && (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-zinc-400">
                        <FileDiff size={14} className="text-emerald-400" />
                        <span className="text-[10px] font-black uppercase tracking-widest">Modification Diff (v{dec.revisions-1} → v{dec.revisions})</span>
                      </div>
                      <div className="space-y-2">
                        {dec.modifications.map((mod, idx) => (
                          <div key={idx} className="bg-[#050505] border border-zinc-800 rounded-xl overflow-hidden shadow-inner">
                            <div className="px-4 py-2 bg-zinc-900/40 border-b border-zinc-800 flex items-center justify-between">
                              <span className="text-[10px] font-mono font-bold text-zinc-400">{mod.field}</span>
                              <ArrowRightLeft size={10} className="text-zinc-700" />
                            </div>
                            <div className="p-4 grid grid-cols-2 gap-4">
                              <div className="text-[11px] text-red-400/70 font-mono bg-red-400/5 p-2 rounded line-through">
                                - {mod.from}
                              </div>
                              <div className="text-[11px] text-emerald-400 font-mono bg-emerald-400/5 p-2 rounded">
                                + {mod.to}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <button className="text-[10px] font-black text-violet-400 uppercase tracking-widest hover:text-white transition-colors flex items-center gap-2 ml-auto">
                    View Full JSON Comparison Stage <ChevronRight size={12} />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}