import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronRight, X, Database } from "lucide-react";
import { TECH_CATALOG, RUNTIME_MAP } from "../../../utils/constants";

export default function TechStackSelector({
  selections = {},
  onSelectionsChange,
  runtimeParts = {},
  onRuntimePartsChange,
}) {
  const activeTab = selections._activeTab || null;

  const handleTechSelect = (categoryKey, tech) => {
    const current = selections[categoryKey] || [];
    const isSelected = current.some((item) => item.value === tech.value);
    
    const newSels = isSelected
      ? current.filter((i) => i.value !== tech.value)
      : [...current, tech];
    
    const newRuns = isSelected
      ? (runtimeParts[categoryKey] || []).filter(
          (r) => r !== RUNTIME_MAP[tech.value]
        )
      : [...(runtimeParts[categoryKey] || []), RUNTIME_MAP[tech.value]];

    onSelectionsChange({ ...selections, [categoryKey]: newSels });
    onRuntimePartsChange({ ...runtimeParts, [categoryKey]: newRuns });
  };

  const setActiveTab = (tab) => {
    onSelectionsChange({ ...selections, _activeTab: tab });
  };

  const labelBase =
    "text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1 mb-3 flex items-center gap-2";

  return (
    <div className="mb-4">
      <label className={labelBase}>
        <Database size={14} className="text-blue-400" /> Technology Stack
      </label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.keys(TECH_CATALOG).map((key) => {
          const category = TECH_CATALOG[key];
          const sels = selections[key] || [];
          const isOpen = activeTab === key;
          
          return (
            <div key={key} className="flex flex-col gap-2 relative">
              <button
                onClick={() => setActiveTab(isOpen ? null : key)}
                className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl border text-[11px] font-black transition-all ${
                  isOpen
                    ? "border-violet-500 bg-violet-600/20 text-white shadow-[0_0_20px_rgba(139,92,246,0.2)]"
                    : sels.length > 0
                      ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-400"
                      : "border-white/20 bg-white/5 text-slate-400"
                }`}
              >
                <div className="flex items-center gap-3">
                  {sels.length > 0 ? (
                    <Check
                      size={14}
                      strokeWidth={3}
                      className="text-emerald-500"
                    />
                  ) : (
                    <category.icon size={14} />
                  )}
                  <span>{category.label}</span>
                </div>
                <ChevronRight
                  size={16}
                  className={`transition-transform ${isOpen ? "-rotate-90" : ""}`}
                />
              </button>

              <div className="flex flex-nowrap gap-1.5 px-1 overflow-x-auto no-scrollbar min-h-[28px]">
                <AnimatePresence>
                  {sels.map((tech) => (
                    <motion.div
                      key={tech.value}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="flex items-center gap-2 px-2.5 py-1 bg-violet-500/10 border border-violet-500/30 rounded-lg text-[9px] font-bold text-violet-300 whitespace-nowrap flex-shrink-0"
                    >
                      {tech.name}{" "}
                      <X
                        size={10}
                        onClick={() => handleTechSelect(key, tech)}
                        className="cursor-pointer hover:text-rose-500 ml-1"
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute bottom-[calc(100%+10px)] left-0 right-0 bg-[#1c2028] border border-white/20 rounded-xl shadow-2xl z-[100] p-2 backdrop-blur-md"
                  >
                    {category.options.map((opt) => {
                      const isSelected = sels.some((s) => s.value === opt.value);
                      return (
                        <button
                          key={opt.value}
                          onClick={() => handleTechSelect(key, opt)}
                          className={`w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-[10px] font-bold transition-all ${
                            isSelected
                              ? "bg-violet-600 text-white"
                              : "text-slate-400 hover:bg-white/5"
                          }`}
                        >
                          <span>{opt.name}</span>{" "}
                          {isSelected && <Check size={12} strokeWidth={4} />}
                        </button>
                      );
                    })}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
}
