import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Plus,
  X,
  Link as LinkIcon,
  History,
  ClipboardList,
  ChevronRight,
  BookOpen,
  Sparkles,
  Users,
  CreditCard,
  FolderOpen,
  Monitor,
  ArrowLeft,
  GitBranch,
  Zap,
  ZapOff,
  Cpu,
  Puzzle,
} from "lucide-react";
import TechStackSelector from "./TechStackSelector";
 
export default function ProjectSetup({ onBack = null }) {
  const navigate = useNavigate();
  const folderInputRef = useRef(null);
 
  // --- STATES ---
  const [projectName, setProjectName] = useState("");
  const [projectType, setProjectType] = useState("");
  const [requirements, setRequirements] = useState("");
  const [repoUrl, setRepoUrl] = useState("");
  const [codeRepoUrl, setCodeRepoUrl] = useState("");
  const [docRepoUrl, setDocRepoUrl] = useState("");
  const [executionMode, setExecutionMode] = useState("ai");
  const [frameworkMode, setFrameworkMode] = useState("agentic");
  const [billingId, setBillingId] = useState("");
  const [selections, setSelections] = useState({});
  const [runtimeParts, setRuntimeParts] = useState({});
  const [deployment, setDeployment] = useState("");
  const [pathMode, setPathMode] = useState("external");
  const [attachments, setAttachments] = useState([]);
  const [urlInput, setUrlInput] = useState("");
 
  // ... HYDRATION & LOGIC (Exactly same) ...
  useEffect(() => {
    const savedData = sessionStorage.getItem("latest_project_setup");
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setProjectName(parsed.projectName || "");
      setProjectType(parsed.projectType || "");
      setRequirements(parsed.requirements || "");
      setAttachments(parsed.attachments || []);
      setSelections(parsed.selections || {});
      setDeployment(parsed.deployment || "");
      setRepoUrl(parsed.repoUrl || "");
      setCodeRepoUrl(parsed.codeRepoUrl || "");
      setDocRepoUrl(parsed.docRepoUrl || "");
      setExecutionMode(parsed.executionMode || "ai");
      setFrameworkMode(parsed.frameworkMode || "agentic");
      setBillingId(parsed.billingId || "");
    }
  }, []);
 
  useEffect(() => {
    const allRuntimes = Object.values(runtimeParts).flat().filter(Boolean);
    setDeployment([...new Set(allRuntimes)].join(", "));
  }, [runtimeParts]);
 
  const handleBackNavigation = () => {
    sessionStorage.removeItem("latest_project_setup");
    onBack ? onBack() : navigate("/");
  };
 
  const handleCreate = () => {
    if (!projectName) return alert("Project Name required.");
    //if (!repoUrl) return alert("Target Repository required.");
    if (!codeRepoUrl) return alert("Target Code Repository required.");
    if (!docRepoUrl) return alert("Target Repository required.");
    const setupData = {
      id: Date.now().toString(),
      projectName,
      projectType,
      requirements,
      attachments,
      selections,
      deployment,
      repoUrl,
      codeRepoUrl,
      docRepoUrl,
      executionMode,
      frameworkMode,
      billingId,
      status: "Running",
      stage: "Phase Selection",
      created: new Date().toISOString().split("T")[0],
    };
    sessionStorage.setItem("latest_project_setup", JSON.stringify(setupData));
    navigate("/phase-selection", { state: { draft: setupData } });
  };
 

 
  const isReady =
    projectName.trim() !== "" &&
    // repoUrl.trim() !== "" &&
    codeRepoUrl.trim() !== "" &&
    docRepoUrl.trim() !== "";
 
  // Fixed Folder Upload Handler
  const handleFolderChange = (e) => {
    const files = e.target.files;
    if (files.length > 0) {
      const folderName =
        files[0].webkitRelativePath.split("/")[0] || files[0].name;
      setAttachments((prev) => [
        ...prev,
        { type: "local", name: folderName, data: folderName },
      ]);
      setUrlInput(""); // Clear input if something was typed
    }
  };
 
  const handleUrlAdd = () => {
    if (urlInput.trim()) {
      /* 🟢 Set the first added link as the repoUrl for Phase Selection */
      if (!repoUrl) {
        setRepoUrl(urlInput.trim());
      }
 
      /* Add to the visual attachments list */
      setAttachments((prev) => [
        ...prev,
        {
          type: pathMode,
          name: urlInput.trim(),
          data: urlInput.trim(),
        },
      ]);
 
      /* Clear the input box */
      setUrlInput("");
    }
  };
 
  const inputBase =
    "w-full p-3 bg-white/5 border border-white/20 rounded-xl outline-none transition-all hover:border-violet-500/50 focus:border-violet-500 text-slate-100 text-sm shadow-inner placeholder:text-slate-600";
  const labelBase =
    "text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] ml-1 mb-3 flex items-center gap-2";
  const sectionBase = "py-4 ";
 
  return (
    <div className="flex-1 min-h-screen bg-[#0f1115] text-slate-100 flex flex-col items-center p-12 font-sans overflow-y-auto custom-scrollbar">
      <div className="w-full max-w-6xl">
        <header className="flex justify-between items-center pb-8 border-b border-white/20 mb-8">
          <div className="flex items-center gap-6">
            <button
              onClick={handleBackNavigation}
              className="p-3 bg-slate-800/50 hover:bg-slate-700 rounded-2xl text-slate-400 border border-white/10 active:scale-95 transition-all"
            >
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-3xl font-black tracking-tighter text-white uppercase italic leading-none">
              Project Setup
            </h1>
          </div>
          <Sparkles className="text-violet-500 opacity-30" size={48} />
        </header>
 
        {/* TOP ROW: IDENTITY & BILLING */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="md:col-span-1">
            <label className={labelBase}>
              Project Name <span className="text-rose-500 ml-0.5">*</span>
            </label>
            <input
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="e.g. neuro-pulse"
              className={inputBase}
              required
            />
          </div>
          <div className="md:col-span-1">
            <label className={labelBase}>Category</label>
            <input
              value={projectType}
              onChange={(e) => setProjectType(e.target.value)}
              placeholder="e.g. Biomedical SaaS"
              className={inputBase}
            />
          </div>
          <div className="md:col-span-1">
            <label className={labelBase}>
              <CreditCard size={12} className="text-amber-500" /> Billing ID
            </label>
            <input
              value={billingId}
              onChange={(e) => setBillingId(e.target.value)}
              placeholder="XXX-XXX-XXXX"
              className={inputBase}
            />
          </div>
        </div>
 
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start mb-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="flex flex-col">
              <label className={labelBase}>
                <ClipboardList size={12} className="text-violet-500" /> Project
                Description
              </label>
              <textarea
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                className={`${inputBase} min-h-[180px] max-h-[400px] resize-y leading-relaxed custom-scrollbar`}
                placeholder="Describe what you want built. Include business goals, user types, key features, constraints, and any non-functional requirements such as performance or compliance."
              />
            </div>
 
            {/* 🟢 TARGET REPOSITORIES SECTION - FIXED */}
            <div className="space-y-4">
              <label className={labelBase}>
                <History size={14} /> Target Repositories{" "}
                <span className="text-rose-500 ml-0.5">*</span>
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. Target Code Repository */}
                <div className="relative group">
                  <GitBranch
                    size={16}
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-blue-500/40"
                  />
                  <input
                    value={codeRepoUrl}
                    onChange={(e) => setCodeRepoUrl(e.target.value)}
                    placeholder="Code Repo URL *"
                    className={`${inputBase} pl-12`}
                    required
                  />
                </div>
                {/* 2. Target Doc Repository */}
                <div className="relative group">
                  <BookOpen
                    size={16}
                    className="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-500/40"
                  />
                  <input
                    value={docRepoUrl}
                    onChange={(e) => setDocRepoUrl(e.target.value)}
                    placeholder="Doc Repo URL *"
                    className={`${inputBase} pl-12`}
                    required
                  />
                </div>
              </div>
            </div>
          </div>
 
          {/* RIGHT COLUMN: FILES & TOGGLES (Shifted down via mt-2) */}
          <div className="space-y-10 mt-2">
            <div className="flex flex-col">
              <div className="flex justify-between items-center mb-3 px-1">
                <label className={`${labelBase} flex items-center gap-1.5`}>
                  <FolderOpen size={12} className="text-violet-400" /> Project
                  files
                </label>
                <div className="flex bg-black/40 rounded-lg p-1 border border-white/20 scale-90">
                  <button
                    onClick={() => setPathMode("external")}
                    className={`px-3 py-1 text-[9px] font-black rounded-md transition-all ${pathMode === "external" ? "bg-violet-600 text-white" : "text-zinc-500"}`}
                  >
                    URL
                  </button>
                  <button
                    onClick={() => setPathMode("local")}
                    className={`px-3 py-1 text-[9px] font-black rounded-md transition-all ${pathMode === "local" ? "bg-violet-600 text-white" : "text-zinc-500"}`}
                  >
                    FOLDER
                  </button>
                </div>
              </div>
              <div className="flex flex-col gap-4">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    {/* Fixed directory upload attributes */}
                    <input
                      type="file"
                      ref={folderInputRef}
                      webkitdirectory=""
                      directory=""
                      className="hidden"
                      onChange={handleFolderChange}
                    />
                    <input
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      placeholder={
                        pathMode === "local"
                          ? "Select folder..."
                          : "Add source links..."
                      }
                      className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-2.5 text-[11px] outline-none"
                    />
                    {pathMode === "local" && (
                      <FolderOpen
                        size={14}
                        onClick={() => folderInputRef.current.click()}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-violet-400 cursor-pointer"
                      />
                    )}
                  </div>
                  <button
                    onClick={handleUrlAdd}
                    className="bg-violet-600 p-2.5 rounded-xl text-white active:scale-90 transition-all"
                  >
                    <Plus size={18} />
                  </button>
                </div>
                <div className="max-h-[100px] overflow-y-auto custom-scrollbar space-y-2">
                  {attachments.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-[10px]"
                    >
                      <div className="flex items-center gap-2 truncate">
                        {item.type === "local" ? (
                          <Monitor size={10} className="text-emerald-400" />
                        ) : (
                          <LinkIcon size={10} className="text-violet-400" />
                        )}
                        <span className="truncate text-slate-300 font-mono">
                          {item.name}
                        </span>
                      </div>
                      <X
                        size={12}
                        onClick={() =>
                          setAttachments((prev) =>
                            prev.filter((_, i) => i !== idx),
                          )
                        }
                        className="cursor-pointer hover:text-rose-500"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
 
            {/* TOGGLES CONTAINER */}
            <div className="space-y-5">
              {/* EXECUTION MODE */}
              <div>
                <label className={labelBase}>
                  <Sparkles size={14} className="text-amber-500" /> Execution
                  Logic
                </label>
                <div className="flex bg-white/5 border border-white/10 p-1 rounded-2xl w-full shadow-inner">
                  {/* AI OPTION */}
                  <div className="relative flex-1 group">
                    <button
                      onClick={() => setExecutionMode("ai")}
                      className={`w-full flex items-center justify-center gap-2 py-3 text-[11px] font-black rounded-xl transition-all ${
                        executionMode === "ai"
                          ? "bg-violet-600 text-white shadow-xl"
                          : "text-zinc-500 hover:text-zinc-300"
                      }`}
                    >
                      <Cpu size={14} /> AI
                    </button>
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-48 p-3 bg-[#1a1d26] border border-violet-500/30 rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 z-50 text-center">
                      <p className="text-[9px] text-violet-400 font-black uppercase tracking-widest mb-1">
                        AI
                      </p>
                      <p className="text-[11px] leading-relaxed text-slate-400">
                        AI agents build the entire project end-to-end. Humans
                        will review, suggest edits, or request changes.
                      </p>
                      <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-[#1a1d26]" />
                    </div>
                  </div>
 
                  {/* HYBRID OPTION */}
                  <div className="relative flex-1 group">
                    <button
                      onClick={() => setExecutionMode("hybrid")}
                      className={`w-full flex items-center justify-center gap-2 py-3 text-[11px] font-black rounded-xl transition-all ${
                        executionMode === "hybrid"
                          ? "bg-amber-600 text-white shadow-xl"
                          : "text-zinc-500 hover:text-zinc-300"
                      }`}
                    >
                      <Users size={14} /> HYBRID
                    </button>
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-48 p-3 bg-[#1a1d26] border border-amber-500/30 rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 z-50 text-center">
                      <p className="text-[9px] text-amber-500 font-black uppercase tracking-widest mb-1">
                        Hybrid Collaboration
                      </p>
                      <p className="text-[11px] leading-relaxed text-slate-400">
                        AI agents and humans collaborate. Humans can build
                        alongside agents.
                      </p>
                      <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-[#1a1d26]" />
                    </div>
                  </div>
                </div>
              </div>
 
              {/* FRAMEWORK TYPE */}
              <div>
                <label className={labelBase}>
                  <Puzzle size={14} className="text-violet-500" /> Framework
                  Type
                </label>
                <div className="flex bg-white/5 border border-white/10 p-1 rounded-2xl w-full shadow-inner">
                  {/* AGENTIC OPTION */}
                  <div className="relative flex-1 group">
                    <button
                      onClick={() => setFrameworkMode("agentic")}
                      className={`w-full flex items-center justify-center gap-2 py-3 text-[11px] font-black rounded-xl transition-all ${
                        frameworkMode === "agentic"
                          ? "bg-violet-600 text-white shadow-xl"
                          : "text-zinc-500 hover:text-zinc-300"
                      }`}
                    >
                      <Zap size={14} /> AGENTIC
                    </button>
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-48 p-3 bg-[#1a1d26] border border-violet-500/30 rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 z-50 text-center">
                      <p className="text-[9px] text-violet-400 font-black uppercase tracking-widest mb-1">
                        Agentic
                      </p>
                      <p className="text-[11px] leading-relaxed text-slate-400">
                        Autonomous AI agents integrated for independent
                        reasoning and task execution.
                      </p>
                      <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-[#1a1d26]" />
                    </div>
                  </div>
 
                  {/* CLASSIC OPTION */}
                  <div className="relative flex-1 group">
                    <button
                      onClick={() => setFrameworkMode("classic")}
                      className={`w-full flex items-center justify-center gap-2 py-3 text-[11px] font-black rounded-xl transition-all ${
                        frameworkMode === "classic"
                          ? "bg-amber-600 text-white shadow-xl"
                          : "text-zinc-500 hover:text-zinc-300"
                      }`}
                    >
                      <ZapOff size={14} /> CLASSIC
                    </button>
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 w-48 p-3 bg-[#1a1d26] border border-white/10 rounded-xl shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 z-50 text-center">
                      <p className="text-[9px] text-amber-400 font-black uppercase tracking-widest mb-1">
                        Classic
                      </p>
                      <p className="text-[11px] leading-relaxed text-slate-400">
                        Standard software architecture utilizing traditional
                        logic without autonomous agent modules.
                      </p>
                      <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-[#1a1d26]" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
 
        <TechStackSelector
          selections={selections}
          onSelectionsChange={setSelections}
          runtimeParts={runtimeParts}
          onRuntimePartsChange={setRuntimeParts}
        />
 
        {/* FOOTER */}
        <div className="mt-4">
          <div className="flex justify-end mb-8">
            <button
              onClick={handleCreate}
              className={`group flex items-center gap-3 px-8 py-3 rounded-xl font-bold uppercase tracking-widest text-xs transition-all duration-500 border border-white/10 active:scale-95 ${
                isReady
                  ? "bg-violet-600 text-white shadow-[0_0_30px_rgba(139,92,246,0.3)] hover:bg-violet-500"
                  : "bg-zinc-800 text-zinc-500 cursor-not-allowed opacity-70"
              }`}
            >
              <span>Next</span>
              <ChevronRight
                size={18}
                className="group-hover:translate-x-1 transition-transform"
              />
            </button>
          </div>
 
          {/* The line is now below the button */}
          <div className="border-t border-white/10 pb-20" />
        </div>
      </div>
 
      <style
        dangerouslySetInnerHTML={{
          __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar:horizontal { height: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.1); border-radius: 20px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(139, 92, 246, 0.4); }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `,
        }}
      />
    </div>
  );
}
 
 