import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LayoutDashboard, Eye, EyeOff } from "lucide-react";
import { useAuth } from "../../hooks/useAuth";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";

const DEFAULT_USERS = [
  { 
    username: "praveen@elite", 
    password: "gate", 
    name: "Praveen", 
    role: "Developer" 
  },
  { 
    username: "oviya@elite", 
    password: "admin", 
    name: "Oviya", 
    role: "Architect" 
  }
];
 
function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
 
  const navigate = useNavigate();
  const { login } = useAuth();
 
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Credentials required to access the pod.");
      return;
    }

    if (isLogin) {
      const user = DEFAULT_USERS.find(
        (u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
      );

      if (user) {
        setError("");
        login(user, "mock-token");
        navigate("/");
      } else {
        setError("Access Denied: Invalid Squad Credentials.");
      }
    } else {
      setIsLogin(true);
      alert("Account created! Please log in.");
    }
  };
 
  return (
    <div className="relative flex-1 flex items-center justify-center bg-[#09090b] overflow-hidden text-zinc-100 font-sans py-12">
     
      {/* Ambient Lighting - Increased spread for a softer look */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />
 
      {/* Glassmorphism Card */}
      <form
        onSubmit={handleSubmit}
        className="relative z-10 bg-zinc-900/40 backdrop-blur-2xl border border-zinc-800 p-10 rounded-3xl w-[420px] shadow-[0_20px_50px_rgba(0,0,0,0.5)] transition-all duration-500"
      >
        {/* Accent line at the top of the card */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-violet-500 to-transparent" />
        {/* Accent line at the bottom of the card */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-violet-500 to-transparent" />
        
        <div className="text-center mb-10">
          {/* Flex container to hold Logo and Title side-by-side */}
          <div className="flex items-center justify-center gap-4">
            {/* Logo Icon */}
            <div className="w-12 h-12 bg-violet-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-violet-600/20">
              <LayoutDashboard size={25} className="text-white" />
            </div>

            {/* Title */}
            <h2 className="text-3xl font-bold tracking-tight text-white uppercase">
              Elite AI <span className="text-violet-500">Squad</span>
            </h2>
          </div>

          {/* Subtitle remains centered below the logo/title group */}
          <p className="text-[10px] text-zinc-500 uppercase tracking-[0.3em] mt-3 font-semibold">
            {isLogin ? "Login page" : "Sign In page"}
          </p>
        </div>
 
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs p-3 rounded-xl mb-6 text-center animate-pulse">
            {error}
          </div>
        )}
 
        <div className="space-y-5">
          <Input
            type="text"
            placeholder="USERNAME"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="bg-zinc-950/40"
          />
         
          <div className="relative">
            <Input
              type={showPassword ? "text" : "password"}
              placeholder="PASSWORD"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-zinc-950/60 pr-12"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-100 transition-colors p-1"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
        </div>
 
        <div className="mt-10">
          <Button type="submit" className="w-full">
            {isLogin ? "LOGIN" : "SIGN IN"}
          </Button>
        </div>
 
        <div className="mt-10 text-center flex flex-col items-center gap-4">
          <p className="text-sm text-zinc-500">
            {isLogin ? "New to the Elite AI?" : "Already have account?"}
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-violet-400 hover:text-violet-300 font-bold transition-colors ml-2"
            >
              {isLogin ? "Sign In" : "Login"}
            </button>
          </p>
 
          {isLogin && (
            <Button variant="ghost" size="sm" type="button" className="text-[10px] text-zinc-600 uppercase tracking-widest hover:text-zinc-400">
              Forgot Credentials?
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}
 
export default Login;
 