import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, FileText, Trash2, Link as LinkIcon, ArrowLeft, Zap, X } from "lucide-react";
import { RUNTIME_MAP } from "../../utils/constants";
import TechStackSelector from "../project/setup/TechStackSelector";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import Textarea from "../../components/ui/Textarea";

export default function AddExistingProject({ onBack = null, onProjectImported = null }) {
  const navigate = useNavigate();

  // Core States
  const [projectName, setProjectName] = useState("");
  const [projectType, setProjectType] = useState("");
  const [uploadType, setUploadType] = useState("file");
  const [files, setFiles] = useState([]);
  const [repoUrls, setRepoUrls] = useState([]);
  const [currentUrl, setCurrentUrl] = useState("");

  // Technology States
  const [selections, setSelections] = useState({});
  const [deployment, setDeployment] = useState("");

  const [basePath, setBasePath] = useState("/home/user/projects/my-app");
  const [modification, setModification] = useState("");

  // Sync Path with Project Name
  useEffect(() => {
    setBasePath(`/home/user/projects/${projectName || "my-app"}`);
  }, [projectName]);

  // Sync Deployment/Runtime values based on Technology Selections
  useEffect(() => {
    const runtimes = Object.values(selections).flat().map(tech => RUNTIME_MAP[tech.value]).filter(Boolean);
    setDeployment([...new Set(runtimes)].join(", "));
  }, [selections]);

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files).map(f => ({ type: 'file', name: f.name, data: f }));
    setFiles((prev) => [...prev, ...selectedFiles]);
  };

  const removeFile = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const addUrl = () => {
    if (currentUrl.trim()) {
      setRepoUrls((prev) => [...prev, currentUrl.trim()]);
      setCurrentUrl("");
    }
  };

  const removeUrl = (index) => {
    setRepoUrls((prev) => prev.filter((_, i) => i !== index));
  };



  const handleAddProject = () => {
    if (!projectName) return alert("Project Name required.");

    const importedProjectDraft = {
      id: Date.now(),
      projectName: projectName,
      projectType: projectType,
      requirements: modification, // Mapping modifications to requirements for config step
      status: 'Running',
      isImported: true,
      created: new Date().toISOString().split('T')[0],
      sources: uploadType === "file" ? files.map(f => f.name) : repoUrls,
      selections,
      deployment,
      basePath: basePath,
      // Defaulting stages for configuration hydration
      stages: [
        { id: 'G1', state: 'approved' },
        { id: 'G2', state: 'executing' },
      ]
    };

    // 🟢 Step 1: Handle Callback if exists
    if (onProjectImported) {
      onProjectImported(importedProjectDraft);
    } 
    
    // 🟢 Step 2: Push to unique configure endpoint with state
    navigate("/", { state: { draft: importedProjectDraft } });
  };

  const handleBack = () => {
    if (onBack) onBack();
    else navigate("/"); // Go back to Dashboard endpoint
  };

  return (
    <div className="flex-1 min-h-screen bg-[#09090b] text-white flex justify-center p-8 font-sans overflow-y-auto custom-scrollbar">
      <style>{`.no-scrollbar::-webkit-scrollbar { display: none; }`}</style>
      <div className="w-full max-w-5xl space-y-6">

        {/* HEADER */}
        <div className="flex items-center gap-4 border-b border-zinc-800/50 pb-6">
          <Button variant="outline" size="icon" onClick={handleBack}>
            <ArrowLeft size={20} />
          </Button>
          <div>
            <h1 className="text-3xl font-black tracking-tighter bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent uppercase leading-none">
                Import Project
            </h1>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mt-1 ml-1">Connect existing codebase to AI Pod</p>
          </div>
        </div>

        {/* BASIC IDENTITY */}
        <div className="grid grid-cols-2 gap-4">
          <Input
            label="Project Name"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            placeholder="my-app"
          />
          <Input
            label="Project Category"
            value={projectType}
            onChange={(e) => setProjectType(e.target.value)}
            placeholder="e.g. SaaS, internal-tool"
          />
        </div>

        {/* IMPORT SOURCE SECTION */}
        <div className="bg-[#0c0c0e] p-6 rounded-2xl border border-zinc-800/50 space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-[10px] font-black text-violet-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <LinkIcon size={12}/> Import Source
            </h2>
            {uploadType === 'file' && files.length > 0 && (
              <Button variant="ghost" size="sm" onClick={() => setFiles([])} className="text-red-500 hover:text-red-400">
                <Trash2 size={12}/> Clear Files
              </Button>
            )}
          </div>
          
          <div className="flex bg-[#111] p-1 rounded-xl w-fit border border-zinc-800">
            <button
              onClick={() => setUploadType("file")}
              className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${uploadType === "file" ? "bg-violet-600 text-white" : "text-zinc-500 hover:text-white"}`}
            >
              Files
            </button>
            <button
              onClick={() => setUploadType("url")}
              className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${uploadType === "url" ? "bg-violet-600 text-white" : "text-zinc-500 hover:text-white"}`}
            >
              URLs
            </button>
          </div>

          {uploadType === "file" ? (
            <div className="space-y-3">
              <label className="w-full cursor-pointer block">
                <div className="flex items-center justify-between p-6 bg-zinc-950 border-2 border-dashed border-zinc-800 rounded-2xl hover:border-violet-500/50 transition group">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-violet-600/10 rounded-xl text-violet-400 group-hover:bg-violet-600/20 transition">
                        <Plus size={24} />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-zinc-300">Drop your project files here</p>
                      <p className="text-[10px] text-zinc-600 uppercase font-black tracking-widest mt-1">ZIP, JSON, or Source Files</p>
                    </div>
                  </div>
                  <div className="text-[10px] font-black uppercase tracking-[0.2em] text-violet-400 bg-violet-400/5 px-3 py-1.5 rounded-lg border border-violet-400/10">Browse</div>
                </div>
                <input type="file" multiple onChange={handleFileChange} className="hidden" />
              </label>

              {files.length > 0 && (
                <div className="max-h-[160px] overflow-y-auto no-scrollbar grid grid-cols-1 md:grid-cols-2 gap-2">
                  {files.map((f, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-zinc-900/40 border border-zinc-800 rounded-xl animate-in fade-in slide-in-from-top-1">
                      <div className="flex items-center gap-3 truncate">
                        <FileText size={16} className="text-violet-400 flex-shrink-0" />
                        <span className="text-[11px] font-medium text-zinc-300 truncate">{f.name}</span>
                      </div>
                      <button onClick={() => removeFile(index)} className="p-1.5 hover:bg-red-500/10 rounded-lg transition-colors group">
                         <X size={14} className="text-zinc-600 group-hover:text-red-500" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  value={currentUrl}
                  onChange={(e) => setCurrentUrl(e.target.value)}
                  placeholder="https://github.com/repository"
                  className="flex-1 p-3 bg-zinc-950 border border-zinc-800 rounded-xl outline-none focus:border-violet-500 text-sm font-mono text-zinc-400"
                />
                <Button onClick={addUrl}>
                  <Plus size={20}/>
                </Button>
              </div>
              {repoUrls.length > 0 && (
                <div className="max-h-[160px] overflow-y-auto no-scrollbar space-y-2">
                  {repoUrls.map((url, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-zinc-900/40 border border-zinc-800 rounded-xl">
                      <div className="flex items-center gap-3 truncate">
                        <LinkIcon size={16} className="text-violet-400 flex-shrink-0" />
                        <span className="text-[11px] font-mono text-zinc-300 truncate">{url}</span>
                      </div>
                      <X size={16} className="text-zinc-600 hover:text-red-500 cursor-pointer p-1" onClick={() => removeUrl(index)} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* TECHNOLOGY STACK */}
        <TechStackSelector
          selections={selections}
          onSelectionsChange={setSelections}
          title="Detected Technology"
        />

        {/* FOOTER: RUNTIME & PATH */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Runtime Environment"
            value={deployment}
            readOnly
            className="font-mono italic cursor-default text-violet-300/80"
          />
          <Input
            label="Installation Path"
            value={basePath}
            onChange={(e) => setBasePath(e.target.value)}
            className="font-mono"
          />
        </div>

        <Textarea
          label="Project Modifications"
          value={modification}
          onChange={(e) => setModification(e.target.value)}
          placeholder="e.g. Integrate existing DB, update CSS variables..."
          rows={4}
          className="italic"
        />

        <div className="flex justify-end pt-6">
          <Button onClick={handleAddProject} size="lg" className="gap-3">
            <span className="text-[10px] font-black uppercase tracking-[0.4em]">Confirm Import</span>
            <Zap size={16} className="group-hover:scale-110 transition-transform" />
          </Button>
        </div>
      </div>
    </div>
  );
}