import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  ArrowLeft, Search as SearchIcon, Clock, 
  CheckCircle2, ChevronRight, AlertCircle, 
  Filter, ShieldAlert, Zap
} from "lucide-react";

export default function ActionCenter({ projects = [] }) {
  const navigate = useNavigate();
  const [acPriority, setAcPriority] = useState('All');
  const [acSearch, setAcSearch] = useState('');

  // Mock data - In production, this would come from your global project state
  const mockPendingGates = [
    { id: 'G4', task: 'Design System Approval', project: 'Omnishop E-commerce', priority: 'Urgent', timeout: '02:45:12', complexity: 'High' },
    { id: 'G6', task: 'Unit Test Coverage Review', project: 'Intelligent Foot Pad', priority: 'High', timeout: '05:12:00', complexity: 'Medium' },
    { id: 'G9', task: 'UAT Sign-off', project: 'Elite AI Pod UI', priority: 'Medium', timeout: '12:20:45', complexity: 'Low' },
  ];

  // Filtering Logic
  const filteredGates = mockPendingGates.filter(gate => {
    const matchesPriority = acPriority === 'All' || gate.priority === acPriority;
    const matchesSearch = gate.task.toLowerCase().includes(acSearch.toLowerCase()) || 
                          gate.project.toLowerCase().includes(acSearch.toLowerCase());
    return matchesPriority && matchesSearch;
  });

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-[#09090b] text-white font-sans animate-in fade-in duration-500">
      
      {/* 1. HEADER */}
      <header className="h-20 flex items-center justify-between px-8 bg-[#09090b]/50 backdrop-blur-md shrink-0 border-b border-zinc-800/50 sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/')} 
            className="p-2 hover:bg-zinc-800 rounded-xl text-zinc-500 transition-all border border-zinc-800/50"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-xl font-black tracking-tight text-zinc-100 uppercase italic">Action Center</h1>
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest leading-none mt-1">
              Manual Intervention Required
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6">
           <StatBox label="Active Gates" value={mockPendingGates.length} color="text-violet-400" />
           <StatBox label="Urgent" value={mockPendingGates.filter(g => g.priority === 'Urgent').length} color="text-red-400" />
        </div>
      </header>

      {/* 2. FILTER BAR */}
      <div className="px-8 py-4 border-b border-zinc-800/30 flex flex-wrap gap-4 items-center justify-between bg-zinc-950/50 backdrop-blur-sm">
          <div className="flex gap-2">
            {['All', 'Urgent', 'High', 'Medium'].map(prio => (
              <button 
                key={prio} 
                onClick={() => setAcPriority(prio)}
                className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest border transition-all active:scale-95 ${
                  acPriority === prio 
                  ? 'bg-violet-600 border-violet-500 text-white shadow-[0_0_15px_rgba(139,92,246,0.3)]' 
                  : 'bg-zinc-900/50 border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700'
                }`}
              >
                {prio}
              </button>
            ))}
          </div>

          <div className="relative group">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600 group-focus-within:text-violet-400 transition-colors" size={14} />
            <input 
              value={acSearch}
              onChange={(e) => setAcSearch(e.target.value)}
              placeholder="Filter tasks or projects..." 
              className="bg-zinc-950 border border-zinc-800 rounded-xl pl-9 pr-4 py-2 text-xs w-72 focus:border-violet-500/50 outline-none transition-all text-white placeholder:text-zinc-700 font-medium"
            />
          </div>
      </div>

      {/* 3. TASK LIST */}
      <div className="flex-1 overflow-y-auto p-8 max-w-6xl mx-auto w-full space-y-4 custom-scrollbar">
        {filteredGates.map((gate) => (
          <div 
            key={gate.id} 
            className="group bg-[#0d0d0f] border border-zinc-800/60 rounded-[1.5rem] p-6 hover:border-violet-500/30 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative overflow-hidden"
          >
            {/* Subtle Priority Indicator Line */}
            <div className={`absolute left-0 top-0 bottom-0 w-1 ${gate.priority === 'Urgent' ? 'bg-red-500' : 'bg-violet-500/20'}`} />

            <div className="flex-1 pr-4">
              <div className="flex items-center gap-3 mb-3">
                <span className="text-[9px] font-black text-violet-400 bg-violet-400/5 px-2 py-1 rounded border border-violet-400/20 uppercase tracking-tighter">
                  Node {gate.id}
                </span>
                <span className={`text-[9px] font-black px-2 py-1 rounded uppercase tracking-widest ${
                  gate.priority === 'Urgent' ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-zinc-800/50 text-zinc-500'
                }`}>
                  {gate.priority}
                </span>
                <div className="flex items-center gap-1.5 text-amber-500/80 text-[10px] font-mono ml-auto md:ml-4 bg-amber-500/5 px-2 py-1 rounded border border-amber-500/10">
                  <Clock size={12} className="animate-pulse" /> {gate.timeout}
                </div>
              </div>

              <h3 className="text-lg font-bold text-zinc-100 group-hover:text-white transition-colors tracking-tight">
                {gate.task}
              </h3>
              
              <div className="flex items-center gap-2 mt-2">
                <ShieldAlert size={12} className="text-zinc-600" />
                <p className="text-[11px] text-zinc-500 font-bold uppercase tracking-tight">
                   {gate.project}
                </p>
              </div>
            </div>
            
            <div className="flex gap-2 w-full md:w-auto shrink-0 z-10">
              <button 
                className="flex-1 md:flex-none px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 shadow-emerald-900/10"
              >
                <CheckCircle2 size={14} /> Approve
              </button>
              <button 
                className="flex-1 md:flex-none px-6 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-100 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95 border border-zinc-800"
              >
                Details
              </button>
            </div>
          </div>
        ))}

        {filteredGates.length === 0 && (
          <div className="py-32 flex flex-col items-center opacity-20">
            <Zap size={48} className="text-zinc-500 mb-4" />
            <p className="font-black uppercase tracking-[0.3em] text-zinc-500 text-center text-xs">
              All gates cleared
            </p>
          </div>
        )}
      </div>

      {/* 4. FOOTER */}
      <footer className="h-12 border-t border-zinc-800/30 px-8 flex items-center justify-between shrink-0 text-[8px] font-black uppercase tracking-[0.2em] text-zinc-600">
          <span>Security Protocol: AES-256</span>
          <span className="text-violet-500/50">Elite AI Systems // Action Layer</span>
      </footer>
    </div>
  );
}

function StatBox({ label, value, color }) {
  return (
    <div className="flex flex-col items-end">
      <span className="text-[7px] font-black text-zinc-500 uppercase tracking-widest mb-1">{label}</span>
      <span className={`text-xl font-black leading-none ${color}`}>{value}</span>
    </div>
  );
}