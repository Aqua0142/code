import { BrowserRouter as Router, Routes, Route, useParams, useNavigate } from "react-router-dom";
import MainLayout from "../components/layout/MainLayout";
import Dashboard from "../features/dashboard/Dashboard";
import ProjectSetup from "../features/project/setup/ProjectSetup";
import AddExistingProject from "../features/import/AddExistingProject";
import ActionCenter from "../features/action-center/ActionCenter";
import PhaseSelection from "../features/project/phases/PhaseSelection";
import ProjectDetails from "../features/project/details/ProjectDetails";
import Login from "../features/auth/Login";

interface Project {
  id: string | number;
  name?: string;
  projectName?: string;
  [key: string]: any; // Allows other dynamic properties
}

function ProjectDetailsWrapper() {
  // 🟢 2. Hooks now properly imported
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  
  // 🟢 3. Type the parsed array as Project[]
  const projects: Project[] = JSON.parse(localStorage.getItem("projects") || "[]");
  const project = projects.find(p => p.id.toString() === projectId);

  if (!project) return (
    <div className="h-screen bg-[#09090b] text-white flex flex-col items-center justify-center gap-4">
      <p className="text-zinc-500 uppercase tracking-widest text-xs">Project Not Found</p>
      <button onClick={() => navigate("/")} className="text-violet-400 text-sm font-bold underline">Return to Dashboard</button>
    </div>
  );

  return (
    <ProjectDetails 
      project={project} 
      onBack={() => navigate("/")} 
      onUpdateProject={(updated: Project) => {
        const existing: Project[] = JSON.parse(localStorage.getItem("projects") || "[]");
        const newProjects = existing.map(p => p.id.toString() === updated.id.toString() ? updated : p);
        localStorage.setItem("projects", JSON.stringify(newProjects));
      }} 
    />
  );
}

export default function AppRouter() {
  return (
    <Router>
      <Routes>
        <Route element={<MainLayout />}>
          {/* All these pages will now have the Universal Sidebar */}
          <Route path="/" element={<Dashboard />} />
          <Route path="/setup" element={<ProjectSetup />} />
          <Route path="/action-center" element={<ActionCenter />} />
          <Route path="/phase-selection" element={<PhaseSelection />} />
          {/* <Route path="/agent-selection" element={<AgentSelection />} /> */}
          <Route path="/Login" element={<Login />} />
          <Route path="/project/:projectId" element={<ProjectDetailsWrapper />} >
              <Route path="review/:gateId" element={<ProjectDetailsWrapper />} />
          </Route>
        </Route>
      </Routes>
    </Router>
  );
}