import AppRouter from "./router/Router";
import { AuthProvider } from "./hooks/useAuth";
import "./App.css";

function App() {
  return (
    <AuthProvider>
      <div className="app-container">
        <AppRouter />
      </div>
    </AuthProvider>
  );
}

export default App;