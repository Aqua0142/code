import { saveToStorage, getFromStorage, removeFromStorage, clearStorage } from "../utils/helpers";

// Storage Keys
export const STORAGE_KEYS = {
  PROJECTS: "projects",
  LATEST_PROJECT_SETUP: "latest_project_setup",
  USER_PREFERENCES: "user_preferences",
  AUTH_TOKEN: "auth_token",
  THEME: "theme",
  RECENT_SEARCHES: "recent_searches",
  DRAFT_PHASES: "draft_phases",
  AGENT_CONFIGS: "agent_configs",
};

// Storage Service
class StorageService {
  // Projects
  getProjects() {
    return getFromStorage(STORAGE_KEYS.PROJECTS, []);
  }

  saveProjects(projects) {
    return saveToStorage(STORAGE_KEYS.PROJECTS, projects);
  }

  addProject(project) {
    const projects = this.getProjects();
    const updated = [project, ...projects];
    return this.saveProjects(updated);
  }

  updateProject(id, updates) {
    const projects = this.getProjects();
    const updated = projects.map((p) => (p.id === id ? { ...p, ...updates } : p));
    return this.saveProjects(updated);
  }

  deleteProject(id) {
    const projects = this.getProjects();
    const updated = projects.filter((p) => p.id !== id);
    return this.saveProjects(updated);
  }

  getProjectById(id) {
    const projects = this.getProjects();
    return projects.find((p) => p.id === id);
  }

  // Latest Project Setup
  getLatestProjectSetup() {
    return getFromStorage(STORAGE_KEYS.LATEST_PROJECT_SETUP, null);
  }

  saveLatestProjectSetup(setupData) {
    return saveToStorage(STORAGE_KEYS.LATEST_PROJECT_SETUP, setupData);
  }

  clearLatestProjectSetup() {
    return removeFromStorage(STORAGE_KEYS.LATEST_PROJECT_SETUP);
  }

  // User Preferences
  getUserPreferences() {
    return getFromStorage(STORAGE_KEYS.USER_PREFERENCES, {
      theme: "dark",
      notifications: true,
      autoSave: true,
    });
  }

  saveUserPreferences(preferences) {
    return saveToStorage(STORAGE_KEYS.USER_PREFERENCES, preferences);
  }

  updateUserPreference(key, value) {
    const preferences = this.getUserPreferences();
    return this.saveUserPreferences({ ...preferences, [key]: value });
  }

  // Authentication
  getAuthToken() {
    return getFromStorage(STORAGE_KEYS.AUTH_TOKEN, null);
  }

  saveAuthToken(token) {
    return saveToStorage(STORAGE_KEYS.AUTH_TOKEN, token);
  }

  clearAuthToken() {
    return removeFromStorage(STORAGE_KEYS.AUTH_TOKEN);
  }

  // Theme
  getTheme() {
    return getFromStorage(STORAGE_KEYS.THEME, "dark");
  }

  saveTheme(theme) {
    return saveToStorage(STORAGE_KEYS.THEME, theme);
  }

  // Recent Searches
  getRecentSearches() {
    return getFromStorage(STORAGE_KEYS.RECENT_SEARCHES, []);
  }

  addRecentSearch(search) {
    const searches = this.getRecentSearches();
    const updated = [search, ...searches.filter((s) => s !== search)].slice(0, 10);
    return saveToStorage(STORAGE_KEYS.RECENT_SEARCHES, updated);
  }

  clearRecentSearches() {
    return removeFromStorage(STORAGE_KEYS.RECENT_SEARCHES);
  }

  // Draft Phases
  getDraftPhases(projectId) {
    const drafts = getFromStorage(STORAGE_KEYS.DRAFT_PHASES, {});
    return drafts[projectId] || [];
  }

  saveDraftPhases(projectId, phases) {
    const drafts = getFromStorage(STORAGE_KEYS.DRAFT_PHASES, {});
    drafts[projectId] = phases;
    return saveToStorage(STORAGE_KEYS.DRAFT_PHASES, drafts);
  }

  clearDraftPhases(projectId) {
    const drafts = getFromStorage(STORAGE_KEYS.DRAFT_PHASES, {});
    delete drafts[projectId];
    return saveToStorage(STORAGE_KEYS.DRAFT_PHASES, drafts);
  }

  // Agent Configurations
  getAgentConfigs(projectId, phaseId) {
    const configs = getFromStorage(STORAGE_KEYS.AGENT_CONFIGS, {});
    return configs[`${projectId}_${phaseId}`] || [];
  }

  saveAgentConfigs(projectId, phaseId, configs) {
    const allConfigs = getFromStorage(STORAGE_KEYS.AGENT_CONFIGS, {});
    allConfigs[`${projectId}_${phaseId}`] = configs;
    return saveToStorage(STORAGE_KEYS.AGENT_CONFIGS, allConfigs);
  }

  clearAgentConfigs(projectId, phaseId) {
    const configs = getFromStorage(STORAGE_KEYS.AGENT_CONFIGS, {});
    delete configs[`${projectId}_${phaseId}`];
    return saveToStorage(STORAGE_KEYS.AGENT_CONFIGS, configs);
  }

  // Clear All Storage
  clearAll() {
    return clearStorage();
  }

  // Export/Import
  exportData() {
    const data = {
      projects: this.getProjects(),
      preferences: this.getUserPreferences(),
      theme: this.getTheme(),
      recentSearches: this.getRecentSearches(),
      timestamp: new Date().toISOString(),
    };
    return JSON.stringify(data, null, 2);
  }

  importData(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      if (data.projects) this.saveProjects(data.projects);
      if (data.preferences) this.saveUserPreferences(data.preferences);
      if (data.theme) this.saveTheme(data.theme);
      if (data.recentSearches) saveToStorage(STORAGE_KEYS.RECENT_SEARCHES, data.recentSearches);
      return true;
    } catch (error) {
      console.error("Failed to import data:", error);
      return false;
    }
  }
}

// Export singleton instance
export const storage = new StorageService();

// Export class for testing
export { StorageService };
