import { retryWithBackoff } from "../utils/helpers";

// API Configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000/api";
const API_TIMEOUT = 30000;

// HTTP Client
class ApiClient {
  constructor(baseURL = API_BASE_URL) {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config = {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), API_TIMEOUT);

    try {
      const response = await fetch(url, {
        ...config,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      if (error.name === "AbortError") {
        throw new Error("Request timeout");
      }
      throw error;
    }
  }

  get(endpoint, options) {
    return this.request(endpoint, { ...options, method: "GET" });
  }

  post(endpoint, data, options) {
    return this.request(endpoint, {
      ...options,
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  put(endpoint, data, options) {
    return this.request(endpoint, {
      ...options,
      method: "PUT",
      body: JSON.stringify(data),
    });
  }

  patch(endpoint, data, options) {
    return this.request(endpoint, {
      ...options,
      method: "PATCH",
      body: JSON.stringify(data),
    });
  }

  delete(endpoint, options) {
    return this.request(endpoint, { ...options, method: "DELETE" });
  }
}

const client = new ApiClient();

// Projects API
export const projectsApi = {
  getAll: () => client.get("/projects"),
  
  getById: (id) => client.get(`/projects/${id}`),
  
  create: (projectData) => client.post("/projects", projectData),
  
  update: (id, updates) => client.patch(`/projects/${id}`, updates),
  
  delete: (id) => client.delete(`/projects/${id}`),
  
  getStatus: (id) => client.get(`/projects/${id}/status`),
  
  updateStatus: (id, status) => 
    client.patch(`/projects/${id}/status`, { status }),
};

// Phases API
export const phasesApi = {
  getByProject: (projectId) => client.get(`/projects/${projectId}/phases`),
  
  getById: (projectId, phaseId) => 
    client.get(`/projects/${projectId}/phases/${phaseId}`),
  
  create: (projectId, phaseData) => 
    client.post(`/projects/${projectId}/phases`, phaseData),
  
  update: (projectId, phaseId, updates) => 
    client.patch(`/projects/${projectId}/phases/${phaseId}`, updates),
  
  approve: (projectId, phaseId) => 
    client.post(`/projects/${projectId}/phases/${phaseId}/approve`),
  
  reject: (projectId, phaseId, reason) => 
    client.post(`/projects/${projectId}/phases/${phaseId}/reject`, { reason }),
};

// Agents API
export const agentsApi = {
  getByPhase: (projectId, phaseId) => 
    client.get(`/projects/${projectId}/phases/${phaseId}/agents`),
  
  assign: (projectId, phaseId, agentData) => 
    client.post(`/projects/${projectId}/phases/${phaseId}/agents`, agentData),
  
  update: (projectId, phaseId, agentId, updates) => 
    client.patch(`/projects/${projectId}/phases/${phaseId}/agents/${agentId}`, updates),
  
  remove: (projectId, phaseId, agentId) => 
    client.delete(`/projects/${projectId}/phases/${phaseId}/agents/${agentId}`),
  
  updateModel: (projectId, phaseId, agentId, model) => 
    client.patch(`/projects/${projectId}/phases/${phaseId}/agents/${agentId}/model`, { model }),
};

// Artifacts API
export const artifactsApi = {
  getByPhase: (projectId, phaseId) => 
    client.get(`/projects/${projectId}/phases/${phaseId}/artifacts`),
  
  create: (projectId, phaseId, artifactData) => 
    client.post(`/projects/${projectId}/phases/${phaseId}/artifacts`, artifactData),
  
  update: (projectId, phaseId, artifactId, updates) => 
    client.patch(`/projects/${projectId}/phases/${phaseId}/artifacts/${artifactId}`, updates),
  
  delete: (projectId, phaseId, artifactId) => 
    client.delete(`/projects/${projectId}/phases/${phaseId}/artifacts/${artifactId}`),
  
  linkSource: (projectId, phaseId, artifactId, sourceId) => 
    client.post(`/projects/${projectId}/phases/${phaseId}/artifacts/${artifactId}/link`, { sourceId }),
};

// Gates API
export const gatesApi = {
  getByProject: (projectId) => client.get(`/projects/${projectId}/gates`),
  
  getById: (projectId, gateId) => 
    client.get(`/projects/${projectId}/gates/${gateId}`),
  
  approve: (projectId, gateId, approvalData) => 
    client.post(`/projects/${projectId}/gates/${gateId}/approve`, approvalData),
  
  reject: (projectId, gateId, rejectionData) => 
    client.post(`/projects/${projectId}/gates/${gateId}/reject`, rejectionData),
  
  getMetrics: (projectId, gateId) => 
    client.get(`/projects/${projectId}/gates/${gateId}/metrics`),
};

// Events API
export const eventsApi = {
  getByProject: (projectId, filters = {}) => {
    const params = new URLSearchParams(filters).toString();
    return client.get(`/projects/${projectId}/events?${params}`);
  },
  
  create: (projectId, eventData) => 
    client.post(`/projects/${projectId}/events`, eventData),
};

// Metrics API
export const metricsApi = {
  getByProject: (projectId) => client.get(`/projects/${projectId}/metrics`),
  
  getCostBreakdown: (projectId) => 
    client.get(`/projects/${projectId}/metrics/cost`),
  
  getPerformance: (projectId) => 
    client.get(`/projects/${projectId}/metrics/performance`),
};

// Pipeline API
export const pipelineApi = {
  getByProject: (projectId) => client.get(`/projects/${projectId}/pipeline`),
  
  trigger: (projectId, pipelineData) => 
    client.post(`/projects/${projectId}/pipeline/trigger`, pipelineData),
  
  getStatus: (projectId, pipelineId) => 
    client.get(`/projects/${projectId}/pipeline/${pipelineId}/status`),
};

// Retry wrapper for critical operations
export const withRetry = (apiCall, maxRetries = 3) => {
  return retryWithBackoff(apiCall, maxRetries);
};

// Export client for custom requests
export { client as apiClient };
