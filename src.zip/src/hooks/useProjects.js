import { useLocalStorage } from "./useLocalStorage";
import { MOCK_PROJECT } from "../utils/constants";
import { storage } from "../services/storage";

export function useProjects() {
  const [projects, setProjects] = useLocalStorage("projects", [MOCK_PROJECT]);

  const addProject = (project) => {
    const newProject = { ...project, id: project.id || Date.now().toString() };
    setProjects((prev) => [newProject, ...prev]);
    storage.addProject(newProject);
    return newProject;
  };

  const updateProject = (id, updates) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
    storage.updateProject(id, updates);
  };

  const deleteProject = (id) => {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    storage.deleteProject(id);
  };

  const getProjectById = (id) => {
    return projects.find((p) => p.id === id) || storage.getProjectById(id);
  };

  return {
    projects,
    setProjects,
    addProject,
    updateProject,
    deleteProject,
    getProjectById,
  };
}