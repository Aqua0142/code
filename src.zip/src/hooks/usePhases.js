import { useState, useEffect } from "react";
import { phasesApi } from "../services/api";
import { storage } from "../services/storage";

export function usePhases(projectId) {
  const [phases, setPhases] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (projectId) {
      loadPhases();
    }
  }, [projectId]);

  const loadPhases = async () => {
    setLoading(true);
    setError(null);
    try {
      // TODO: Replace with actual API call when backend is ready
      const drafts = storage.getDraftPhases(projectId);
      setPhases(drafts);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const createPhase = async (phaseData) => {
    try {
      // TODO: Replace with actual API call
      const newPhase = { id: Date.now().toString(), ...phaseData };
      const updated = [...phases, newPhase];
      setPhases(updated);
      storage.saveDraftPhases(projectId, updated);
      return { success: true, data: newPhase };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const updatePhase = async (phaseId, updates) => {
    try {
      const updated = phases.map((p) =>
        p.id === phaseId ? { ...p, ...updates } : p
      );
      setPhases(updated);
      storage.saveDraftPhases(projectId, updated);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const deletePhase = async (phaseId) => {
    try {
      const updated = phases.filter((p) => p.id !== phaseId);
      setPhases(updated);
      storage.saveDraftPhases(projectId, updated);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const approvePhase = async (phaseId) => {
    return updatePhase(phaseId, { status: "approved" });
  };

  const rejectPhase = async (phaseId, reason) => {
    return updatePhase(phaseId, { status: "rejected", rejectionReason: reason });
  };

  return {
    phases,
    loading,
    error,
    loadPhases,
    createPhase,
    updatePhase,
    deletePhase,
    approvePhase,
    rejectPhase,
  };
}
