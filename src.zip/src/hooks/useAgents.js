import { useState, useEffect } from "react";
import { agentsApi } from "../services/api";
import { storage } from "../services/storage";

export function useAgents(projectId, phaseId) {
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (projectId && phaseId) {
      loadAgents();
    }
  }, [projectId, phaseId]);

  const loadAgents = async () => {
    setLoading(true);
    setError(null);
    try {
      // TODO: Replace with actual API call when backend is ready
      const configs = storage.getAgentConfigs(projectId, phaseId);
      setAgents(configs);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const assignAgent = async (agentData) => {
    try {
      const newAgent = {
        id: Date.now().toString(),
        ...agentData,
        assignedAt: new Date().toISOString(),
      };
      const updated = [...agents, newAgent];
      setAgents(updated);
      storage.saveAgentConfigs(projectId, phaseId, updated);
      return { success: true, data: newAgent };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const updateAgent = async (agentId, updates) => {
    try {
      const updated = agents.map((a) =>
        a.id === agentId ? { ...a, ...updates } : a
      );
      setAgents(updated);
      storage.saveAgentConfigs(projectId, phaseId, updated);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const removeAgent = async (agentId) => {
    try {
      const updated = agents.filter((a) => a.id !== agentId);
      setAgents(updated);
      storage.saveAgentConfigs(projectId, phaseId, updated);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const updateAgentModel = async (agentId, model) => {
    return updateAgent(agentId, { model });
  };

  const toggleAgentStatus = async (agentId) => {
    const agent = agents.find((a) => a.id === agentId);
    if (!agent) return { success: false, error: "Agent not found" };
    
    const newStatus = agent.status === "active" ? "inactive" : "active";
    return updateAgent(agentId, { status: newStatus });
  };

  return {
    agents,
    loading,
    error,
    loadAgents,
    assignAgent,
    updateAgent,
    removeAgent,
    updateAgentModel,
    toggleAgentStatus,
  };
}
